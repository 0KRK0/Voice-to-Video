"""Phase C, the server's half: what a device is allowed to be given.

## The three things being defended

**A device is only ever handed its own organisation's work.** This is the single
most important check in a multi-tenant system, and here it is checked at the one
place a device is handed content at all. A bug here is a cross-customer
disclosure of somebody's unreleased video.

**A device is given four photographs, not a bucket.** Every URL in an assignment
is signed, expiring, and scoped to one object the timeline actually names. The
upload URL is write-only, single-object and size-capped. A leaked assignment is
worth exactly the four files it names, for one hour.

**A closed laptop is a delay, not a stuck render.** The lease is the queue's own
claim, so a device that stops talking is recovered by the same rule that
recovers a killed worker — and this is tested by actually letting one expire
rather than by trusting that it would.
"""

from __future__ import annotations

import asyncio
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from typing import Any

from vtv.adapters.queue.durable import DurableJobQueue
from vtv.adapters.storage.local import LocalStorageProvider
from vtv.contracts.base import ObjectRef
from vtv.contracts.devices import Completion, DeviceHardware, ProgressReport
from vtv.contracts.errors import PolicyViolation
from vtv.contracts.tenancy import Organisation
from vtv.dispatch import DEVICE_KIND, DevicePool, worker_id_for
from vtv.observability.events import EventSink
from vtv.security.devices import mint_pairing_code
from vtv.security.directory import Directory


def run(coroutine):  # type: ignore[no-untyped-def]
    return asyncio.run(coroutine)


class Documents:
    """The one repository method a dispatcher needs.

    A stub rather than a real SQLite repository because what is under test is
    what a device may be *given*, not how a timeline is stored — and a fake that
    returns a real `Timeline` exercises exactly the same validation the real one
    would.
    """

    def __init__(self, documents: dict[str, dict[str, Any]] | None = None) -> None:
        self.documents = documents or {}

    async def get_document(self, *, project_id: str, kind: str) -> Any:
        return self.documents.get(f"{project_id}:{kind}")


class Fixture:
    """A server with one organisation, one device and one queued job."""

    def __init__(self, root: Path, *, clock: Any = None) -> None:
        self.root = root
        self.directory = Directory(path=root / "dir.db")
        self.organisation = self.directory.create_organisation(
            Organisation(name="Acme", slug="acme")
        )
        self.storage = LocalStorageProvider(root / "storage")
        self.queue = DurableJobQueue(
            root / "queue.db",
            EventSink(),
            reclaim_after_seconds=30.0,
            **({"clock": clock} if clock else {}),
        )
        # Registered so `lease` with no kinds would still find it, and so the
        # queue's own accounting matches a real deployment's.
        self.queue.register(DEVICE_KIND, self._never_run)
        self.repository = Documents()
        self.pool = DevicePool(
            queue=self.queue,
            repository=self.repository,
            storage=self.storage,
            directory=self.directory,
        )

    async def _never_run(self, payload: dict[str, Any]) -> str:  # pragma: no cover
        raise AssertionError("a device job must never execute in the server process")

    def pair(self, *, organisation_id: str | None = None, name: str = "Desk") -> Any:
        code = self.directory.create_pairing_code(
            mint_pairing_code(
                organisation_id=organisation_id or self.organisation.organisation_id
            )
        )
        return self.directory.redeem_pairing_code(
            code.code,
            name=name,
            hardware=DeviceHardware(cpu_cores=8, gpu_name="A card", gpu_verified=True),
        ).record

    def timeline(self, project_id: str) -> Any:
        from tests.test_render_segments import plain_timeline

        story = plain_timeline(
            ObjectRef(bucket="b", key="n.wav", content_type="audio/wav")
        ).model_copy(
            update={
                "project_id": project_id,
                "organisation_id": self.organisation.organisation_id,
            }
        )
        self.repository.documents[f"{project_id}:timeline"] = story.model_dump(
            mode="json"
        )
        return story

    async def enqueue(
        self, *, project_id: str, organisation_id: str | None = None
    ) -> str:
        self.timeline(project_id)
        handle = await self.queue.enqueue(
            kind=DEVICE_KIND,
            payload={
                "project_id": project_id,
                "organisation_id": organisation_id
                or self.organisation.organisation_id,
                "render_job_id": "rnd_" + "b" * 24,
                "settings": {"frame_rate": 24},
            },
        )
        return handle.job_id if hasattr(handle, "job_id") else str(handle)


class ADeviceIsOnlyOfferedItsOwnOrganisationsWork(unittest.TestCase):
    """The check whose failure mode is a cross-customer disclosure."""

    def setUp(self) -> None:
        self._dir = TemporaryDirectory(prefix="vtv-dispatch-")
        self.fixture = Fixture(Path(self._dir.name))

    def tearDown(self) -> None:
        self._dir.cleanup()

    def test_a_device_gets_a_job_from_its_own_tenant(self) -> None:
        device = self.fixture.pair()
        run(self.fixture.enqueue(project_id="prj_" + "c" * 24))
        assignment = run(self.fixture.pool.claim(device))
        self.assertIsNotNone(assignment)
        self.assertEqual(
            assignment.organisation_id, self.fixture.organisation.organisation_id
        )
        self.assertEqual(assignment.lease.device_id, device.device_id)

    def test_a_job_from_another_tenant_is_refused_and_given_back(self) -> None:
        """Refused *and* handed back. Leaving it claimed would mean one device's
        mistake silently withholding another tenant's render for five minutes.
        """
        device = self.fixture.pair()
        run(
            self.fixture.enqueue(
                project_id="prj_" + "d" * 24,
                organisation_id="org_" + "e" * 24,
            )
        )
        with self.assertRaises(PolicyViolation):
            run(self.fixture.pool.claim(device))
        stats = run(self.fixture.queue.stats())
        self.assertEqual(stats.get("running", 0), 0, stats)

    def test_a_revoked_device_is_offered_nothing(self) -> None:
        device = self.fixture.pair()
        self.fixture.directory.revoke_device(device.device_id)
        revoked = self.fixture.directory.device(device.device_id)
        run(self.fixture.enqueue(project_id="prj_" + "f" * 24))
        with self.assertRaises(PolicyViolation):
            run(self.fixture.pool.claim(revoked))

    def test_an_idle_queue_offers_nothing_rather_than_failing(self) -> None:
        """The common answer. A device asks every few seconds and almost always
        hears no."""
        device = self.fixture.pair()
        self.assertIsNone(run(self.fixture.pool.claim(device)))

    def test_a_device_may_only_report_on_its_own_work(self) -> None:
        """`ProgressReport.device_id` exists so a report is self-describing in a
        log, not so a caller can nominate whose job it is renewing."""
        device = self.fixture.pair()
        other = self.fixture.pair(name="Somebody else")
        run(self.fixture.enqueue(project_id="prj_" + "g" * 24))
        run(self.fixture.pool.claim(device))
        with self.assertRaises(PolicyViolation):
            run(
                self.fixture.pool.progress(
                    other,
                    ProgressReport(
                        render_job_id="rnd_" + "b" * 24,
                        device_id=device.device_id,
                        segments_done=1,
                        segments_total=4,
                    ),
                )
            )

    def test_a_device_may_only_complete_its_own_work(self) -> None:
        device = self.fixture.pair()
        other = self.fixture.pair(name="Somebody else")
        run(self.fixture.enqueue(project_id="prj_" + "h" * 24))
        run(self.fixture.pool.claim(device))
        with self.assertRaises(PolicyViolation):
            run(
                self.fixture.pool.complete(
                    other,
                    Completion(
                        render_job_id="rnd_" + "b" * 24,
                        device_id=device.device_id,
                        ok=True,
                    ),
                )
            )

    def test_two_devices_do_not_get_the_same_job(self) -> None:
        """Atomic claim, from the queue rather than from a check-then-write here."""
        first = self.fixture.pair(name="One")
        second = self.fixture.pair(name="Two")
        run(self.fixture.enqueue(project_id="prj_" + "z" * 24))
        self.assertIsNotNone(run(self.fixture.pool.claim(first)))
        self.assertIsNone(run(self.fixture.pool.claim(second)))


class AnAssignmentCarriesNoCredentials(unittest.TestCase):
    """What is *in* the envelope, which is the other half of the security story."""

    def setUp(self) -> None:
        self._dir = TemporaryDirectory(prefix="vtv-assign-")
        self.fixture = Fixture(Path(self._dir.name))

    def tearDown(self) -> None:
        self._dir.cleanup()

    def assignment(self) -> Any:
        device = self.fixture.pair()
        run(self.fixture.enqueue(project_id="prj_" + "j" * 24))
        return run(self.fixture.pool.claim(device))

    def test_it_contains_no_provider_credentials(self) -> None:
        """The line that makes "use your own GPU" safe to offer at all.

        Asserted over the serialised envelope rather than field by field,
        because a field added later would slip past a field-by-field check.

        Note what is *not* forbidden: the word "token". Signed URLs carry a
        signature, and banning the word would either fail forever or push
        somebody into renaming the parameter, which is worse than useless — the
        property that matters is not the absence of a string but that the only
        credentials present are the scoped, expiring, single-object ones the
        next two tests pin down.
        """
        payload = self.assignment().model_dump_json().lower()
        for forbidden in (
            "api_key",
            "apikey",
            "openai",
            "anthropic",
            "password",
            "vtv_live_",
            "vtv_test_",
            "vtv_dev_",
            "aws_",
            "sk-",
        ):
            with self.subTest(term=forbidden):
                self.assertNotIn(forbidden, payload)

    def test_the_upload_url_reaches_exactly_one_object(self) -> None:
        """Write-only, single-object, expiring and size-capped.

        Four separate limits because each removes a different thing a leaked URL
        could be used for: reading other renders, overwriting a different
        object, working next week, and filling the bucket.
        """
        assignment = self.assignment()
        self.assertIn(assignment.render_job_id, assignment.upload_url)
        self.assertIn(assignment.project_id, assignment.upload_url)
        self.assertIn("upload", assignment.upload_url)

    def test_an_asset_url_reaches_that_asset_and_not_its_neighbours(self) -> None:
        """A device is given the ability to read four photographs, not the
        ability to read the bucket those photographs are in."""
        from vtv.dispatch import ASSET_URL_SECONDS

        self.assertLessEqual(ASSET_URL_SECONDS, 3600)
        for handout in self.assignment().assets:
            with self.subTest(key=handout.key):
                self.assertIn(handout.object.key.split("/")[-1], handout.url)

    def test_it_carries_the_resolved_timeline_and_settings(self) -> None:
        """Everything the device may see arrives here, because it can read
        nothing else."""
        assignment = self.assignment()
        self.assertTrue(assignment.timeline.clips)
        self.assertEqual(assignment.settings.frame_rate, 24)

    def test_an_asset_that_cannot_be_verified_is_withheld(self) -> None:
        """A device that cannot check an asset must not draw from it.

        The renderer describes a missing asset as a message card, which is
        visible and honest. A corrupt one is neither — it is a grey band the
        customer discovers after publishing.
        """
        assignment = self.assignment()
        for handout in assignment.assets:
            with self.subTest(key=handout.key):
                self.assertEqual(len(handout.sha256), 64)

    def test_the_lease_expires(self) -> None:
        """The whole design. A lease that had to be released explicitly would
        strand a render every time a laptop closed, and 'explicitly released' is
        exactly what a crashed process cannot do."""
        assignment = self.assignment()
        self.assertGreater(assignment.lease.expires_at, assignment.lease.granted_at)
        self.assertTrue(assignment.lease.is_live)


class AClosedLaptopIsADelayNotAStuckRender(unittest.TestCase):
    """Tested by letting a lease actually expire, not by trusting that it would."""

    def setUp(self) -> None:
        self._dir = TemporaryDirectory(prefix="vtv-lease-")
        self.now = [1000.0]
        self.fixture = Fixture(Path(self._dir.name), clock=lambda: self.now[0])

    def tearDown(self) -> None:
        self._dir.cleanup()

    def test_an_abandoned_job_is_offered_to_somebody_else(self) -> None:
        laptop = self.fixture.pair(name="Laptop")
        desktop = self.fixture.pair(name="Desktop")
        run(self.fixture.enqueue(project_id="prj_" + "k" * 24))

        self.assertIsNotNone(run(self.fixture.pool.claim(laptop)))
        # Nothing else may have it while the lease is alive.
        self.assertIsNone(run(self.fixture.pool.claim(desktop)))

        # The lid closes. No release, no message, nothing — which is the point.
        self.now[0] += 600.0
        run(self.fixture.queue.recover())

        self.assertIsNotNone(
            run(self.fixture.pool.claim(desktop)),
            "an abandoned job was never offered to another machine",
        )

    def test_progress_keeps_the_claim_alive(self) -> None:
        """Renewed by progress rather than by a timer of its own: a device still
        reporting frames is still working, and a heartbeat on its own schedule
        would keep insisting a wedged process was healthy."""
        laptop = self.fixture.pair(name="Laptop")
        other = self.fixture.pair(name="Other")
        run(self.fixture.enqueue(project_id="prj_" + "m" * 24))
        run(self.fixture.pool.claim(laptop))

        for _ in range(4):
            self.now[0] += 20.0
            run(
                self.fixture.pool.progress(
                    laptop,
                    ProgressReport(
                        render_job_id="rnd_" + "b" * 24,
                        device_id=laptop.device_id,
                        segments_done=1,
                        segments_total=4,
                    ),
                )
            )
        run(self.fixture.queue.recover())
        self.assertIsNone(
            run(self.fixture.pool.claim(other)),
            "a working device lost its job while it was reporting progress",
        )

    def test_an_outcome_from_a_lost_claim_is_discarded(self) -> None:
        """Not an error and not a lie to the device: the lease expired while it
        was drawing and somebody else has the job now."""
        laptop = self.fixture.pair(name="Laptop")
        desktop = self.fixture.pair(name="Desktop")
        run(self.fixture.enqueue(project_id="prj_" + "n" * 24))
        run(self.fixture.pool.claim(laptop))

        self.now[0] += 600.0
        run(self.fixture.queue.recover())
        run(self.fixture.pool.claim(desktop))

        accepted = run(
            self.fixture.pool.complete(
                laptop,
                Completion(
                    render_job_id="rnd_" + "b" * 24,
                    device_id=laptop.device_id,
                    ok=True,
                ),
            )
        )
        self.assertFalse(accepted, "a stale outcome overwrote the current worker's")

    def test_a_finished_job_is_settled(self) -> None:
        device = self.fixture.pair()
        run(self.fixture.enqueue(project_id="prj_" + "p" * 24))
        run(self.fixture.pool.claim(device))
        self.assertTrue(
            run(
                self.fixture.pool.complete(
                    device,
                    Completion(
                        render_job_id="rnd_" + "b" * 24,
                        device_id=device.device_id,
                        ok=True,
                        output_bytes=1234,
                    ),
                )
            )
        )
        stats = run(self.fixture.queue.stats())
        self.assertEqual(stats.get("succeeded", 0), 1, stats)

    def test_a_machine_specific_failure_is_retried_elsewhere(self) -> None:
        """`elsewhere` is the remote form of `SegmentOutcome.elsewhere`: only the
        device that failed knows whether it was about this machine or this job."""
        device = self.fixture.pair()
        run(self.fixture.enqueue(project_id="prj_" + "q" * 24))
        run(self.fixture.pool.claim(device))
        run(
            self.fixture.pool.complete(
                device,
                Completion(
                    render_job_id="rnd_" + "b" * 24,
                    device_id=device.device_id,
                    ok=False,
                    reason="out of video memory",
                    elsewhere=True,
                ),
            )
        )
        stats = run(self.fixture.queue.stats())
        self.assertEqual(stats.get("pending", 0), 1, stats)

    def test_a_job_that_cannot_be_drawn_anywhere_is_not_retried(self) -> None:
        """Retrying it would turn one clear error into several slow ones."""
        device = self.fixture.pair()
        run(self.fixture.enqueue(project_id="prj_" + "r" * 24))
        run(self.fixture.pool.claim(device))
        run(
            self.fixture.pool.complete(
                device,
                Completion(
                    render_job_id="rnd_" + "b" * 24,
                    device_id=device.device_id,
                    ok=False,
                    reason="the timeline references an asset that does not exist",
                    elsewhere=False,
                ),
            )
        )
        stats = run(self.fixture.queue.stats())
        # Dead-lettered rather than retried: parked where an exhausted retry
        # also lands, so "what went wrong with this render" is one query.
        self.assertEqual(stats.get("dead_letter", 0), 1, stats)
        self.assertEqual(stats.get("pending", 0), 0, stats)

    def test_a_device_names_itself_recognisably_in_the_queue(self) -> None:
        """A glance at `claimed_by` should say whether a job is in the cloud or
        on somebody's desk, which is the first thing anybody asks when a render
        is slow."""
        self.assertTrue(worker_id_for("dev_" + "a" * 24).startswith("device:"))


class ADeviceMayOnlyClaimOneKindOfWork(unittest.TestCase):
    """The allow-list, which is why a device never touches a provider."""

    def setUp(self) -> None:
        self._dir = TemporaryDirectory(prefix="vtv-kinds-")
        self.fixture = Fixture(Path(self._dir.name))

    def tearDown(self) -> None:
        self._dir.cleanup()

    def test_a_pipeline_job_is_never_offered_to_a_device(self) -> None:
        """`render_recording` transcribes, plans visuals and calls three
        providers before it draws anything. Every one of those needs a
        credential, and a credential on somebody's desktop is a credential in a
        coffee shop."""
        device = self.fixture.pair()
        self.fixture.queue.register("render_recording", self.fixture._never_run)
        run(
            self.fixture.queue.enqueue(
                kind="render_recording",
                payload={
                    "project_id": "prj_" + "s" * 24,
                    "organisation_id": self.fixture.organisation.organisation_id,
                },
            )
        )
        self.assertIsNone(
            run(self.fixture.pool.claim(device)),
            "a device was offered work that needs provider credentials",
        )

    def test_the_allow_list_has_exactly_one_entry(self) -> None:
        self.assertEqual(DEVICE_KIND, "render_timeline")


if __name__ == "__main__":  # pragma: no cover
    unittest.main()
