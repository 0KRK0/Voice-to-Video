"""What a customer actually types.

    vtv-desktop pair --code ABC-DEF --server https://app.example.com
    vtv-desktop hardware
    vtv-desktop run
    vtv-desktop status
    vtv-desktop unpair

Four verbs and one of them is a diagnostic. That is the whole surface, and it is
small on purpose: this program runs on a machine somebody uses for something
else, and every option is a thing they have to decide about a background process
they would rather not think about.

## Why `hardware` exists as its own command

Because "why isn't my graphics card being used" is the question this feature
will generate more than any other, and the answer has to be available without
pairing, without a job, and without reading a log. It prints what was measured
and, when the card was refused, the sentence saying why.
"""

from __future__ import annotations

import argparse
import asyncio
import contextlib
import signal
import sys
from pathlib import Path

from vtv.contracts.errors import VTVError
from vtv.desktop import state
from vtv.desktop.agent import Agent
from vtv.desktop.cache import AssetCache
from vtv.desktop.client import DeviceClient
from vtv.desktop.hardware import describe, detect


def _workspace(given: str | None) -> Path:
    return Path(given) if given else state.config_root() / "work"


async def _pair(args: argparse.Namespace) -> int:
    """Redeem a code and remember the token this machine gets back."""
    import httpx

    hardware = detect(probe_gpu=not args.skip_gpu_check)
    print(describe(hardware))
    print()

    name = args.name or _default_name()
    async with httpx.AsyncClient(
        base_url=args.server.rstrip("/"), timeout=30.0
    ) as client:
        response = await client.post(
            "/v1/devices/pair",
            json={
                "code": args.code,
                "name": name,
                "hardware": hardware.model_dump(mode="json"),
            },
        )
    if response.status_code >= 400:
        # The server refuses every bad pairing identically — expired, wrong,
        # already used all read the same — so the useful thing to say is what to
        # do next rather than to guess which it was.
        print(f"pairing failed ({response.status_code}): {response.text[:200]}")
        print("Codes last a few minutes and work once. Generate another and retry.")
        return 1

    payload = response.json()
    path = state.save(
        state.Pairing(
            server=args.server.rstrip("/"),
            device_id=str(payload["device_id"]),
            token=str(payload["token"]),
            name=name,
        )
    )
    print(f"paired as {name}")
    print(f"identity stored at {path}")
    print("Start rendering with:  vtv-desktop run")
    return 0


def _default_name() -> str:
    """Something a person will recognise in a list of their computers."""
    import platform

    host = platform.node().split(".")[0]
    return host or f"{platform.system()} computer"


async def _run(args: argparse.Namespace) -> int:
    pairing = state.load()
    workspace = _workspace(args.workspace)
    client = DeviceClient(server=pairing.server, token=pairing.token)
    agent = Agent(
        client=client,
        workspace=workspace,
        device_id=pairing.device_id,
        cache=AssetCache(workspace / "assets", budget_bytes=args.cache_bytes),
        workers=args.workers,
    )

    # A closed laptop is handled by the lease expiring. A Ctrl-C is not, and
    # should not be: the job in hand is minutes from finishing and throwing it
    # away would waste all of it. So the signal asks the loop to stop after the
    # current job, and a second one is the operating system's business.
    loop = asyncio.get_running_loop()
    for name in ("SIGINT", "SIGTERM"):
        received = getattr(signal, name, None)
        if received is None:
            continue
        # Windows has no `add_signal_handler`. KeyboardInterrupt still
        # propagates there, which is a coarser stop but not a broken one.
        with contextlib.suppress(NotImplementedError):
            loop.add_signal_handler(received, agent.stop)

    print(f"{pairing.name or pairing.device_id} is available for rendering")
    print(f"server    : {pairing.server}")
    print(describe(detect()))
    print("\nwaiting for work (Ctrl-C to stop after the current job)\n", flush=True)

    try:
        await agent.run(max_jobs=args.max_jobs)
    finally:
        await client.aclose()
    print(f"\nstopped. {agent.completed} completed, {agent.failed} failed.")
    return 0


async def _status(args: argparse.Namespace) -> int:
    del args
    pairing = state.load()
    workspace = _workspace(None)
    cache = AssetCache(workspace / "assets")
    print(f"device    : {pairing.name or '(unnamed)'}  {pairing.device_id}")
    print(f"server    : {pairing.server}")
    print(f"identity  : {state.token_path()}")
    print(f"cache     : {cache.size_bytes() / 1e6:.1f} MB at {cache.root}")
    print()
    print(describe(detect()))
    return 0


async def _hardware(args: argparse.Namespace) -> int:
    print(describe(detect(probe_gpu=not args.skip_gpu_check)))
    return 0


async def _unpair(args: argparse.Namespace) -> int:
    del args
    removed = state.forget()
    if removed:
        print("this computer will no longer render for that account")
        print("Note: the device is still listed on the account until it is revoked there.")
    else:
        print("this computer was not paired")
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="vtv-desktop",
        description="Render Voice to Video projects on this computer.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    pair = sub.add_parser("pair", help="link this computer to an account")
    pair.add_argument("--code", required=True, help="the code shown in the web app")
    pair.add_argument("--server", required=True, help="e.g. https://app.example.com")
    pair.add_argument("--name", help="what to call this computer (defaults to its hostname)")
    pair.add_argument(
        "--skip-gpu-check",
        action="store_true",
        help="pair without testing the graphics card (it is tested again before every job)",
    )
    pair.set_defaults(run=_pair)

    run = sub.add_parser("run", help="make this computer available for rendering")
    run.add_argument("--workspace", help="where to keep assets and part-finished jobs")
    run.add_argument(
        "--workers",
        type=int,
        help="segments to draw at once (default: sized from this machine)",
    )
    run.add_argument("--max-jobs", type=int, help="stop after this many jobs")
    run.add_argument(
        "--cache-bytes",
        type=int,
        default=AssetCache.__dataclass_fields__["budget_bytes"].default,
        help="ceiling for the downloaded-asset cache",
    )
    run.set_defaults(run=_run)

    status = sub.add_parser("status", help="show this computer's pairing and hardware")
    status.set_defaults(run=_status)

    hardware = sub.add_parser("hardware", help="show what this computer can render with")
    hardware.add_argument("--skip-gpu-check", action="store_true")
    hardware.set_defaults(run=_hardware)

    unpair = sub.add_parser("unpair", help="stop this computer rendering for the account")
    unpair.set_defaults(run=_unpair)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return asyncio.run(args.run(args))
    except KeyboardInterrupt:
        print("\nstopped")
        return 130
    except VTVError as exc:
        # The project's own errors carry sentences meant for people. Printing
        # the message rather than a traceback is the difference between a
        # customer fixing this themselves and a support ticket.
        print(f"{exc}", file=sys.stderr)
        return 1


def cli() -> None:  # pragma: no cover - process entrypoint
    raise SystemExit(main())


__all__ = ["build_parser", "cli", "main"]
