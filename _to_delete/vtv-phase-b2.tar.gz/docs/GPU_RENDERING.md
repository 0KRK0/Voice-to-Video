# GPU rendering

**Status: implemented, not physically verified.**

The GPU compositor is written and wired. It has never executed: the environment
it was built in has no graphics device and no way to obtain a graphics library
— the package index serves neither `moderngl` nor `wgpu`, and `apt` is blocked.
Until the equivalence test passes on a machine with a card, the product does not
offer GPU compositing. `/health` reports the target as unavailable, and
`wiring.execution_registry` registers no GPU backend.

[Validate it on Windows](#validating-on-windows) is one command.

## Why this is worth doing at all

Rendering is the only cost that scales with the length of somebody's video, and
it was profiled rather than guessed:

| | share of render time |
|---|---|
| composing frames | **77%** |
| encoding them (x264) | 23% |

Two consequences follow, and the second is the one most GPU work gets wrong.

**Hardware encoding is not the win.** Even at zero cost it caps a render at
1.3×, and it fights the worker pool that carries the other 77% — consumer
NVIDIA drivers limit concurrent encode sessions to a handful, so eight parallel
segments would serialise on the card. Encoding stays on the processor until
measurement says otherwise.

**Text is not the win either.** Inside that 77%, glyph rasterisation was 0.7%.
The expensive part was moving 1920×1080 buffers: a paste, a blend, a channel
split, a convert, per frame. Those are what move to the card.

## Architecture

```
RenderPlan
   ↓
RenderContext.describe(t)     pure; no pixels, no fonts, no filesystem
   ↓
DisplayList                   ONE scene representation
   ↓
Painter                       two implementations
   ├── CpuPainter  (reference)
   └── GpuPainter  (this)
   ↓
frame → ffmpeg → MP4
```

Above `Renderer`, nothing changed and nothing can tell which painter ran. The
Visual Director, the timeline, visual units, grounding, assets, narration and
checkpointing are untouched by this work.

**The invariant: both painters consume the same `DisplayList`.** The moment a
backend needs its own description, the composer has to know which backend it is
describing for, and the boundary is gone.

## What runs where

| | CPU | GPU |
|---|---|---|
| Layout, text, rounded rectangles | ✅ | — |
| Animation engine (charts, diagrams, typography) | ✅ | — |
| Texture upload | — | ✅ |
| Transform + sample (Ken Burns, pan, zoom, crop) | — | ✅ |
| Alpha-over compositing | — | ✅ |
| Transitions (blend, wipe, push) | — | ✅ |
| Vignette | ✅ rasterised | ✅ composited |
| Encoding | ✅ | — |

Text and plates are rasterised by **the reference painter** on both paths, into
a transparent RGBA tile the card composites. That is deliberate: it makes a
glyph bit-identical between the two implementations. Reimplementing type on a
card would be a font-rendering project whose output could never sit inside a
two-per-channel tolerance.

### The honest consequence

A typography-heavy video will not get much faster. Its frames come from the
animation engine on the processor and are then uploaded, and the upload is new
work. An image-heavy video — photographs with camera moves, dissolves between
them — is where the card wins. That is a measurement per project, not a claim,
which is what `scripts/bench_gpu_renderer.py` produces.

## Technology, and why

**OpenGL 3.3 through `moderngl`.**

* **It runs where the customer is.** Available on every Windows machine with a
  driver from the last decade — NVIDIA, AMD, Intel alike — and `moderngl`
  creates a standalone context with no window and no display.
* **It is small.** One C++ extension and a pip wheel. Not a runtime, a
  toolchain or a vendor SDK.
* **It is not CUDA.** Nothing here is NVIDIA-specific.
* **The seam is one file.** Swapping to `wgpu` — which maps onto D3D12, Vulkan
  and Metal, and is the better long-term answer once its Python bindings settle
  — replaces `gpu_painter.py` and nothing else.

Known cost: macOS deprecated OpenGL and caps it at 4.1. It still works; a Metal
path through `wgpu` is the eventual answer there.

## Capability detection

Hardware being present is **not** a capability. A card can be installed and
driverless, installed with a driver too old for the shaders, installed in a
container with no render node, or installed and already holding all its memory.
Every one of those reports as "an RTX 4070 is present" and fails at the first
frame of a sixty-minute render.

So `gpu_probe.probe()` asks the graphics stack to initialise, compile the
pipelines, **draw a calibration frame, and match it against the CPU reference**.
Only then is the card reported usable. A driver that initialises and draws the
*wrong* picture is worse than one that refuses — the render succeeds, the file
plays, and the captions are two pixels off until a customer notices.

Cached against a fingerprint that includes the adapter and driver strings, so a
driver update invalidates it and nothing else needs to.

`VTV_DISABLE_GPU=1` turns it off regardless. A switch that only ever *disables*
is safe to expose; one that forces a capability on is how a user ends up with a
render that cannot start.

## Determinism policy

Not bit-for-bit, and deliberately. Rasterisation on a card may differ from PIL
in the last bit or two — texture filtering is implementation-defined, and an
edge pixel landing on 127 rather than 128 is not a defect.

The rule has two halves and the second is the one that bites:

* no pixel may differ by more than **2** per channel;
* **no pixel may be outside that at all** (`MAX_OUTLIERS = 0`).

A mean-difference check would pass a caption sitting one pixel high on every
frame of a four-hour video. Real errors — a plate misplaced, an overlay
missing, a wipe running backwards — differ in the hundreds and either half
catches them. Subtle errors are caught only by the second.

The harness is tested before it is trusted: pointed at painters that shift a
plate by two pixels and that drop overlays, it must catch both; pointed at two
reference painters, it must pass.

## Fallback

A GPU failure means *this backend cannot do this segment*, never *the project is
broken*:

```
segment 41 → local_gpu ❌ out of video memory
segment 41 → local_cpu ✅
job.backends = {"local_gpu": 118, "local_cpu": 1}
```

Because segments are checkpointed, a failed attempt costs one segment and every
finished segment stays on disk. Every fallback is reported in the event stream
with its reason — a render that quietly moved to different hardware is one
whose timing and cost the user cannot explain.

`GpuRenderBackend` marks almost every failure `elsewhere=True`: driver resets,
lost contexts, exhausted memory and shader failures all say something about the
card and nothing about the timeline.

## Validating on Windows

```powershell
cd "D:\Voice to Video"
.\.venv\Scripts\Activate.ps1

pip install moderngl

# 1. Does the device initialise and draw a matching calibration frame?
python -c "from vtv.adapters.render.gpu_probe import describe; print(describe())"

# 2. The acceptance test: every layer type, every transition, every alpha case.
python -m unittest tests.test_painter_equivalence -v

# 3. Is it actually faster, and on what kind of content?
python scripts\bench_gpu_renderer.py
python scripts\bench_gpu_renderer.py --resolution 4k
```

Step 2 is the one that matters. Until it passes, this is unverified code.

Expected shape of step 3 on a machine where the card wins:

```
gpu        : GPU compositing available: NVIDIA ... via opengl
calibration: worst channel difference 1

correctness
  27 scenes match (worst channel difference 1)

composition (96 frames per workload)
  workload         CPU fps   GPU fps   speedup  verdict
  typography          26.1      27.4     1.05x  CPU (tie or slower)
  images              18.3      74.2     4.05x  GPU
  transitions          9.4      61.8     6.57x  GPU
  mixed               15.7      48.1     3.06x  GPU
```

Those numbers are an **illustration of the format, not a prediction**. Nothing
in this repository has measured a GPU.

## Known limitations

1. **Never executed.** No graphics device was reachable from the build
   environment.
2. **The animation engine is still CPU.** Charts, diagrams and typography are
   rasterised on the processor and uploaded, so typography-heavy projects gain
   little. Moving primitives onto the card is incremental and does not change
   the `DisplayList` contract.
3. **Encoding is CPU.** By measurement, not oversight.
4. **OpenGL on macOS is deprecated.** Works, capped at 4.1; `wgpu` later.
5. **One device per worker process.** Eight segment workers create eight
   contexts. Whether that is better than fewer workers with more work each is a
   measurement nobody has taken.
6. **No user-facing control yet.** Deliberate: the backend becomes real and
   measured first. Fast/Auto/GPU is exposed after a machine passes steps 2
   and 3.
