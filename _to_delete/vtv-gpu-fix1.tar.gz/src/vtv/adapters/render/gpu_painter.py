"""Compositing frames on the machine's graphics card.

**STATUS: RUN ON REAL HARDWARE ONCE; FOUR DEFECTS FOUND AND FIXED; AWAITING
RE-VERIFICATION.**

First contact was a GTX 1650 (driver 610.88, OpenGL 3.3). Fifteen of the
twenty-three calibration scenes matched the reference; eight did not, and the
pattern in *which* eight was the diagnosis:

| what failed | cause |
|---|---|
| every scene with a plate, label or message | the framebuffer is read bottom-up |
| the one scene whose picture is smaller than the frame | cleared to black, not the theme background |
| the same scene, a nine-pixel band | `paste_fitted` overflows its box; a quad did not |
| both overlay scenes | the reference *replaces* pixels and flattens onto the theme background; a card alpha-composites |

Every failing scene contained something vertically asymmetric and every passing
one was symmetric, which is what a mirrored readback looks like from the
outside. The pixel counts confirmed it to the unit: a plate at y 11..50 in a
180-row frame differed across y 11..169 — itself and its mirror.

All four are fixed. The product still does not offer GPU compositing until the
equivalence run passes: `gpu_probe` reports unavailable, `wiring` registers no
GPU target. See `docs/GPU_RENDERING.md`.

## What the graphics card is actually asked to do

Not everything, and the profile says why. Composition was measured at 77% of
render time, and inside that, **text rasterisation was 0.7%**. The expensive
part was never drawing glyphs; it was moving 1920×1080 buffers around — a
paste, a blend, a channel split, a convert, per frame.

So the split is:

    CPU   layout, text, rounded rectangles, the animation engine
          → rasterised into RGBA tiles, exactly as the reference painter does
    GPU   texture upload, transform and sample, alpha-over, the transition mix

That is deliberately lopsided, and it buys two things. The expensive work moves
to hardware built for it. And **the parts that must match the reference exactly
are still produced by the reference**: a glyph is rasterised by PIL on both
paths, so a caption cannot land a pixel high on one of them. Reimplementing
text on a card would be a font-rendering project whose output could never sit
inside a two-per-channel tolerance.

## The honest consequence

A typography-heavy video will not get much faster. Its frames are produced by
the animation engine on the processor and then uploaded, and the upload is new
work. An image-heavy video — photographs with camera moves, dissolves between
them — is where the transform and the compositing dominate and the card wins.

That is a measurement to be made per project, not a claim. `calibration.better`
already refuses to switch backends for less than a ten percent gain, and
`scripts/bench_gpu_renderer.py` is what produces the number.

## Why OpenGL 3.3 through moderngl

Chosen after checking what the runtime can actually carry, which is the part of
this decision people skip.

* **It runs where the customer is.** OpenGL 3.3 is available on every Windows
  machine with a driver from the last decade — NVIDIA, AMD and Intel alike —
  and `moderngl` creates a standalone context with no window and no display.
* **It is a small dependency.** One C++ extension and a pip wheel, not a
  runtime, a toolchain or a vendor SDK.
* **It is not CUDA.** Nothing here is NVIDIA-specific. A machine with an AMD or
  Intel card runs the same shaders.
* **The seam is one file.** `Painter` is the port; swapping to `wgpu` — which
  maps onto D3D12, Vulkan and Metal, and is the better long-term answer once
  its Python bindings settle — replaces this module and nothing else.

The known cost of that choice: macOS has deprecated OpenGL and caps it at 4.1.
It still works, and a Metal path through `wgpu` is the eventual answer there.
"""

from __future__ import annotations

from typing import Any

from PIL import Image

from vtv.animation.painter import (  # the reference implementation
    _base,
    _draw_over,
    _message,
)
from vtv.animation.theme import Theme
from vtv.contracts.display import (
    Background,
    DisplayList,
    Drawn,
    Fit,
    Message,
    Mix,
    Picture,
)


def _has_raster(frame: DisplayList) -> bool:
    """Whether any of this frame is full-frame buffer work worth a card."""
    if frame.beneath is not None and frame.transition is not Mix.NONE:
        return True
    return any(
        isinstance(layer, Picture | Drawn | Background) for layer in frame.layers
    )

#: Minimum OpenGL this needs. 3.3 core gives sampler objects, instancing and
#: GLSL 330 — everything below — and is the floor every desktop driver since
#: about 2010 clears.
REQUIRE_GL = 330

#: Draws a textured quad into the framebuffer, blending alpha-over.
#:
#: The quad's corners come from the layer's box, so the *transform* — Ken
#: Burns, a pan, a zoom, a crop — is expressed as vertex positions rather than
#: as a resampled buffer. That is the operation this whole module exists for:
#: on the processor it is a LANCZOS resize and a paste of several megabytes,
#: and here it is four vertices and the sampler.
_VERTEX = """
#version 330
in vec2 position;
in vec2 uv;
out vec2 texcoord;
void main() {
    texcoord = uv;
    gl_Position = vec4(position, 0.0, 1.0);
}
"""

_FRAGMENT = """
#version 330
uniform sampler2D source;
uniform float opacity;
in vec2 texcoord;
out vec4 colour;
void main() {
    vec4 texel = texture(source, texcoord);
    colour = vec4(texel.rgb, texel.a * opacity);
}
"""

#: Mixes two full frames. One shader for all three transitions, because they
#: differ only in how the mix factor varies across the frame — which keeps the
#: timing curve and the geometry in one place instead of three.
_MIX_FRAGMENT = """
#version 330
uniform sampler2D under;
uniform sampler2D over;
uniform float progress;
uniform int kind;      // 0 blend, 1 wipe, 2 push
uniform float feather; // wipe edge softness, in texture units
in vec2 texcoord;
out vec4 colour;

void main() {
    if (kind == 1) {
        // A vertical edge travelling left to right, softened so it does not
        // alias into a staircase on diagonal content.
        float edge = smoothstep(
            progress - feather, progress + feather, texcoord.x
        );
        colour = mix(texture(over, texcoord), texture(under, texcoord), edge);
    } else if (kind == 2) {
        // Both frames move: the incoming one slides in from the right and
        // shoves the outgoing one off to the left. That is what separates a
        // push from a slide-over.
        vec2 outgoing = vec2(texcoord.x + progress, texcoord.y);
        vec2 incoming = vec2(texcoord.x + progress - 1.0, texcoord.y);
        colour = texcoord.x < 1.0 - progress
            ? texture(under, outgoing)
            : texture(over, incoming);
    } else {
        colour = mix(texture(under, texcoord), texture(over, texcoord), progress);
    }
}
"""


def _quad(box: tuple[float, float, float, float], width: int, height: int) -> tuple:
    """A layer's box as clip-space vertices.

    OpenGL's clip space is -1..1 with y upward; a display list's box is pixels
    with y downward. Getting this inversion wrong produces a picture that is
    correct and upside down, which is exactly the class of mistake the
    equivalence harness exists to catch on the first run.
    """
    x0, y0, x1, y1 = box
    left = (x0 / width) * 2.0 - 1.0
    right = (x1 / width) * 2.0 - 1.0
    top = 1.0 - (y0 / height) * 2.0
    bottom = 1.0 - (y1 / height) * 2.0
    return (
        left, bottom, 0.0, 1.0,
        right, bottom, 1.0, 1.0,
        left, top, 0.0, 0.0,
        right, top, 1.0, 0.0,
    )


def _fitted_box(
    source: tuple[int, int],
    box: tuple[float, float, float, float],
    *,
    cover: bool,
) -> tuple[float, float, float, float]:
    """Where `Canvas.paste_fitted` actually puts a picture.

    Not the same rectangle as the box, and the difference is not a rounding
    detail. `paste_fitted` scales the source to cover (or fit) the box, centres
    it, and then **clamps the origin to the box's own corner** — so a source
    whose aspect ratio differs from the box overflows one edge instead of being
    cropped symmetrically.

    Drawing a quad at the box instead produced a nine-pixel band along the
    bottom of every contained picture on the calibration run. Reproducing the
    arithmetic here, rather than "fixing" it in either painter, is the only
    option that keeps one reference: the CPU path is what customers' videos
    already look like.
    """
    x0, y0, x1, y1 = int(box[0]), int(box[1]), int(box[2]), int(box[3])
    target_w, target_h = max(1, x1 - x0), max(1, y1 - y0)
    source_w, source_h = source
    scale = (
        max(target_w / source_w, target_h / source_h)
        if cover
        else min(target_w / source_w, target_h / source_h)
    )
    width = max(1, int(source_w * scale))
    height = max(1, int(source_h * scale))
    left = max(x0, x0 + (target_w - width) // 2)
    top = max(y0, y0 + (target_h - height) // 2)
    return (float(left), float(top), float(left + width), float(top + height))


class GpuPainter:
    """`Painter` on the graphics card. Unverified — see the module docstring."""

    name = "gpu"

    def __init__(
        self,
        *,
        theme: Theme,
        engine: object,
        size: object,
        stills: Any,
    ) -> None:
        import moderngl
        import numpy

        self.theme = theme
        self.engine = engine
        self.size = size
        self.stills = stills
        self._numpy = numpy
        self.width = int(getattr(size, "width", theme.width))
        self.height = int(getattr(size, "height", theme.height))

        self.ctx = moderngl.create_context(standalone=True, require=REQUIRE_GL)
        self.ctx.enable(moderngl.BLEND)
        self.ctx.blend_func = moderngl.SRC_ALPHA, moderngl.ONE_MINUS_SRC_ALPHA
        self._program = self.ctx.program(
            vertex_shader=_VERTEX, fragment_shader=_FRAGMENT
        )
        self._mixer = self.ctx.program(
            vertex_shader=_VERTEX, fragment_shader=_MIX_FRAGMENT
        )
        self._target = self.ctx.simple_framebuffer((self.width, self.height), 4)
        #: Uploaded stills, by layer key. Cleared by `release` between segments
        #: so a long video does not hold every photograph it has ever shown.
        self._textures: dict[str, Any] = {}
        self._memo: dict[str, Image.Image] = {}
        #: The reference painter, for frames with no full-frame work in them.
        #: Built lazily because most frames never need it.
        self._cpu: Any = None

    # -- Painter ----------------------------------------------------------

    def paint(self, frame: DisplayList) -> Image.Image:
        if frame.key and frame.key in self._memo:
            return self._memo[frame.key]

        # Nothing here for a graphics card.
        #
        # A frame made only of plates, labels, a message or a vignette is
        # rasterisation the reference already does, and there is no full-frame
        # buffer work to move. Handing it to the CPU painter is not a fallback
        # — it is the correct implementation, and it removes an entire class of
        # divergence: the reference composites overlays by *replacing* pixels
        # and then flattening onto the theme background, which is not what
        # alpha-over on a card does. Reimplementing that semantic in a shader
        # would be reimplementing a PIL quirk, and it would drift.
        if not _has_raster(frame):
            return self._reference().paint(frame)

        if frame.beneath is not None and frame.transition is not Mix.NONE:
            under = self.paint(frame.beneath)
            over = self.paint(
                DisplayList(
                    width=frame.width, height=frame.height, layers=frame.layers
                )
            )
            painted = self._mix(under, over, frame.transition, frame.progress)
        else:
            painted = self._draw(frame.layers)

        if frame.overlays:
            # Drawn by the reference, onto the finished picture. The frame has
            # to come back from the card for the encoder anyway, so this costs
            # nothing extra — and it is the only way the plate ends up composited
            # against the same thing on both paths.
            painted = _draw_over(painted, frame.overlays, self.theme)

        if frame.key:
            self._memo[frame.key] = painted
        return painted

    def release(self) -> None:
        """Drop per-segment resources, keeping the device and the pipelines."""
        for texture in self._textures.values():
            with _quiet():
                texture.release()
        self._textures.clear()
        self._memo.clear()
        if self._cpu is not None:
            self._cpu.release()

    def close(self) -> None:
        """Drop the device itself. Called when a worker is finished."""
        self.release()
        for item in (self._target, self._program, self._mixer, self.ctx):
            with _quiet():
                item.release()

    # -- drawing ----------------------------------------------------------

    def _clear(self) -> None:
        """Start from the theme background, which is what the reference does.

        `CpuPainter` begins every frame with `Canvas(theme)`, and a `Canvas` is
        filled with `theme.background`. Clearing to black instead is invisible
        whenever a picture covers the whole frame and obvious the moment one
        does not: on the calibration run it accounted for 18 432 of the 20 736
        differing pixels in the one scene where the picture is smaller than the
        frame.
        """
        self._target.use()
        self._target.clear(*(channel / 255.0 for channel in self.theme.background))

    def _draw(self, layers: tuple) -> Image.Image:
        self._clear()
        vector: list[object] = []
        for layer in layers:
            if isinstance(layer, Background):
                self._target.clear(*[c / 255.0 for c in layer.colour])
            elif isinstance(layer, Picture):
                texture = self._texture_for(layer.key)
                self._blit(
                    texture,
                    _fitted_box(
                        texture.size, layer.box, cover=layer.fit is Fit.COVER
                    ),
                )
            elif isinstance(layer, Drawn | Message):
                # Produced by the reference implementation and uploaded. The
                # animation engine is the same code on both paths, which is
                # what keeps a chart identical rather than merely similar.
                image = _base(
                    layer,
                    theme=self.theme,
                    engine=self.engine,
                    size=self.size,
                    stills=self.stills,
                )
                self._blit(self._upload(image.convert("RGBA")), _full(self))
            else:
                vector.append(layer)
        painted = self._read()
        if vector:
            painted = _draw_over(painted, tuple(vector), self.theme)
        return painted

    def _blit(self, texture: Any, box: tuple) -> None:
        import moderngl

        buffer = self.ctx.buffer(
            self._numpy.array(
                _quad(box, self.width, self.height), dtype="f4"
            ).tobytes()
        )
        array = self.ctx.vertex_array(
            self._program, [(buffer, "2f 2f", "position", "uv")]
        )
        texture.use(0)
        self._program["source"].value = 0
        self._program["opacity"].value = 1.0
        array.render(moderngl.TRIANGLE_STRIP)
        array.release()
        buffer.release()

    def _mix(
        self, under: Image.Image, over: Image.Image, kind: Mix, progress: float
    ) -> Image.Image:
        import moderngl

        self._clear()
        first = self._upload(under.convert("RGBA"))
        second = self._upload(over.convert("RGBA"))
        buffer = self.ctx.buffer(
            self._numpy.array(
                _quad(_full(self), self.width, self.height), dtype="f4"
            ).tobytes()
        )
        array = self.ctx.vertex_array(
            self._mixer, [(buffer, "2f 2f", "position", "uv")]
        )
        first.use(0)
        second.use(1)
        self._mixer["under"].value = 0
        self._mixer["over"].value = 1
        self._mixer["progress"].value = float(progress)
        self._mixer["kind"].value = {Mix.WIPE: 1, Mix.PUSH: 2}.get(kind, 0)
        # Matches the reference's soft margin: width // 96, in texture units.
        self._mixer["feather"].value = max(2.0, self.width / 96.0) / self.width
        array.render(moderngl.TRIANGLE_STRIP)
        array.release()
        buffer.release()
        first.release()
        second.release()
        return self._read()

    # -- device -----------------------------------------------------------

    def _reference(self) -> Any:
        """A CPU painter sharing this one's theme, engine and stills."""
        from vtv.animation.painter import CpuPainter

        if getattr(self, "_cpu", None) is None:
            self._cpu = CpuPainter(
                theme=self.theme, engine=self.engine, size=self.size,
                stills=self.stills,
            )
        return self._cpu

    def _texture_for(self, key: str) -> Any:
        texture = self._textures.get(key)
        if texture is None:
            still = self.stills(key)
            image = (
                still.convert("RGBA")
                if still is not None
                else _message(self.theme, "Visual unavailable").convert("RGBA")
            )
            texture = self._upload(image, keep=True)
            self._textures[key] = texture
        return texture

    def _upload(self, image: Image.Image, *, keep: bool = False) -> Any:
        import moderngl

        texture = self.ctx.texture(image.size, 4, image.tobytes())
        texture.filter = (moderngl.LINEAR, moderngl.LINEAR)
        texture.repeat_x = texture.repeat_y = False
        del keep
        return texture

    def _read(self) -> Image.Image:
        """Pull the framebuffer back as a PIL image, the right way up.

        ## The bug this line exists to fix

        OpenGL's framebuffer origin is the **bottom** left; PIL's is the top.
        `glReadPixels` therefore returns the last row of the picture first, and
        handing that straight to `Image.frombytes` produces a frame that is
        vertically mirrored.

        It was invisible in almost every check, which is what made it dangerous.
        A GTX 1650 ran the twenty-three calibration scenes and eight failed —
        and every single failing scene contained something vertically
        asymmetric (a caption plate at the top, a line of text, a message card)
        while every passing one was symmetric (a flat background, a centred
        vignette, a full-frame picture, a horizontal wipe). The arithmetic
        confirmed it exactly: a plate at y 11..50 in a 180-pixel frame produced
        differences spanning y 11..169, which is that plate and its mirror at
        y 130..169 and nothing in between.

        Textures do *not* need the same treatment. `glTexImage2D` maps the first
        row of data to t=0, and `_quad` puts t=0 at the top of the screen, so an
        uploaded PIL image already lands the right way up.
        """
        raw = Image.frombytes(
            "RGBA", (self.width, self.height), self._target.read(components=4)
        )
        return raw.transpose(Image.Transpose.FLIP_TOP_BOTTOM).convert("RGB")


def _full(painter: GpuPainter) -> tuple[float, float, float, float]:
    return (0.0, 0.0, float(painter.width), float(painter.height))


class _quiet:
    """Swallow release errors. A device teardown must never fail a render."""

    def __enter__(self) -> None:
        return None

    def __exit__(self, *exc: object) -> bool:
        return True


def inspect_device() -> Any:
    """Initialise a device, draw a calibration frame, compare it to the CPU.

    Called by `gpu_probe.probe`. Returns a `GpuReport`, and reports
    `available=True` only when a real frame came back matching the reference —
    hardware being present is not a capability, and a driver that initialises
    and draws the *wrong* picture is worse than one that refuses.
    """
    from vtv.adapters.render.gpu_probe import GpuReport
    from vtv.animation.engine import AnimationEngine, RenderSize
    from vtv.animation.equivalence import check, summarise
    from vtv.animation.painter import CpuPainter
    from vtv.contracts.style import StyleProfile

    try:
        import moderngl  # noqa: F401
    except ImportError:
        return GpuReport(
            available=False,
            reason=(
                "no GPU graphics library is installed. "
                "Install it with: pip install moderngl"
            ),
        )

    width, height = 320, 180
    theme = Theme.from_style(StyleProfile(), width=width, height=height)
    size = RenderSize(width, height)
    engine = AnimationEngine(StyleProfile())

    def blank(_key: str) -> Image.Image:
        return Image.new("RGB", (200, 120), (90, 120, 200))

    painter = GpuPainter(theme=theme, engine=engine, size=size, stills=blank)
    try:
        info = dict(painter.ctx.info)
        differences = check(
            CpuPainter(theme=theme, engine=engine, size=size, stills=blank),
            painter,
            width=width,
            height=height,
        )
        worst = max((d.worst for d in differences), default=255)
        failed = [d for d in differences if not d.ok]
        return GpuReport(
            available=not failed,
            reason="" if not failed else summarise(differences),
            vendor=str(info.get("GL_VENDOR", "")),
            device=str(info.get("GL_RENDERER", "")),
            driver=str(info.get("GL_VERSION", "")),
            api="opengl",
            max_texture=info.get("GL_MAX_TEXTURE_SIZE"),
            calibration_difference=worst,
        )
    finally:
        painter.close()


__all__ = ["REQUIRE_GL", "GpuPainter", "inspect_device"]
