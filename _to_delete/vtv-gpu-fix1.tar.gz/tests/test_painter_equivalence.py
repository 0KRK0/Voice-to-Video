"""The comparison that will decide whether a GPU painter is trustworthy.

## Why the harness is tested before the thing it tests

Because a comparison that cannot fail proves nothing, and one that fails on
correct work is worse than none. Before this is pointed at a graphics card it
is pointed at two deliberately-wrong painters — one that shifts a plate by two
pixels, one that omits an overlay entirely — and it has to catch both. Then it
is pointed at two instances of the CPU painter, and it has to pass.

That ordering matters. "The GPU painter passed the equivalence check" is only
information if the check has been shown to discriminate.

## What first contact with real hardware found

A GTX 1650 ran the twenty-three scenes and eight failed. The *pattern* was the
diagnosis: every failing scene contained something vertically asymmetric — a
plate near the top, a line of text, a message card — and every passing one was
symmetric. That is what a mirrored framebuffer readback looks like from
outside, and the arithmetic confirmed it exactly (a plate at y 11..50 differing
across y 11..169: itself and its mirror).

Three more followed from the numbers: a black clear colour where the reference
starts from the theme background, a picture placed at its box rather than where
`paste_fitted` actually puts it, and overlays alpha-composited on the card where
the reference replaces pixels and flattens onto the theme background.

The classifier below exists so the *next* round is data rather than pattern
recognition, and it is tested the same way the harness is: by injecting each
defect it claims to name.
"""

from __future__ import annotations

import unittest
from dataclasses import dataclass
from pathlib import Path
from tempfile import TemporaryDirectory

from PIL import Image

from vtv.animation.canvas import Canvas
from vtv.animation.equivalence import (
    MAX_OUTLIERS,
    TOLERANCE,
    check,
    classify,
    compare,
    measure,
    scenes,
    summarise,
)
from vtv.animation.engine import AnimationEngine, RenderSize
from vtv.animation.painter import CpuPainter
from vtv.animation.theme import Theme
from vtv.contracts.display import DisplayList, Label, Plate
from vtv.contracts.style import StyleProfile

WIDTH, HEIGHT = 480, 270


def theme() -> Theme:
    return Theme.from_style(StyleProfile(), width=WIDTH, height=HEIGHT)


def still(_key: str) -> Image.Image:
    """A picture with structure in it.

    Flat colour would make a wrong transform invisible — a crop of grey is grey
    wherever it was taken from. Bands and a corner block mean a shifted or
    mirrored box changes the pixels.
    """
    image = Image.new("RGB", (600, 400), (40, 60, 110))
    draw = Canvas(theme()).draw.__class__(image)
    for index in range(0, 600, 40):
        draw.rectangle([index, 0, index + 20, 400], fill=(200, 120, 40))
    draw.rectangle([0, 0, 120, 90], fill=(240, 240, 250))
    return image


def cpu_painter() -> CpuPainter:
    return CpuPainter(
        theme=theme(),
        engine=AnimationEngine(StyleProfile()),
        size=RenderSize(WIDTH, HEIGHT),
        stills=still,
    )


@dataclass
class Sabotaged:
    """A painter that is wrong in one specific, plausible way.

    Both failures modelled here are real ones this project has shipped: a plate
    in slightly the wrong place, and an overlay that goes missing during a
    transition. If the harness cannot see them it cannot see anything.
    """

    inner: CpuPainter
    shift: float = 0.0
    drop_overlays: bool = False
    name: str = "sabotaged"

    def paint(self, frame: DisplayList) -> Image.Image:
        layers = tuple(self._move(layer) for layer in frame.layers)
        overlays = () if self.drop_overlays else tuple(
            self._move(layer) for layer in frame.overlays
        )
        return self.inner.paint(
            DisplayList(
                width=frame.width,
                height=frame.height,
                layers=layers,
                overlays=overlays,
                beneath=frame.beneath,
                transition=frame.transition,
                progress=frame.progress,
            )
        )

    def _move(self, layer: object) -> object:
        if not self.shift:
            return layer
        if isinstance(layer, Plate):
            x0, y0, x1, y1 = layer.box
            return Plate(
                box=(x0 + self.shift, y0, x1 + self.shift, y1),
                radius=layer.radius,
                fill=layer.fill,
                outline=layer.outline,
                outline_width=layer.outline_width,
            )
        if isinstance(layer, Label):
            x, y = layer.position
            return Label(
                text=layer.text,
                role=layer.role,
                position=(x + self.shift, y),
                colour=layer.colour,
                anchor=layer.anchor,
            )
        return layer

    def release(self) -> None:
        self.inner.release()


class TheHarnessCatchesRealMistakes(unittest.TestCase):
    """Tested before it is trusted. A comparison that cannot fail is decoration."""

    def test_a_two_pixel_shift_is_caught(self) -> None:
        """The failure a mean-difference check would launder: everything is
        almost right, on every frame, forever."""
        differences = check(
            cpu_painter(),
            Sabotaged(inner=cpu_painter(), shift=2.0),
            width=WIDTH,
            height=HEIGHT,
        )
        self.assertTrue(
            [d for d in differences if not d.ok],
            f"a two-pixel shift went unnoticed: {summarise(differences)}",
        )

    def test_a_dropped_overlay_is_caught(self) -> None:
        differences = check(
            cpu_painter(),
            Sabotaged(inner=cpu_painter(), drop_overlays=True),
            width=WIDTH,
            height=HEIGHT,
        )
        failed = {d.scene for d in differences if not d.ok}
        self.assertIn("overlay-over-picture", failed)
        self.assertIn("overlay-during-blend", failed)

    def test_a_painter_that_raises_is_a_failure_not_a_crash(self) -> None:
        """A port under development throws. The harness has to survive that and
        say which scene did it, or the first hour of the port is spent finding
        out which scene did it."""

        class Broken:
            name = "broken"

            def paint(self, frame: DisplayList) -> Image.Image:
                raise RuntimeError("shader compilation failed")

            def release(self) -> None:
                return

        differences = check(
            cpu_painter(), Broken(), width=WIDTH, height=HEIGHT
        )
        self.assertTrue(all(not d.ok for d in differences))
        self.assertIn("shader compilation failed", differences[0].scene)

    def test_different_sizes_are_a_failure_not_an_exception(self) -> None:
        one = Image.new("RGB", (10, 10))
        two = Image.new("RGB", (20, 20))
        self.assertFalse(compare(one, two, scene="mismatched").ok)


class TheDiagnosisNamesTheRightCause(unittest.TestCase):
    """The classifier is tested the same way the harness was: by injecting each
    defect it claims to recognise and checking it says so.

    Its whole value is turning "eight scenes differ" into "the framebuffer is
    read bottom-up" without a round trip. A classifier that guessed would cost
    more than no classifier, because it would send somebody to fix the wrong
    thing — and every one of these defects has actually occurred.
    """

    def frame(self) -> Image.Image:
        """Deliberately asymmetric, or a flip is invisible."""
        image = Image.new("RGB", (320, 180), (11, 13, 16))
        Canvas(theme()).draw.__class__(image).rectangle(
            [19, 11, 134, 50], fill=(90, 120, 200)
        )
        return image

    def test_a_mirrored_frame_is_named_as_one(self) -> None:
        """The defect a real GTX 1650 hit on first contact: OpenGL reads the
        framebuffer bottom-up and PIL expects top-down."""
        base = self.frame()
        found = classify(base, base.transpose(Image.Transpose.FLIP_TOP_BOTTOM))
        self.assertTrue(any("vertical flip" in item for item in found), found)

    def test_a_one_pixel_shift_is_named_as_one(self) -> None:
        from PIL import ImageChops

        base = self.frame()
        found = classify(base, ImageChops.offset(base, 1, 0))
        self.assertTrue(any("translation" in item for item in found), found)

    def test_a_wrong_clear_colour_is_named_as_one(self) -> None:
        """A constant difference everywhere is a background, not geometry."""
        from PIL import ImageChops

        base = self.frame()
        shifted = ImageChops.add(base, Image.new("RGB", (320, 180), (9, 9, 9)))
        found = classify(base, shifted)
        self.assertTrue(any("uniform offset" in item for item in found), found)

    def test_identical_frames_are_not_given_a_cause(self) -> None:
        """It must not invent one. A classifier that always has an answer is a
        classifier nobody can act on."""
        base = self.frame()
        self.assertEqual(classify(base, base), ["unclassified: see the diff image"])

    def test_the_measurements_are_the_ones_a_report_needs(self) -> None:
        base = self.frame()
        keys = set(measure(base, base))
        self.assertEqual(
            keys,
            {
                "dimensions",
                "max_per_channel",
                "pixels_outside_tolerance",
                "mean_absolute_difference",
                "bounding_box",
            },
        )


class TheHarnessPassesCorrectWork(unittest.TestCase):
    """The other half. A check that rejects a correct implementation for being
    a different correct implementation is a check nobody will keep."""

    def test_the_reference_painter_matches_itself(self) -> None:
        differences = check(
            cpu_painter(), cpu_painter(), width=WIDTH, height=HEIGHT
        )
        self.assertTrue(
            all(d.ok for d in differences), summarise(differences)
        )
        self.assertEqual(max(d.worst for d in differences), 0)

    def test_every_layer_type_and_transition_is_covered(self) -> None:
        """The suite is the claim. A comparison over one plain frame would pass
        a painter that handles nothing else."""
        names = set(scenes(WIDTH, HEIGHT))
        for required in (
            "background", "message", "picture", "picture-zoomed",
            "picture-panned", "plate-filled", "plate-outlined", "text",
            "vignette", "overlay-over-picture", "overlay-during-blend",
        ):
            self.assertIn(required, names)
        for kind in ("blend", "wipe", "push"):
            for point in (0, 50, 100):
                self.assertIn(f"{kind}-{point}", names)

    def test_the_tolerance_is_tight_and_admits_no_outliers(self) -> None:
        """Documented as a test because both halves matter and the second is
        the one that stops a subtle error passing."""
        self.assertLessEqual(TOLERANCE, 2)
        self.assertEqual(MAX_OUTLIERS, 0)


class TheGpuIsNotClaimedWithoutEvidence(unittest.TestCase):
    """Hardware being present is not a capability, and neither is code existing."""

    def setUp(self) -> None:
        from vtv.adapters.render import gpu_probe

        gpu_probe.forget()

    def test_this_environment_reports_no_gpu_and_says_why(self) -> None:
        from vtv.adapters.render.gpu_probe import probe

        found = probe()
        if found.available:
            self.skipTest("this machine has a usable GPU; see the equivalence run")
        self.assertFalse(found.available)
        self.assertTrue(found.reason, "unavailable with no reason is unactionable")

    def test_the_probe_never_raises(self) -> None:
        """It runs before every render that might use a card. A probe that
        throws takes down the render it exists to protect."""
        from vtv.adapters.render.gpu_probe import forget, probe

        forget()
        probe()
        forget()
        probe()

    def test_disabling_it_is_honoured_before_anything_is_loaded(self) -> None:
        import os

        from vtv.adapters.render.gpu_probe import DISABLE, forget, probe

        forget()
        os.environ[DISABLE] = "1"
        try:
            found = probe()
            self.assertFalse(found.available)
            self.assertIn(DISABLE, found.reason)
        finally:
            del os.environ[DISABLE]
            forget()

    def test_no_gpu_backend_is_registered_without_a_working_device(self) -> None:
        """The Phase A rule, applied to the thing Phase B2 adds: a target with
        no working backend is never offered."""
        from vtv.config import Settings
        from vtv.contracts.execution import ExecutionTarget
        from vtv.wiring import execution_registry

        registry = execution_registry(Settings(asset_search_endpoint=""))
        for target in registry.ready():
            if target.processor.value == "gpu":
                from vtv.adapters.render.gpu_probe import probe

                self.assertTrue(
                    probe().available,
                    "a GPU target was registered without a proven device",
                )
        del ExecutionTarget


@unittest.skipUnless(
    __import__(
        "vtv.adapters.render.gpu_probe", fromlist=["probe"]
    ).probe().available,
    "no usable GPU on this machine",
)
class TheGpuPainterMatchesTheReference(unittest.TestCase):
    """The acceptance test for Phase B2, run wherever there is a card.

    Skipped in the container this was written in, which has no graphics device
    and no way to obtain a graphics library. That is not a soft pass: until
    this runs somewhere with a GPU, the GPU painter is implemented and
    unverified, and the product does not offer it.
    """

    def test_every_scene_matches_within_tolerance(self) -> None:
        from vtv.adapters.render.gpu_painter import GpuPainter

        with TemporaryDirectory():
            gpu = GpuPainter(
                theme=theme(),
                engine=AnimationEngine(StyleProfile()),
                size=RenderSize(WIDTH, HEIGHT),
                stills=still,
            )
            try:
                differences = check(
                    cpu_painter(), gpu, width=WIDTH, height=HEIGHT
                )
            finally:
                gpu.release()
        self.assertTrue(all(d.ok for d in differences), summarise(differences))


if __name__ == "__main__":  # pragma: no cover
    unittest.main()
