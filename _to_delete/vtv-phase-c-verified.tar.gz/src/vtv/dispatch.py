"""Offering render work to a customer's own computers.

## The one job kind a device may run

`render_timeline`, and only that. Not `render_recording`, which transcribes,
plans visuals, searches for assets and calls three providers before it draws
anything — every one of those needs a credential, and a credential on somebody's
desktop is a credential in a coffee shop.

So the split is: **the server decides what the video should be, the device draws
it.** By the time a job is offered here, every AI call has been made, every asset
has been acquired and paid for, and what is left is a resolved `Timeline` and
some pixels. That is the part worth moving to hardware the customer already owns,
and it is also the only part that is safe to move.

## Why the timeline is not in the queue payload

A queue row is not a blob store — the same reason `RenderPayload` carries a
storage key instead of the audio. A four-hour video's timeline is megabytes of
JSON, and putting it in the row would mean every claim, every retry and every
status poll dragging it through the database. The payload names the project; the
timeline is read from the document store at claim time, once, by the one caller
that needs it.

## Why claiming goes through the queue rather than around it

Because the queue already does the hard parts — atomic claim, heartbeats,
stale-claim recovery — and it does them correctly. A device is a worker that
happens to be on the other side of the internet, so a closed laptop is recovered
by exactly the rule that recovers a killed process. Building a second lease table
here would be building a second thing to get wrong.
"""

from __future__ import annotations

import contextlib
import hashlib
from dataclasses import dataclass
from datetime import timedelta
from typing import Any

from vtv.contracts.base import ObjectRef, utc_now
from vtv.contracts.devices import (
    LEASE_TTL_SECONDS,
    AssetHandout,
    Assignment,
    Completion,
    Device,
    DeviceState,
    JobLease,
    ProgressReport,
)
from vtv.contracts.errors import (
    ErrorCategory,
    ErrorCode,
    ErrorInfo,
    NotFound,
    PolicyViolation,
)

#: The queue kind a device is allowed to claim. One entry, and the allow-list is
#: the point: a device asks for "work", and this is the only thing that word can
#: mean for it.
DEVICE_KIND = "render_timeline"

#: How long a signed asset URL lives. Long enough for a slow domestic connection
#: to pull a few hundred megabytes, short enough that a URL captured from a log
#: is worthless by the time anybody reads it.
ASSET_URL_SECONDS = 3600

#: Ceiling on an uploaded render, so a signed upload URL cannot be used to push
#: arbitrary amounts of data into a customer's bucket.
MAX_UPLOAD_BYTES = 8 * 1024 * 1024 * 1024


def worker_id_for(device: Device | str) -> str:
    """How a device names itself to the queue.

    Prefixed, so a glance at `claimed_by` says whether a job is running in the
    cloud or on somebody's desk — which is the first thing anybody wants to know
    when a render is slow.
    """
    identifier = device if isinstance(device, str) else device.device_id
    return f"device:{identifier}"


@dataclass
class DevicePool:
    """The server's half of local execution.

    Everything a device is allowed to do passes through here, and every method
    takes the device rather than trusting an id in the request body. A device
    that could name another device in a payload would be a device that can steal
    or sabotage its neighbour's job.
    """

    queue: Any
    repository: Any
    storage: Any
    directory: Any

    # -- putting work up --------------------------------------------------

    async def offer(
        self,
        *,
        project_id: str,
        organisation_id: str,
        render_job_id: str,
        settings: Any,
    ) -> str:
        """Queue a render for whichever of this tenant's computers takes it.

        ## Why this refuses when no device could take it

        A job queued for hardware that does not exist is a render that never
        happens and never fails — it sits pending, the customer watches a
        spinner, and nothing in the system is wrong enough to alert anybody.
        Refusing here turns that into an error at the moment somebody asked,
        with a sentence saying what to do about it.

        "Could take it" means paired, not revoked, and seen recently. A computer
        that was switched off last week is not capacity.
        """
        available = [
            device
            for device in self.directory.devices_for(organisation_id)
            if device.is_active and device.state() is not DeviceState.OFFLINE
        ]
        if not available:
            # `user_message` explicitly, because that is the field that reaches
            # the browser: a `PolicyViolation` carries a class-level "We could
            # not use that material under its licence", and a customer who
            # simply had not started their desktop app was being told their
            # footage was unlicensed. The internal message and the one a person
            # reads are different strings and only one of them is shown.
            raise PolicyViolation(
                f"no available device for organisation {organisation_id}",
                user_message=(
                    "No computer on this account is available to render right "
                    "now. Start the desktop app on one of them, or render in "
                    "the cloud."
                ),
            )

        handle = await self.queue.enqueue(
            kind=DEVICE_KIND,
            payload={
                "project_id": project_id,
                "organisation_id": organisation_id,
                "render_job_id": render_job_id,
                "settings": settings.model_dump(mode="json"),
            },
            # Keyed by the render job, so a customer pressing the button twice
            # gets one render. The queue enforces it with a unique index rather
            # than a pre-flight check, so two requests racing both survive.
            idempotency_key=f"device-render:{render_job_id}",
        )
        return getattr(handle, "job_id", str(handle))

    def capacity(self, organisation_id: str) -> dict[str, Any]:
        """What this tenant could render on right now.

        For the picker in Phase D, and for an honest answer to "why is 'this
        device' greyed out". Reports what is actually there rather than what was
        paired at some point.
        """
        devices = [
            device
            for device in self.directory.devices_for(organisation_id)
            if device.is_active
        ]
        online = [
            device for device in devices if device.state() is not DeviceState.OFFLINE
        ]
        return {
            "paired": len(devices),
            "available": len(online),
            "accelerated": sum(
                1 for device in online if device.hardware.gpu_verified
            ),
            "devices": [
                {
                    "device_id": device.device_id,
                    "name": device.name,
                    "state": device.state().value,
                    "summary": device.hardware.summary,
                }
                for device in devices
            ],
        }

    # -- offering work -----------------------------------------------------

    async def claim(self, device: Device) -> Assignment | None:
        """Lease one job for this device, or `None` when there is nothing.

        A device with no verified graphics card is not refused work — it renders
        on its processor, which is what the per-segment router would have chosen
        for most of a typography-heavy video anyway. Hardware decides *how* a
        job is drawn, not *whether* this machine may draw one.
        """
        if not device.is_active:
            raise PolicyViolation(
                f"device {device.device_id} is revoked",
                user_message="This computer is no longer paired with that account.",
            )

        # Reap abandoned claims before asking for work.
        #
        # `recover()` is otherwise called only by the cloud worker's maintenance
        # loop, and the entire premise of local execution is a deployment that
        # runs no cloud worker at all. Without this, a device that was killed
        # mid-render holds its job until somebody restarts the API — the job is
        # neither running nor available, the customer watches a spinner, and
        # nothing in the system is broken enough to say so.
        #
        # On the claim path specifically, because that is the moment somebody
        # wants the work: a device asking for a job is the natural trigger for
        # noticing that a job is going spare. It costs one indexed UPDATE.
        with contextlib.suppress(Exception):
            await self.queue.recover()

        worker = worker_id_for(device)
        claimed = await self.queue.lease(worker_id=worker, kinds=(DEVICE_KIND,))
        if claimed is None:
            return None

        try:
            return await self._assignment(device, claimed)
        except Exception as exc:
            # The job is already claimed at this point. Handing it straight back
            # rather than leaving it to the lease timeout matters: a project
            # whose timeline cannot be loaded would otherwise be claimed,
            # abandoned and re-claimed by every device in the account, five
            # minutes apart, forever.
            await self.queue.surrender(
                claimed.job_id,
                worker,
                ErrorInfo(
                    code=ErrorCode.INTERNAL_ERROR,
                    category=ErrorCategory.INTERNAL,
                    message=f"could not prepare the assignment: {exc}"[:400],
                ),
                retry=True,
            )
            raise

    async def _assignment(self, device: Device, claimed: Any) -> Assignment:
        payload = dict(claimed.payload)
        organisation_id = str(payload.get("organisation_id") or "")
        project_id = str(payload.get("project_id") or "")

        # The tenant check, at the one place a device is handed content. A
        # device belongs to exactly one organisation and may never be given a
        # job from another; this is that rule, and it is a single comparison on
        # purpose so it can be read and audited.
        if not organisation_id or organisation_id != device.organisation_id:
            raise PolicyViolation(
                f"job for {organisation_id!r} offered to a device in "
                f"{device.organisation_id!r}",
                user_message="That job is not available to this computer.",
            )

        from vtv.contracts.render import RenderSettings
        from vtv.contracts.timeline import Timeline

        document = await self.repository.get_document(
            project_id=project_id, kind=Timeline.document_name
        )
        if document is None:
            raise NotFound(f"no timeline stored for {project_id}")
        timeline = Timeline.model_validate(document)
        settings = RenderSettings.model_validate(payload.get("settings") or {})

        now = utc_now()
        return Assignment(
            render_job_id=str(payload.get("render_job_id") or claimed.job_id),
            project_id=project_id,
            organisation_id=organisation_id,
            timeline=timeline,
            settings=settings,
            assets=tuple(await self._handouts(timeline)),
            upload_url=await self._upload_url(payload, organisation_id, project_id),
            lease=JobLease(
                render_job_id=str(payload.get("render_job_id") or claimed.job_id),
                device_id=device.device_id,
                organisation_id=organisation_id,
                granted_at=now,
                expires_at=now + timedelta(seconds=LEASE_TTL_SECONDS),
            ),
        )

    async def _handouts(self, timeline: Any) -> list[AssetHandout]:
        """A signed, expiring URL for each object this job draws from.

        Exactly the objects this timeline names, and no prefix or wildcard. A
        device is given the ability to read four photographs, not the ability to
        read the bucket those photographs are in.
        """
        from vtv.contracts.timeline import AssetClipSource

        seen: dict[str, ObjectRef] = {}
        for clip in timeline.clips:
            source = clip.source
            if isinstance(source, AssetClipSource) and source.object is not None:
                seen.setdefault(source.object.key, source.object)
        narration = getattr(timeline.narration, "audio", None)
        if narration is not None:
            seen.setdefault(narration.key, narration)

        handouts: list[AssetHandout] = []
        for ref in seen.values():
            digest = ref.checksum_sha256 or self._digest(ref)
            if not digest:
                # A device that cannot verify an asset must not draw from it: an
                # unverifiable download is how a truncated photograph becomes a
                # grey band in a finished video. Skipping is the safe answer —
                # the renderer describes a missing asset as a message card,
                # which is visible and honest, where a corrupt one is neither.
                continue
            handouts.append(
                AssetHandout(
                    object=ref,
                    url=await self.storage.signed_url(
                        ref, expires_in_seconds=ASSET_URL_SECONDS
                    ),
                    sha256=digest,
                    size_bytes=ref.size_bytes or 0,
                )
            )
        return handouts

    def _digest(self, ref: ObjectRef) -> str:
        """Hash an object that was stored before checksums were recorded."""
        try:
            path = self.storage.path_for(ref)
        except Exception:
            return ""
        if not path.exists():
            return ""
        hasher = hashlib.sha256()
        with path.open("rb") as handle:
            while chunk := handle.read(1024 * 1024):
                hasher.update(chunk)
        return hasher.hexdigest()

    async def _upload_url(
        self, payload: dict[str, Any], organisation_id: str, project_id: str
    ) -> str:
        """Write-only, single-object, expiring, size-capped.

        Four separate limits because each removes a different thing a leaked URL
        could be used for: reading other renders, overwriting a different
        object, working next week, and filling the bucket.
        """
        from vtv.security.paths import safe_storage_key

        render_job_id = str(payload.get("render_job_id") or "")
        key = safe_storage_key(
            f"orgs/{organisation_id}/projects/{project_id}/renders/{render_job_id}.mp4"
        )
        try:
            return await self.storage.signed_upload_url(
                key=key,
                content_type="video/mp4",
                expires_in_seconds=ASSET_URL_SECONDS,
                max_bytes=MAX_UPLOAD_BYTES,
            )
        except Exception:
            # A storage backend without signed uploads is a deployment where
            # devices cannot return their output. Better an empty string the
            # executor treats as "nowhere to upload" than a fabricated URL.
            return ""

    # -- while it works ----------------------------------------------------

    async def progress(self, device: Device, report: ProgressReport) -> bool:
        """Record progress and renew the lease. True if cancellation is wanted.

        ## Why the device does not say which job it is reporting on

        It says, and it is not believed. The row that gets renewed is *the one
        this device holds*, looked up from the claim — so a device physically
        cannot renew, steal or fail another machine's job, and there is no
        comparison anybody has to remember to write.

        The first version addressed the row by the `render_job_id` in the body,
        which was wrong twice over. It trusted a caller-supplied identifier, and
        it did not even work: a render job id and the queue's job id are
        different identifiers, so every renewal silently updated nothing and
        every lease expired mid-render while the device reported progress into
        the void. The tests caught it because they let a lease actually run out
        rather than assuming it would not.
        """
        if report.device_id != device.device_id:
            raise PolicyViolation(
                "a device reported on work belonging to another device",
                user_message="That job is not available to this computer.",
            )
        worker = worker_id_for(device)
        held = await self.queue.held_by(worker)
        if held is None:
            return False
        return await self.queue.renew(held, worker)

    async def complete(self, device: Device, completion: Completion) -> bool:
        """Settle a job a device has finished with. False if the claim was lost.

        A lost claim is not an error and not a lie to the device: it means the
        lease expired while the machine was drawing and somebody else has the
        job now. The right thing is to discard this outcome, which the queue
        already does by guarding its write on `claimed_by`.
        """
        if completion.device_id != device.device_id:
            raise PolicyViolation(
                "a device completed work belonging to another device",
                user_message="That job is not available to this computer.",
            )

        worker = worker_id_for(device)
        # The job this device holds, not the one it names. See `progress`.
        held = await self.queue.held_by(worker)
        if held is None:
            return False
        if completion.ok:
            return await self.queue.settle(held, worker)
        return await self.queue.surrender(
            held,
            worker,
            ErrorInfo(
                code=ErrorCode.RENDER_FAILED,
                # `elsewhere` decides the category, which decides whether the
                # queue retries: the device is the only thing that knows whether
                # its failure was about this machine or about this job.
                #
                # `VALIDATION` for the terminal case specifically because it is
                # in `TERMINAL_CATEGORIES` — the same set the executor uses to
                # decide `elsewhere` in the first place, so the two ends of this
                # decision cannot drift apart.
                category=(
                    ErrorCategory.INTERNAL if completion.elsewhere
                    else ErrorCategory.VALIDATION
                ),
                message=completion.reason or "the device could not render this",
            ),
            retry=completion.elsewhere,
        )


__all__ = [
    "ASSET_URL_SECONDS",
    "DEVICE_KIND",
    "MAX_UPLOAD_BYTES",
    "DevicePool",
    "worker_id_for",
]
