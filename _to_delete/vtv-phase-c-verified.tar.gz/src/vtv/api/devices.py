"""The HTTP surface for a customer's own computers.

Eight endpoints in two groups, and the split between them is the security story.

**Three are administrative** — create a pairing code, list the computers on an
account, revoke one — and need `DEVICE_MANAGE`, which only admins and owners
hold. Deciding which machines an organisation's material may be sent to is an
administrative act, not an editorial one.

**One is unauthenticated on purpose.** `/pair` is where a computer that has no
credential gets one; requiring a credential to obtain a credential is a circle.
The pairing code *is* the authentication, which is why it is single-use, expires
in minutes, and is rate limited harder than anything else here.

**Four are for devices**, and every one of them resolves the device from the
bearer token and then ignores any device id in the body. A payload that could
name a device would be a payload that lets one machine renew, steal or fail
another's job.

## Why the failures are uniform

Every bad pairing attempt returns the same refusal — no such code, expired,
already used, wrong organisation, all identical. Distinguishing them tells
somebody guessing which guess was closest. The person with a real problem is
better served by generating another code, which takes two seconds, than by an
error message that also helps an attacker.
"""

from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any

from starlette.requests import Request
from starlette.responses import JSONResponse, Response
from starlette.routing import Route

from vtv.contracts.devices import Completion, DeviceHardware, ProgressReport
from vtv.contracts.errors import VTVError
from vtv.contracts.tenancy import Capability, Principal
from vtv.security.devices import format_code, mint_pairing_code
from vtv.security.limits import RateLimitPolicy, limit_key

#: Pairing is the one unauthenticated write in this file, so it gets the
#: tightest budget in the system. Six characters of code is about 29 bits: at
#: ten attempts a minute, guessing one inside its ten-minute life is not an
#: attack anybody completes, and this is what makes that true.
PAIR_LIMIT = RateLimitPolicy(rate_per_second=0.2, burst=10)

#: Polling is frequent and cheap and must not be throttled into uselessness — a
#: device asking every five seconds is the design, not abuse.
DEVICE_LIMIT = RateLimitPolicy(rate_per_second=10.0, burst=60)


def routes(
    *,
    guard: Callable[..., Principal],
    owned_project: Callable[[Request, Principal], Awaitable[Any]],
    json_body: Callable[[Request], Awaitable[dict[str, Any]]],
    client_ip: Callable[[Request], str],
    assembly: Any,
    pool: Any,
) -> list[Route]:
    """Build the device routes over the application's existing plumbing.

    Dependencies passed in rather than imported, for the same reason as the
    product routes: this module must not be able to acquire its own
    authentication or its own rate limiter, because those are the two things
    that have to have exactly one implementation.
    """
    directory = assembly.directory

    def _device(request: Request) -> Any:
        """Resolve the bearer token into a device, or refuse.

        The single place a device identity comes from. Everything downstream
        takes the `Device` object this returns and never an identifier out of a
        request body — that is the difference between a device acting for itself
        and a device nominating whose work it is touching.
        """
        header = request.headers.get("authorization") or ""
        scheme, _, credential = header.partition(" ")
        if scheme.lower() != "bearer" or not credential.strip():
            raise VTVError("a device token is required")
        assembly.limiter.require(
            limit_key("device", client_ip(request)), policy=DEVICE_LIMIT
        )
        _, device = directory.authenticate_device(credential.strip())
        return device

    # -- administrative ---------------------------------------------------

    async def create_code(request: Request) -> Response:
        """Mint a pairing code for somebody to type into their computer."""
        principal = guard(request, Capability.DEVICE_MANAGE)
        code = directory.create_pairing_code(
            mint_pairing_code(
                organisation_id=principal.organisation_id or "",
                created_by=principal.subject,
            )
        )
        return JSONResponse(
            {
                # Shown grouped, because it is going to be read off a screen and
                # typed into another one, and possibly read aloud.
                "code": format_code(code.code),
                "expires_at": code.expires_at.isoformat(),
                "instructions": (
                    "On the computer you want to render on, run:  "
                    f"vtv-desktop pair --code {format_code(code.code)} "
                    "--server <this server>"
                ),
            },
            status_code=201,
        )

    async def list_devices(request: Request) -> Response:
        principal = guard(request, Capability.DEVICE_MANAGE)
        found = directory.devices_for(principal.organisation_id or "")
        return JSONResponse({"devices": [_view(device) for device in found]})

    async def revoke(request: Request) -> Response:
        principal = guard(request, Capability.DEVICE_MANAGE)
        device_id = request.path_params["device_id"]
        existing = directory.device(device_id)
        # Checked before revoking, so revoking a device id from another tenant
        # is a not-found rather than a successful cross-tenant write.
        if existing is None or not principal.owns(existing.organisation_id):
            return JSONResponse({"error": "no such device"}, status_code=404)
        return JSONResponse(_view(directory.revoke_device(device_id)))

    # -- pairing ----------------------------------------------------------

    async def pair(request: Request) -> Response:
        """Turn a typed code into a device token. The only unauthenticated write.

        Rate limited by address rather than by tenant, because there is no tenant
        yet — that is what the code is for — and an unauthenticated endpoint with
        no per-caller budget is an endpoint somebody enumerates.
        """
        assembly.limiter.require(
            limit_key("pair", client_ip(request)), policy=PAIR_LIMIT
        )
        body = await json_body(request)
        hardware = DeviceHardware.model_validate(body.get("hardware") or {})
        minted = directory.redeem_pairing_code(
            str(body.get("code") or ""),
            name=str(body.get("name") or "").strip() or "A computer",
            hardware=hardware,
        )
        return JSONResponse(
            {
                "device_id": minted.record.device_id,
                # The only moment this value exists outside the desktop. Never
                # returned again, never logged, never recoverable from the
                # database — a lost token means pairing again.
                "token": minted.secret,
                "name": minted.record.name,
                "organisation_id": minted.record.organisation_id,
            },
            status_code=201,
        )

    # -- putting work up --------------------------------------------------

    async def offer(request: Request) -> Response:
        """Queue a render for this tenant's own computers.

        `RENDER_SUBMIT` and not `DEVICE_MANAGE`: choosing *where* a render runs
        is an editorial decision an editor makes every time they press the
        button, while deciding *which computers exist* is administrative. The
        two are separated because the same person often is not both.

        ## Why the project is in the path and not the body

        Because `owned_project` — the one place that decides whether this
        caller's tenant owns this project — reads it from `path_params`. A body
        parameter meant either a `KeyError` or a second, private ownership check
        living here, and a multi-tenant system with two implementations of "may
        you touch this" has one of them wrong.

        The first version took it in the body and raised `KeyError` on the very
        first real request. Nothing in the unit tests could see it: they call
        `DevicePool.offer` directly, which is the right level for what they
        test and is below the layer that was broken.
        """
        principal = guard(request, Capability.RENDER_SUBMIT)
        body = await json_body(request)
        project = await owned_project(request, principal)  # reads the path param
        if project is None:
            return JSONResponse({"error": "no such project"}, status_code=404)

        from vtv.contracts.base import IdPrefix, new_id
        from vtv.contracts.render import RenderSettings

        render_job_id = new_id(IdPrefix.RENDER_JOB)
        job_id = await pool.offer(
            project_id=project.project_id,
            organisation_id=principal.organisation_id or "",
            render_job_id=render_job_id,
            settings=RenderSettings.model_validate(body.get("settings") or {}),
        )
        return JSONResponse(
            {"render_job_id": render_job_id, "job_id": job_id}, status_code=202
        )

    async def capacity(request: Request) -> Response:
        """What this account could render on right now.

        Read with `PROJECT_READ` rather than `DEVICE_MANAGE`, because an editor
        deciding where to render needs to know whether "this device" is even an
        option — and greying out a button with no explanation is the thing this
        endpoint exists to prevent.
        """
        principal = guard(request, Capability.PROJECT_READ)
        return JSONResponse(pool.capacity(principal.organisation_id or ""))

    # -- the device's own endpoints ---------------------------------------

    async def announce(request: Request) -> Response:
        """A device saying it is alive and what it currently has."""
        device = _device(request)
        body = await json_body(request)
        hardware = DeviceHardware.model_validate(body.get("hardware") or {})
        updated = directory.touch_device(device.device_id, hardware=hardware)
        return JSONResponse(_view(updated))

    async def claim(request: Request) -> Response:
        """Ask for work. 204 means there is none, which is the common answer."""
        device = _device(request)
        body = await json_body(request)
        if body.get("hardware"):
            # Re-read on every claim, not just at pairing: a driver update or an
            # undocked laptop must change what this machine is offered on its
            # next poll, and pairing happens once.
            device = directory.touch_device(
                device.device_id,
                hardware=DeviceHardware.model_validate(body["hardware"]),
            )
        else:
            device = directory.touch_device(device.device_id)

        assignment = await pool.claim(device)
        if assignment is None:
            return Response(status_code=204)
        return JSONResponse(assignment.model_dump(mode="json"))

    async def progress(request: Request) -> Response:
        device = _device(request)
        report = ProgressReport.model_validate(await json_body(request))
        directory.touch_device(device.device_id)
        cancelled = await pool.progress(device, report)
        # The response is how a cancellation reaches a running device: it is
        # already talking to us every few seconds, so a separate channel would
        # be a second connection to keep alive for a message that fits here.
        return JSONResponse({"cancelled": bool(cancelled)})

    async def complete(request: Request) -> Response:
        device = _device(request)
        completion = Completion.model_validate(await json_body(request))
        directory.touch_device(device.device_id)
        settled = await pool.complete(device, completion)
        # `accepted: false` is not an error. It means the lease expired while
        # this machine was drawing and the job belongs to somebody else now —
        # the device did nothing wrong and there is nothing for it to retry.
        return JSONResponse({"accepted": bool(settled)})

    return [
        Route("/v1/devices/codes", create_code, methods=["POST"]),
        Route("/v1/devices", list_devices, methods=["GET"]),
        Route("/v1/devices/{device_id}", revoke, methods=["DELETE"]),
        Route("/v1/devices/pair", pair, methods=["POST"]),
        Route("/v1/devices/capacity", capacity, methods=["GET"]),
        # A project route, deliberately: it is the same shape as every other
        # "do something to this project" endpoint, and it is what lets the one
        # tenancy check in the application apply to it unchanged.
        Route(
            "/v1/projects/{project_id}/render/device", offer, methods=["POST"]
        ),
        Route("/v1/devices/announce", announce, methods=["POST"]),
        Route("/v1/devices/claim", claim, methods=["POST"]),
        Route("/v1/devices/progress", progress, methods=["POST"]),
        Route("/v1/devices/complete", complete, methods=["POST"]),
    ]


def _view(device: Any) -> dict[str, Any]:
    """A device as the UI sees it. No token, no digest, not even the prefix's tail."""
    return {
        "device_id": device.device_id,
        "name": device.name,
        "state": device.state().value,
        "hardware": {
            "summary": device.hardware.summary,
            "platform": device.hardware.platform,
            "cpu_cores": device.hardware.cpu_cores,
            "memory_mb": device.hardware.memory_mb,
            "gpu_name": device.hardware.gpu_name,
            "gpu_verified": device.hardware.gpu_verified,
            # Carried through so the UI can answer "why isn't my card being
            # used" without anybody reading a log on the customer's machine.
            "gpu_reason": device.hardware.gpu_reason,
            "targets": [target.value for target in device.hardware.targets],
        },
        "prefix": device.prefix,
        "paired_at": device.paired_at.isoformat() if device.paired_at else None,
        "last_seen_at": (
            device.last_seen_at.isoformat() if device.last_seen_at else None
        ),
    }


__all__ = ["DEVICE_LIMIT", "PAIR_LIMIT", "routes"]
