"""P1-7 — deletion removes the bytes, and retention is a plan, not a constant.

Two audit findings, tested together because they are the same operation:

* **`delete_project` removed the rows and left the files.** A customer told
  their project was gone still had it — the video, the narration audio, the
  fetched assets. That is a compliance failure before it is a storage bill,
  because GDPR Article 17 is about the data and not the index.
* **`Plan.max_retention_days` was never read.** It existed on all five plans,
  documented as the thing that stops storage cost growing without bound, and no
  code consulted it. A free trial and an enterprise contract expired on one
  global `temporary_retention_hours`.

The interesting tests here are the ones about interruption. Deletion cannot be
atomic across two stores, so the design chooses *which* half-finished state to
leave behind, and these assert that choice rather than pretending it does not
exist.
"""

from __future__ import annotations

import asyncio
import unittest
from datetime import timedelta
from pathlib import Path
from tempfile import TemporaryDirectory

from vtv.adapters.repository.sqlite import SqliteProjectRepository
from vtv.adapters.storage.local import LocalStorageProvider
from vtv.contracts.base import utc_now
from vtv.contracts.errors import PolicyViolation
from vtv.contracts.project import PersistenceMode, Project
from vtv.contracts.tenancy import PlanTier
from vtv.retention import RetentionService, expiry_for, retention_for
from vtv.security.paths import project_prefix, tenant_key

ORG_A = "org_" + "a" * 24
ORG_B = "org_" + "b" * 24


def run(coro):  # type: ignore[no-untyped-def]
    return asyncio.run(coro)


class RetentionTestCase(unittest.TestCase):
    def setUp(self) -> None:
        self._dir = TemporaryDirectory(prefix="vtv-retention-")
        root = Path(self._dir.name)
        self.storage = LocalStorageProvider(root / "storage")
        self.repository = SqliteProjectRepository(root / "vtv.db")
        self.service = RetentionService(
            repository=self.repository, storage=self.storage
        )

    def tearDown(self) -> None:
        self._dir.cleanup()

    def project(
        self,
        organisation_id: str = ORG_A,
        *,
        expires_in_hours: float | None = None,
    ) -> Project:
        project = Project(
            organisation_id=organisation_id,
            title="a project",
            persistence=PersistenceMode.TEMPORARY,
        )
        if expires_in_hours is not None:
            project.expires_at = utc_now() + timedelta(hours=expires_in_hours)
        run(self.repository.save_project(project))
        return project

    def artefacts(self, project: Project, count: int = 4) -> list[str]:
        """The spread of objects a real render leaves behind."""
        keys = [
            tenant_key(
                project.organisation_id, "projects", project.project_id, *parts
            )
            for parts in (
                ("recordings", "a.webm"),
                ("narration", "b.wav"),
                ("assets", "c.jpg"),
                ("renders", "d.mp4"),
            )[:count]
        ]
        for key in keys:
            run(self.storage.put(key=key, data=b"x" * 32, content_type="video/mp4"))
        return keys

    def files_under(self, organisation_id: str, project_id: str) -> list[Path]:
        bucket = self.storage.root / self.storage.bucket
        root = bucket / project_prefix(organisation_id, project_id)
        return [path for path in root.rglob("*") if path.is_file()]


class DeletionRemovesTheBytes(RetentionTestCase):
    def test_every_artefact_goes_not_just_the_row(self) -> None:
        """The finding, stated as a test."""
        project = self.project()
        self.artefacts(project)
        self.assertEqual(len(self.files_under(ORG_A, project.project_id)), 4)

        report = run(
            self.service.delete_project(
                organisation_id=ORG_A, project_id=project.project_id
            )
        )

        self.assertEqual(report.objects_deleted, 4)
        self.assertEqual(report.records_deleted, 1)
        self.assertEqual(self.files_under(ORG_A, project.project_id), [])
        self.assertIsNone(
            run(
                self.repository.get_project(
                    project.project_id, organisation_id=ORG_A
                )
            )
        )

    def test_the_directory_itself_is_removed(self) -> None:
        """Directory names are data: they say which projects existed."""
        project = self.project()
        self.artefacts(project)
        run(
            self.service.delete_project(
                organisation_id=ORG_A, project_id=project.project_id
            )
        )
        bucket = self.storage.root / self.storage.bucket
        self.assertFalse(
            (bucket / project_prefix(ORG_A, project.project_id)).exists()
        )

    def test_another_tenants_project_is_untouched(self) -> None:
        mine = self.project(ORG_A)
        theirs = self.project(ORG_B)
        self.artefacts(mine)
        self.artefacts(theirs)

        run(
            self.service.delete_project(
                organisation_id=ORG_A, project_id=mine.project_id
            )
        )

        self.assertEqual(len(self.files_under(ORG_B, theirs.project_id)), 4)
        self.assertIsNotNone(
            run(
                self.repository.get_project(
                    theirs.project_id, organisation_id=ORG_B
                )
            )
        )

    def test_deleting_with_the_wrong_tenant_removes_nothing(self) -> None:
        """The scope is in the operation, not in a check before it."""
        project = self.project(ORG_A)
        self.artefacts(project)

        report = run(
            self.service.delete_project(
                organisation_id=ORG_B, project_id=project.project_id
            )
        )

        self.assertEqual(report.records_deleted, 0)
        self.assertTrue(report.already_absent)
        self.assertEqual(len(self.files_under(ORG_A, project.project_id)), 4)

    def test_deleting_twice_is_not_an_error(self) -> None:
        """A retried job and a user double-clicking land in the same place."""
        project = self.project()
        self.artefacts(project)
        first = run(
            self.service.delete_project(
                organisation_id=ORG_A, project_id=project.project_id
            )
        )
        second = run(
            self.service.delete_project(
                organisation_id=ORG_A, project_id=project.project_id
            )
        )
        self.assertTrue(first.is_complete)
        self.assertTrue(second.is_complete)
        self.assertTrue(second.already_absent)
        self.assertEqual(second.objects_deleted, 0)

    def test_a_project_with_no_artefacts_deletes_cleanly(self) -> None:
        project = self.project()
        report = run(
            self.service.delete_project(
                organisation_id=ORG_A, project_id=project.project_id
            )
        )
        self.assertEqual(report.objects_deleted, 0)
        self.assertEqual(report.records_deleted, 1)


class AnInterruptedDeletionIsRecoverable(RetentionTestCase):
    """Deletion spans two stores, so it can be interrupted. Which half first?

    Database first leaves objects nothing knows about: invisible, unbilled,
    removable only by a full-bucket scan. That is a permanent leak.

    Storage first leaves a row pointing at nothing: visibly broken, found again
    by the next sweep, and completable. Strictly better, so that is the order.
    """

    def test_orphaned_objects_are_reclaimed_by_a_later_pass(self) -> None:
        """The state a crash *after* the storage half leaves."""
        project = self.project()
        self.artefacts(project)
        run(self.repository.delete_project(project.project_id, organisation_id=ORG_A))

        report = run(
            self.service.delete_project(
                organisation_id=ORG_A, project_id=project.project_id
            )
        )
        self.assertTrue(report.already_absent)
        self.assertEqual(report.objects_deleted, 4)
        self.assertEqual(self.files_under(ORG_A, project.project_id), [])

    def test_the_orphan_sweep_respects_age(self) -> None:
        """A freshly written object belongs to a render still in flight."""
        project = self.project()
        self.artefacts(project)

        kept = run(
            self.service.sweep_orphans(
                organisation_id=ORG_A, older_than_seconds=3600.0
            )
        )
        self.assertEqual(kept, [])
        self.assertEqual(len(self.files_under(ORG_A, project.project_id)), 4)

        swept = run(
            self.service.sweep_orphans(organisation_id=ORG_A, older_than_seconds=0.0)
        )
        self.assertEqual(len(swept), 4)

    def test_the_orphan_sweep_stays_inside_one_tenant(self) -> None:
        mine = self.project(ORG_A)
        theirs = self.project(ORG_B)
        self.artefacts(mine)
        self.artefacts(theirs)

        run(self.service.sweep_orphans(organisation_id=ORG_A, older_than_seconds=0.0))

        self.assertEqual(len(self.files_under(ORG_B, theirs.project_id)), 4)


class TheSweepIsTenantScoped(RetentionTestCase):
    def test_only_expired_projects_go(self) -> None:
        expired = self.project(expires_in_hours=-1)
        alive = self.project(expires_in_hours=+24)
        self.artefacts(expired)
        self.artefacts(alive)

        reports = run(self.service.sweep(organisation_id=ORG_A))

        self.assertEqual([r.project_id for r in reports], [expired.project_id])
        self.assertEqual(self.files_under(ORG_A, expired.project_id), [])
        self.assertEqual(len(self.files_under(ORG_A, alive.project_id)), 4)

    def test_another_tenants_expired_project_is_not_swept(self) -> None:
        """The `/internal/sweep` defect, at the layer below the route."""
        mine = self.project(ORG_A, expires_in_hours=-1)
        theirs = self.project(ORG_B, expires_in_hours=-1)
        self.artefacts(mine)
        self.artefacts(theirs)

        run(self.service.sweep(organisation_id=ORG_A))

        self.assertEqual(len(self.files_under(ORG_B, theirs.project_id)), 4)

    def test_there_is_no_cross_tenant_sweep_to_call(self) -> None:
        """Not "discouraged" — absent.

        A cross-tenant sweep exists only as a loop in the worker over tenants
        the worker enumerates itself. Making it a parameter is how an endpoint
        acquires the ability to delete every customer's data.
        """
        import inspect

        signature = inspect.signature(RetentionService.sweep)
        parameter = signature.parameters["organisation_id"]
        self.assertIs(parameter.default, inspect.Parameter.empty)
        self.assertEqual(parameter.annotation, "str")


class RetentionComesFromThePlan(unittest.TestCase):
    def test_each_plan_has_its_own_ceiling(self) -> None:
        free = retention_for(PlanTier.FREE)
        enterprise = retention_for(PlanTier.ENTERPRISE)
        self.assertLess(free, enterprise)
        self.assertEqual(free, timedelta(days=7))

    def test_an_unknown_plan_gets_the_most_restrictive_ceiling(self) -> None:
        """Guessing generously would mean an unrecognised tier keeps data
        longest, which is exactly backwards."""
        self.assertEqual(retention_for("not-a-plan"), retention_for(PlanTier.FREE))
        self.assertEqual(retention_for(None), retention_for(PlanTier.FREE))

    def test_a_saved_project_still_hits_the_plan_ceiling(self) -> None:
        """"Saved" meant "never expires", which is unbounded storage cost."""
        now = utc_now()
        project = Project(
            organisation_id=ORG_A, persistence=PersistenceMode.SAVED
        )
        expiry = expiry_for(
            project, tier=PlanTier.FREE, temporary_hours=24, now=now
        )
        self.assertIsNotNone(expiry)
        assert expiry is not None
        self.assertEqual(expiry, now + timedelta(days=7))

    def test_a_temporary_project_expires_sooner_than_the_ceiling(self) -> None:
        now = utc_now()
        project = Project(
            organisation_id=ORG_A, persistence=PersistenceMode.TEMPORARY
        )
        expiry = expiry_for(
            project, tier=PlanTier.ENTERPRISE, temporary_hours=24, now=now
        )
        self.assertEqual(expiry, now + timedelta(hours=24))

    def test_the_plan_ceiling_wins_when_it_is_shorter(self) -> None:
        """A free tenant cannot buy a longer window by asking for one."""
        now = utc_now()
        project = Project(
            organisation_id=ORG_A, persistence=PersistenceMode.TEMPORARY
        )
        expiry = expiry_for(
            project, tier=PlanTier.FREE, temporary_hours=24 * 365, now=now
        )
        self.assertEqual(expiry, now + timedelta(days=7))


class PrefixesAreContained(RetentionTestCase):
    def test_a_prefix_outside_a_tenant_namespace_is_refused(self) -> None:
        for prefix in ("projects/p", "", "..", "orgs"):
            with self.subTest(prefix), self.assertRaises(PolicyViolation):
                run(self.storage.delete_prefix(prefix))

    def test_a_traversal_in_a_tenant_id_is_refused(self) -> None:
        with self.assertRaises(PolicyViolation):
            run(self.storage.delete_prefix("orgs/../../etc"))

    def test_a_missing_prefix_returns_nothing_rather_than_raising(self) -> None:
        self.assertEqual(
            run(self.storage.delete_prefix(project_prefix(ORG_A, "prj_absent"))), []
        )


if __name__ == "__main__":  # pragma: no cover
    unittest.main()
