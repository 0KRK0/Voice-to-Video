"""P1-7 — deletion that actually deletes, and retention that is actually a policy.

Two findings, one module, because they are the same operation seen from two
sides: "remove this project now" and "remove this project when its time is up".

**Deletion was incomplete.** `delete_project` removed the database rows and left
every byte on disk — the rendered video, the narration audio, the fetched
assets. A customer told their project was gone still had it, which is a
compliance failure (GDPR Article 17 is about the data, not the index) before it
is a storage bill.

**Retention was not enforced.** `Plan.max_retention_days` existed on all five
plans, was documented as "a plan that keeps content forever is a plan whose
storage cost grows without bound" — and was **never read**. Expiry came from one
global `temporary_retention_hours`, identical for a free trial and an enterprise
contract.

## The ordering, and why it is the way round it is

Storage first, then the database. Both orders can be interrupted, so the
question is which wreckage is recoverable:

* database first, then storage: the row is gone, so nothing knows the objects
  exist. They are invisible, unbilled, undeletable except by a full-bucket
  scan. That is a permanent leak of customer data.
* storage first, then database: the objects are gone and the row remains,
  pointing at nothing. The project reads as broken, the sweep finds it again on
  the next pass, and the deletion completes. Recoverable, and visibly so.

The second failure mode is strictly better, so deletion is ordered to produce
it. This is the same reasoning as "reserve then settle" in billing: when a
crash is inevitable, choose where it lands.

## Idempotence

Every operation here is safe to repeat. The sweep is a scheduled job with
at-least-once delivery, so it *will* be repeated, and a deletion that throws on
its second run turns a duplicate message into a dead-lettered job and a tenant
whose retention silently stops running.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Any

from vtv.billing.plans import PLANS, Plan
from vtv.contracts.base import utc_now
from vtv.contracts.project import PersistenceMode, Project
from vtv.contracts.tenancy import PlanTier
from vtv.security.paths import project_prefix, tenant_prefix


@dataclass(frozen=True)
class DeletionReport:
    """What a deletion actually removed. Returned rather than logged.

    A caller that cannot see the object count cannot tell "deleted a project
    with no artefacts" from "failed to find the artefacts", and those need
    different responses.
    """

    project_id: str
    objects_deleted: int = 0
    records_deleted: int = 0
    #: Set when the project was already gone. Not an error — a retried job and
    #: a user pressing delete twice both land here — but worth distinguishing.
    already_absent: bool = False

    @property
    def is_complete(self) -> bool:
        return self.already_absent or self.records_deleted > 0


def retention_for(tier: PlanTier | str | None) -> timedelta:
    """How long this plan may keep content.

    The ceiling, not the default. A project can ask for less (a temporary
    project expires in hours); it cannot ask for more, because storage that
    outlives the plan paying for it is unbounded cost with no revenue.
    """
    plan = _plan_for(tier)
    return timedelta(days=plan.max_retention_days)


def expiry_for(
    project: Project,
    *,
    tier: PlanTier | str | None,
    temporary_hours: int,
    now: datetime | None = None,
) -> datetime | None:
    """When this project's content must be gone by.

    `None` means "no expiry from this rule" and is reachable only for a
    persistent project on a plan whose ceiling has not been hit — the ceiling
    always wins, which is the whole point of it being a plan ceiling.
    """
    moment = now or utc_now()
    ceiling = moment + retention_for(tier)

    if project.persistence is PersistenceMode.TEMPORARY:
        # The shorter of the two. A free-tier temporary project expires in
        # hours, not in the plan's seven days.
        return min(moment + timedelta(hours=temporary_hours), ceiling)
    return ceiling


@dataclass
class RetentionService:
    """Deletes projects completely, and on schedule.

    Holds the repository and storage rather than reaching for a global, so a
    test can drive it against temporary files and the worker and the API can
    share exactly one implementation. Before this there were two — one in
    `jobs.run_retention_sweep` and one inline in the API's sweep route — and
    only the API's applied a tenant scope.
    """

    repository: Any
    storage: Any
    #: Fallback window for a project with no plan on record.
    temporary_hours: int = 24
    #: Names the tenant of every operation, so an unscoped call is impossible to
    #: write by accident rather than merely discouraged.
    _seen: set[str] = field(default_factory=set, repr=False)

    async def delete_project(
        self, *, organisation_id: str, project_id: str
    ) -> DeletionReport:
        """Remove one project's bytes and then its records.

        Scoped to a tenant in both halves. The storage prefix contains the
        organisation id, and the repository delete carries it as a query
        parameter, so a caller holding the wrong tenant's identifier removes
        nothing rather than removing something.
        """
        existing = await self.repository.get_project(
            project_id, organisation_id=organisation_id
        )
        if existing is None:
            # Still sweep the prefix. A row can be gone while its objects
            # remain — that is exactly the state an interrupted deletion
            # leaves, and refusing to clean it up would make the interruption
            # permanent.
            removed = await self.storage.delete_prefix(
                project_prefix(organisation_id, project_id)
            )
            return DeletionReport(
                project_id=project_id,
                objects_deleted=len(removed),
                already_absent=True,
            )

        removed = await self.storage.delete_prefix(
            project_prefix(organisation_id, project_id)
        )
        await self.repository.delete_project(
            project_id, organisation_id=organisation_id
        )
        return DeletionReport(
            project_id=project_id,
            objects_deleted=len(removed),
            records_deleted=1,
        )

    async def sweep(
        self,
        *,
        organisation_id: str,
        now: datetime | None = None,
    ) -> list[DeletionReport]:
        """Delete everything of this tenant's that has passed its retention.

        Deliberately tenant-scoped with no "all tenants" option. The
        cross-tenant form is a loop in the worker over organisations the worker
        enumerates itself; making it reachable from here is how an endpoint
        ends up deleting every customer's data, which is the defect the audit
        found in `/internal/sweep`.
        """
        expired = await self.repository.expired_projects(
            now=now or utc_now(), organisation_id=organisation_id
        )
        reports: list[DeletionReport] = []
        for project_id in expired:
            reports.append(
                await self.delete_project(
                    organisation_id=organisation_id, project_id=project_id
                )
            )
        return reports

    async def sweep_orphans(
        self, *, organisation_id: str, older_than_seconds: float
    ) -> list[str]:
        """Remove objects with no project left to own them.

        The second half of "interrupted deletion is recoverable": objects whose
        row is gone are found here, by age, inside this tenant's namespace
        only. Age matters — a freshly written object belongs to a render that
        has not yet saved its project.
        """
        return list(
            await self.storage.sweep_expired(
                older_than_seconds=older_than_seconds,
                prefix=tenant_prefix(organisation_id),
            )
        )


def _plan_for(tier: PlanTier | str | None) -> Plan:
    if isinstance(tier, PlanTier):
        return PLANS[tier]
    if isinstance(tier, str):
        try:
            return PLANS[PlanTier(tier)]
        except ValueError:
            pass
    # Unknown or absent: the most restrictive plan. Guessing generously here
    # would mean an unrecognised tier keeps data the longest, which is exactly
    # backwards.
    return PLANS[PlanTier.FREE]


__all__ = [
    "DeletionReport",
    "RetentionService",
    "expiry_for",
    "retention_for",
]
