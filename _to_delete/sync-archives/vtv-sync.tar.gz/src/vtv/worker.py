"""Stage 27 — the worker process.

`python -m vtv.worker`

This exists because of the audit finding that rendering ran inside the API's
event loop. A thirty-second render stalled every request on that process,
including the health check the load balancer uses to decide whether the process
is alive — so the system's response to load was to be marked unhealthy and
restarted, losing the render.

The split is the fix, and it is deliberately blunt:

* **The API may only enqueue.** It registers no handlers, so it cannot run work
  even by accident. `create_app` no longer imports the renderer.
* **The worker may only consume.** It serves no HTTP.
* **The queue is the only thing they share**, plus the database and object
  store they both address by reference.

Delivery is **at-least-once with idempotent effects**, not exactly-once. A
worker can complete a handler and die before the row is settled, and the job
will be redelivered; that is unavoidable without a distributed transaction
across the queue and the pipeline's side effects. What makes it safe is that
every effect converges: usage settlement is keyed on the render job id, the
output object is addressed by content, and persistence is an upsert.

Shutdown is cooperative. On SIGTERM the loop stops claiming new work and waits
for in-flight jobs, so a rolling deploy drains rather than abandons. A job that
outlives the grace period is left in `running` with a stale heartbeat, and
recovery reclaims it — which is the same path a crash takes, exercised on every
deploy rather than only in an incident.
"""

from __future__ import annotations

import asyncio
import contextlib
import signal
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from vtv.adapters.queue.durable import DurableJobQueue
from vtv.adapters.repository.sqlite import SqliteProjectRepository
from vtv.config import Settings
from vtv.jobs import HANDLERS, JobContext, JobKind, SweepPayload
from vtv.observability.bridge import correlated_log_handler
from vtv.observability.context import correlated
from vtv.observability.events import EventName, configure_logging
from vtv.wiring import Assembly, build, queue_path, repository_path

#: How often the worker asks for work when the queue was empty. Short enough
#: that a user does not notice, long enough that an idle fleet is not a
#: self-inflicted database load test.
IDLE_POLL_SECONDS = 0.25

#: How often abandoned work is reclaimed and expired reservations released.
#: Both are cheap; running them often means a crash costs seconds of quota
#: rather than the reservation TTL.
MAINTENANCE_INTERVAL_SECONDS = 30.0

#: Retention runs on a schedule here rather than behind an HTTP endpoint.
RETENTION_INTERVAL_SECONDS = 3600.0

#: How long a rolling deploy waits for in-flight work before giving up on it.
SHUTDOWN_GRACE_SECONDS = 120.0


@dataclass
class Worker:
    """Claims jobs, runs them, and shuts down without losing any."""

    settings: Settings
    assembly: Assembly
    repository: SqliteProjectRepository
    queue: DurableJobQueue
    concurrency: int = 2
    _stopping: asyncio.Event = field(default_factory=asyncio.Event)
    _running: int = 0

    @classmethod
    def create(
        cls,
        settings: Settings | None = None,
        *,
        assembly: Assembly | None = None,
        concurrency: int = 2,
    ) -> Worker:
        settings = settings or Settings.from_env()
        assembly = assembly or build(settings, log_events=True)
        repository = SqliteProjectRepository(repository_path(settings))
        queue = DurableJobQueue(
            queue_path(settings),
            events=assembly.events,
            max_attempts=3,
            # A render is minutes of work, so the reclaim window has to exceed
            # it or a healthy worker's job is stolen while it is still running.
            reclaim_after_seconds=900.0,
            heartbeat_interval_seconds=15.0,
        )
        worker = cls(
            settings=settings,
            assembly=assembly,
            repository=repository,
            queue=queue,
            concurrency=concurrency,
        )
        worker.register()
        return worker

    # -- registration -----------------------------------------------------

    def register(self) -> None:
        """Bind every job kind to its handler.

        The worker registers all of them. If a deployment should not run a kind
        of work, it runs a worker that does not register it — the queue leaves
        unclaimed kinds visibly waiting in `stats()` rather than failing them.
        """
        context = self.context()
        for kind, handler in HANDLERS.items():
            self.queue.register(kind, _bind(handler, context))

    def context(self) -> JobContext:
        scratch = Path(self.settings.storage_root).parent / "scratch"
        scratch.mkdir(parents=True, exist_ok=True)
        return JobContext(
            assembly=self.assembly,
            repository=self.repository,
            usage=self.assembly.usage,
            audit=self.assembly.audit,
            events=self.assembly.events,
            scratch=scratch,
        )

    # -- lifecycle --------------------------------------------------------

    async def run_forever(self) -> None:
        """The worker's whole life."""
        self.assembly.events.emit(
            EventName.JOB_STARTED,
            project_id=None,
            data={
                "worker_id": self.queue.worker_id,
                "concurrency": self.concurrency,
                "kinds": sorted(HANDLERS),
            },
        )
        # Reclaim anything a previous worker died holding, before taking new
        # work. Doing it first means a crash-restart loop still makes progress.
        recovered, dead = await self.queue.recover()
        if recovered or dead:
            self.assembly.events.emit(
                EventName.JOB_ENQUEUED,
                project_id=None,
                data={"recovered": recovered, "dead_lettered": dead},
            )

        tasks = [
            asyncio.create_task(self._consume(index), name=f"vtv-consumer-{index}")
            for index in range(max(1, self.concurrency))
        ]
        tasks.append(
            asyncio.create_task(
                self._correlated_maintenance(), name="vtv-maintenance"
            )
        )
        tasks.append(asyncio.create_task(self._retention(), name="vtv-retention"))

        try:
            await self._stopping.wait()
        finally:
            deadline = SHUTDOWN_GRACE_SECONDS
            while self._running and deadline > 0:
                await asyncio.sleep(0.5)
                deadline -= 0.5
            for task in tasks:
                task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)

    def stop(self) -> None:
        """Stop claiming. In-flight work is allowed to finish."""
        self._stopping.set()

    async def _consume(self, index: int) -> None:
        worker_id = f"{self.queue.worker_id}#{index}"
        while not self._stopping.is_set():
            try:
                self._running += 1
                claimed = await self.queue.run_once(worker_id=worker_id)
            except asyncio.CancelledError:
                raise
            except Exception as error:
                # A handler that raises is already recorded by the queue. This
                # catches a failure in the claiming machinery itself, which must
                # not take the consumer down with it.
                self.assembly.events.emit(
                    EventName.JOB_FAILED,
                    project_id=None,
                    data={"worker_id": worker_id, "error": type(error).__name__},
                )
                claimed = None
                await asyncio.sleep(1.0)
            finally:
                self._running -= 1

            if claimed is None:
                await asyncio.sleep(IDLE_POLL_SECONDS)

    async def _correlated_maintenance(self) -> None:
        """Maintenance under its own trace.

        Periodic work has no enqueuing request to inherit from, so it gets a
        fresh trace per process. Without one, a reservation expiry that goes
        wrong appears in the logs as an orphan line with nothing to join it to.
        """
        with correlated(job_id=f"maintenance:{self.queue.worker_id}"):
            await self._maintenance()

    async def _maintenance(self) -> None:
        """Reclaim abandoned work and release abandoned quota."""
        while not self._stopping.is_set():
            await asyncio.sleep(MAINTENANCE_INTERVAL_SECONDS)
            with contextlib.suppress(Exception):
                await self.queue.recover()
            with contextlib.suppress(Exception):
                # P0-7. This is the caller `expire_reservations` never had, and
                # its absence meant a crashed render held quota until the TTL.
                released = await asyncio.to_thread(
                    self.assembly.usage.expire_reservations
                )
                if released:
                    self.assembly.events.emit(
                        EventName.JOB_COMPLETED,
                        project_id=None,
                        data={"reservations_released": released},
                    )

    async def _retention(self) -> None:
        """Cross-tenant retention, on a schedule, under a system principal."""
        while not self._stopping.is_set():
            await asyncio.sleep(RETENTION_INTERVAL_SECONDS)
            with contextlib.suppress(Exception):
                await self.queue.enqueue(
                    kind=JobKind.RETENTION_SWEEP.value,
                    payload=SweepPayload(
                        older_than_hours=self.settings.temporary_retention_hours
                    ).model_dump(mode="json"),
                    idempotency_key=None,
                )


def _bind(handler: Any, context: JobContext) -> Any:
    """Turn a two-argument handler into the one-argument shape the queue wants."""

    async def run(payload: dict[str, Any]) -> Any:
        return await handler(context, payload)

    return run


async def main(argv: list[str] | None = None) -> int:
    argv = list(argv if argv is not None else sys.argv[1:])
    concurrency = 2
    for index, item in enumerate(argv):
        if item == "--concurrency" and index + 1 < len(argv):
            concurrency = max(1, int(argv[index + 1]))

    settings = Settings.from_env()
    configure_logging(settings.log_level)
    worker = Worker.create(settings, concurrency=concurrency)
    worker.assembly.events.subscribe(correlated_log_handler())

    loop = asyncio.get_running_loop()
    for received in (signal.SIGTERM, signal.SIGINT):
        with contextlib.suppress(NotImplementedError):
            # Not available on every platform; the worker still runs, it just
            # cannot drain gracefully there.
            loop.add_signal_handler(received, worker.stop)

    await worker.run_forever()
    return 0


def cli() -> None:  # pragma: no cover - process entrypoint
    raise SystemExit(asyncio.run(main()))


if __name__ == "__main__":  # pragma: no cover
    cli()


__all__ = [
    "IDLE_POLL_SECONDS",
    "MAINTENANCE_INTERVAL_SECONDS",
    "RETENTION_INTERVAL_SECONDS",
    "SHUTDOWN_GRACE_SECONDS",
    "Worker",
    "cli",
    "main",
]
