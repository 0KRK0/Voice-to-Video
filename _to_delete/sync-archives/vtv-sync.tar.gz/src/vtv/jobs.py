"""Stage 27 — the work the worker does, defined once.

Before the 2026-08-13 audit these handlers lived as closures inside
`create_app`, which is why rendering happened inside the API's event loop: the
only process that knew how to run a job was the one serving requests. One
thirty-second render stalled every other request on that process, including
health checks.

They live here now because they belong to neither side. The API imports this
module to know the *names* of the job kinds it may enqueue; the worker imports
it to know how to run them. Neither imports the other.

**Payloads are contracts.** A job payload outlives the process that created it —
that is the point of a durable queue — so it is a validated model rather than a
loose dict. A worker running last week's code must be able to reject next week's
payload rather than misread it.

**Handlers are idempotent.** The queue delivers at least once. A handler that is
re-run after a crash must converge on the same result, which is why usage
settlement carries an idempotency key and why the render output key is derived
from the job rather than from the clock.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from pathlib import Path
from typing import Any

from pydantic import Field

from vtv.billing.plans import QuotaKind
from vtv.billing.usage import UsageMeter
from vtv.contracts.base import Id, VTVModel
from vtv.contracts.consistency import VisualBible
from vtv.contracts.errors import ErrorCode, NotFound, Status, VTVError
from vtv.contracts.project import Project
from vtv.contracts.render import RenderQuality, RenderSettings
from vtv.contracts.tenancy import AuditAction, Principal
from vtv.observability.events import EventName, EventSink
from vtv.pipeline.orchestrator import PipelineResult
from vtv.retention import RetentionService
from vtv.security.audit import AuditLog


class JobKind(str, Enum):
    """Every kind of background work. The API may enqueue only these."""

    #: A recording becomes a video.
    RENDER_RECORDING = "render_recording"
    #: A document becomes a video.
    RENDER_DOCUMENT = "render_document"
    #: Cross-tenant retention, run on a schedule by the worker under a system
    #: principal. Deliberately not reachable over HTTP (see `docs/SECURITY.md`).
    RETENTION_SWEEP = "retention_sweep"


class RenderPayload(VTVModel):
    """What a render job needs to run, and nothing else.

    Note the absence of the audio bytes. Large inputs go to object storage and
    the job carries a reference: a queue row is not a blob store, and a payload
    that grows with the upload is a queue that fails on the biggest customer.
    """

    project_id: Id
    organisation_id: Id
    #: Storage key of the uploaded bytes. Durable, so a worker on another
    #: machine can fetch it, which a local temp path would not allow.
    input_key: str = Field(min_length=1, max_length=512)
    input_content_type: str = Field(default="application/octet-stream", max_length=128)
    filename: str | None = Field(default=None, max_length=200)
    language: str | None = Field(default=None, max_length=32)
    quality: RenderQuality = RenderQuality.PREVIEW
    frame_rate: int = Field(default=24, ge=24, le=60)
    #: Set when the API reserved quota up front. The handler settles it.
    reservation_id: str | None = Field(default=None, max_length=64)
    #: Development-only aligner script. Refused in production by the API.
    script: str | None = Field(default=None, max_length=20000)


class SweepPayload(VTVModel):
    """Retention for one tenant, or for all of them when run by the scheduler."""

    organisation_id: Id | None = None
    older_than_hours: float = Field(default=24.0, gt=0)


@dataclass
class JobContext:
    """Everything a handler needs, injected rather than reached for.

    A handler that could reach for a global would be a handler that behaves
    differently in the worker than in a test.
    """

    assembly: Any  # vtv.wiring.Assembly
    repository: Any  # SqliteProjectRepository
    usage: UsageMeter
    audit: AuditLog
    events: EventSink
    scratch: Path


async def _approved_bible(context: JobContext, project: Project) -> VisualBible | None:
    """The Visual Bible an earlier run of this project already approved.

    P1-1. Without this, every render rebuilt the Bible from scratch, so a
    binding a user had *locked* — pressed "keep this" on — was silently
    discarded on the next render. A control that does not survive a re-render
    is not a control.

    A document written by an older schema is ignored rather than fatal: losing
    the continuity of one project is much better than refusing to render it.
    """
    payload = await context.repository.get_document(
        project_id=project.project_id, kind="visual_bible"
    )
    if payload is None:
        return None
    try:
        return VisualBible.model_validate(payload)
    except ValueError:
        return None


async def run_render_recording(context: JobContext, payload: dict[str, Any]) -> str:
    """A recording becomes a video. Runs in the worker, never in the API."""
    job = RenderPayload.model_validate(payload)
    project = await _load_project(context, job)

    audio = await context.assembly.storage.get_by_key(job.input_key)
    if job.script and not context.assembly.settings.is_production:
        context.assembly.register_script_for_key(job.input_key, job.script)

    result = await context.assembly.pipeline.run(
        audio=audio,
        project=project,
        style=project.style,
        visual_bible=await _approved_bible(context, project),
        settings=RenderSettings(
            aspect_ratio=project.style.aspect_ratio,
            quality=job.quality,
            frame_rate=job.frame_rate,
        ),
    )
    await _finish(context, job, result)
    return job.project_id


async def run_render_document(context: JobContext, payload: dict[str, Any]) -> str:
    """A document becomes a video, through the identical downstream path."""
    job = RenderPayload.model_validate(payload)
    project = await _load_project(context, job)

    data = await context.assembly.storage.get_by_key(job.input_key)
    document, _transcript, _document_context = context.assembly.ingestion.ingest(
        data,
        organisation_id=project.organisation_id,
        project_id=project.project_id,
        filename=job.filename,
        origin=job.filename,
        language=job.language,
    )
    result = await context.assembly.pipeline.run_from_document(
        document=document,
        project=project,
        style=project.style,
        visual_bible=await _approved_bible(context, project),
        settings=RenderSettings(
            aspect_ratio=project.style.aspect_ratio,
            quality=job.quality,
            frame_rate=job.frame_rate,
        ),
    )
    await _finish(context, job, result)
    return job.project_id


async def run_retention_sweep(context: JobContext, payload: dict[str, Any]) -> str:
    """Delete what has passed its retention.

    Runs under a system principal in the worker. The HTTP surface has a
    tenant-scoped equivalent; the cross-tenant form lives only here, because an
    unauthenticated endpoint that deletes every tenant's data is precisely the
    defect the audit found.
    """
    job = SweepPayload.model_validate(payload)
    principal = Principal.system("retention-sweep", job.organisation_id)

    # P1-7. One implementation, shared with the API's tenant-scoped route.
    # There used to be two, and only one of them applied a tenant scope.
    service = RetentionService(
        repository=context.repository,
        storage=context.assembly.storage,
    )

    organisations = (
        [job.organisation_id]
        if job.organisation_id
        else context.assembly.directory.active_organisation_ids()
    )

    projects = 0
    objects = 0
    for organisation_id in organisations:
        for report in await service.sweep(organisation_id=organisation_id):
            projects += report.records_deleted
            objects += report.objects_deleted
        objects += len(
            await service.sweep_orphans(
                organisation_id=organisation_id,
                older_than_seconds=job.older_than_hours * 3600,
            )
        )

    context.audit.write(
        action=AuditAction.DATA_DELETED,
        principal=principal,
        organisation_id=job.organisation_id,
        target=f"organisation:{job.organisation_id or 'all'}",
        detail={
            "organisations": str(len(organisations)),
            "projects_deleted": str(projects),
            "objects_deleted": str(objects),
            "trigger": "scheduled",
        },
    )
    return f"{projects}:{objects}"


# ---------------------------------------------------------------------------
# Shared handler plumbing
# ---------------------------------------------------------------------------

def _prefix_for(organisation_id: str | None) -> str | None:
    if organisation_id is None:
        return None
    from vtv.security.paths import tenant_prefix

    return tenant_prefix(organisation_id)


async def _load_project(context: JobContext, job: RenderPayload) -> Project:
    """Load the project, scoped to the tenant named in the payload.

    The scope matters even here. A payload is data, and data can be wrong or
    forged; loading by id alone would let a malformed job touch another
    tenant's project.
    """
    project: Project | None = await context.repository.get_project(
        job.project_id, organisation_id=job.organisation_id
    )
    if project is None:
        raise NotFound(
            f"project {job.project_id} is not available to this tenant",
            code=ErrorCode.ASSET_NOT_FOUND,
        )
    return project


async def _finish(
    context: JobContext, job: RenderPayload, result: PipelineResult
) -> None:
    """Persist everything, settle usage, and drop the input.

    Order matters. Persistence first, because an artifact nobody can find is
    the same as no artifact. Settlement second, keyed so a re-delivered job
    bills once. The input is removed last, and only on success — a retry after
    a crash still needs it.
    """
    await persist_result(context.repository, result)
    _settle(context, job, result)

    if result.succeeded:
        await context.assembly.storage.delete_by_key(job.input_key)

    context.events.emit(
        EventName.JOB_COMPLETED,
        project_id=result.project.project_id,
        data={
            "succeeded": result.succeeded,
            "outcome": result.outcome.value,
            "has_speech": result.narration_has_speech,
            "grounding_refusals": (
                result.gate_outcome.refusals if result.gate_outcome else 0
            ),
        },
    )


def _settle(context: JobContext, job: RenderPayload, result: PipelineResult) -> None:
    if not job.reservation_id:
        return
    render_job = result.render_job
    if render_job is None or render_job.status is not Status.READY:
        # Nothing was delivered, so nothing is charged. Releasing immediately
        # beats waiting for the TTL to reclaim it.
        context.usage.release(job.reservation_id)
        return
    context.usage.settle(
        job.reservation_id,
        actual=round((render_job.duration_seconds or 0.0) / 60.0, 4),
        cost_usd=result.ledger.total_usd if result.ledger else 0.0,
        project_id=result.project.project_id,
        # Derived from the render job, so a re-delivered message settles once.
        idempotency_key=f"render:{result.project.project_id}:{render_job.render_job_id}",
    )
    context.usage.record(
        organisation_id=job.organisation_id,
        kind=QuotaKind.PROVIDER_SPEND_USD,
        quantity=result.ledger.total_usd if result.ledger else 0.0,
        project_id=result.project.project_id,
        idempotency_key=f"spend:{result.project.project_id}:{render_job.render_job_id}",
    )


async def persist_result(repository: Any, result: PipelineResult) -> None:
    """Store every document the run produced.

    This is what makes artifacts survive a restart, and it is why the API can
    serve a video it never rendered. The Visual Bible is included — it was
    omitted before the audit, which is why "re-render reproduces the approved
    video" was not true across processes.
    """
    await repository.save_project(result.project)
    documents = {
        "recording": result.recording,
        "transcript": result.transcript,
        "understanding": result.understanding,
        "scene_graph": result.scene_graph,
        "visual_plan": result.visual_plan,
        "visual_bible": result.visual_bible,
        "source_document": result.source_document,
        "timeline": result.timeline,
        "render_job": result.render_job,
    }
    import json

    for kind, document in documents.items():
        if document is None:
            continue
        await repository.put_document(
            project_id=result.project.project_id,
            kind=kind,
            document_id=getattr(document, f"{kind}_id", kind),
            payload=json.loads(document.model_dump_json()),
        )


#: Job kind to handler. The worker registers exactly this; the API registers
#: nothing, which is what stops it running work by accident.
HANDLERS: dict[str, Any] = {
    JobKind.RENDER_RECORDING.value: run_render_recording,
    JobKind.RENDER_DOCUMENT.value: run_render_document,
    JobKind.RETENTION_SWEEP.value: run_retention_sweep,
}


def unavailable(kind: str) -> VTVError:
    return VTVError(
        f"no handler for job kind {kind!r}",
        code=ErrorCode.INTERNAL_ERROR,
        user_message="That kind of work is not available on this deployment.",
    )


__all__ = [
    "HANDLERS",
    "JobContext",
    "JobKind",
    "RenderPayload",
    "SweepPayload",
    "persist_result",
    "run_render_document",
    "run_render_recording",
    "run_retention_sweep",
    "unavailable",
]
