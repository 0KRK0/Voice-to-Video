"""Stage 10 — Rendering a timeline to MP4 with ffmpeg.

STATUS: **REAL IMPLEMENTATION — RUNS AND PRODUCES A PLAYABLE FILE.**

Composition is a pure function of the timeline and a timestamp. For every frame
time the composer asks the timeline what should be on screen and draws it; no
frame depends on the frame before it, and nothing about the picture is decided
here (Rule 13 — everything drawn was decided upstream).

That purity buys three things it always bought:

* **transitions are free** — a dissolve is two frames blended, not a filter graph;
* **captions and attributions are ours** — drawn with the same type system as
  everything else, rather than handed to a subtitle burner whose fonts and
  metrics we do not control;
* **it cannot desynchronise** — audio is muxed once, and every frame's timestamp
  is derived from the narration clock, so drift has nowhere to enter.

and it now buys two more, because a pure function of a timestamp can be
evaluated out of order and in parallel:

* **a render survives a crash** — frames are encoded in segments, and a segment
  on disk is finished by definition, so a machine that dies at 97% resumes at
  97% instead of at zero;
* **cores are used** — segments are drawn in a process pool, because the slow
  part is PIL and Python and the GIL would serialise threads doing it.

`segments.py` holds why that decomposition is shaped the way it is. This module
holds the drawing.

The one thing that is *not* per-frame is asset loading. Stills and extracted
video frames are materialised to the scratch directory once, by the parent
process which is the only one holding a storage handle, and every worker opens
them from there. So the drawing side of this file — `RenderContext` — has no
storage, no network and no events: it takes a directory and a time and returns a
picture. That is what makes it safe to run in a pool worker, and it is enforced
by the fact that it is a separate class rather than by a comment asking nicely.
"""

from __future__ import annotations

import asyncio
import bisect
import json
import os
import shutil
import subprocess
import tempfile
from collections.abc import AsyncIterator
from concurrent.futures import ProcessPoolExecutor
from dataclasses import dataclass, field
from pathlib import Path

from PIL import Image, ImageDraw, ImageFilter

from vtv.adapters.media import ffmpeg
from vtv.adapters.render import segments as seg
from vtv.animation.canvas import Canvas
from vtv.animation.engine import AnimationEngine, RenderSize
from vtv.animation.theme import Theme, ease_in_out, ease_out_cubic, with_alpha
from vtv.contracts.base import ObjectRef, RetentionClass, TimeSpan
from vtv.contracts.errors import (
    ErrorCategory,
    ErrorCode,
    ErrorInfo,
    RenderFailed,
    Status,
    VTVError,
)
from vtv.contracts.render import RenderJob, RenderSettings
from vtv.contracts.timeline import (
    AssetClipSource,
    CaptionCue,
    FitPolicy,
    PlaceholderClipSource,
    ProgrammaticClipSource,
    Timeline,
    TransitionKind,
    VisualClip,
)
from vtv.contracts.visual_language import CameraMotion
from vtv.observability.events import EventName, EventSink, Timer
from vtv.pipeline.captions import caption_pages, to_srt, to_vtt
from vtv.security.paths import tenant_key

#: Ken Burns strength: how far the frame travels over a clip. Subtle on purpose
#: — anything more reads as a screensaver.
CAMERA_TRAVEL = 0.10

#: Most pool workers to start, however many cores are present.
#:
#: Each worker holds one segment's stills in memory and runs one x264, so the
#: ceiling is about memory and disk bandwidth rather than arithmetic. Past
#: eight, a 1080p render is waiting on the encoder and the page cache.
MAX_WORKERS = 8


def _combine(
    under: Image.Image, over: Image.Image, kind: TransitionKind, progress: float
) -> Image.Image:
    """One frame of a transition: the outgoing picture, the incoming one, and
    how far through we are.

    ``progress`` is already eased, so each of these is a straight geometric or
    photometric mix — the timing curve is one decision made once, not four
    slightly different ones.

    * **fade / dissolve** — a cross-blend. Two names for the same operation in
      this renderer, and deliberately so: a true fade goes out through black and
      back, which on a cut between two lit shots reads as a mistake rather than
      a choice. Editors who want black between shots get it by putting a gap in
      the timeline, which the renderer already fills with the background.
    * **wipe** — a vertical edge travelling left to right, with a soft margin so
      it does not alias into a staircase on diagonal content.
    * **push** — the incoming frame slides in from the right and shoves the
      outgoing one off to the left. Both move, which is what separates a push
      from a slide-over, and it is the transition that reads as "next" rather
      than "meanwhile".

    Anything unrecognised cross-blends. A new `TransitionKind` added to the
    contract will look like a dissolve until it is implemented here, which is
    the mistake this function was written to stop repeating — so the enum and
    this table are checked against each other by a test rather than by hope.
    """
    if kind is TransitionKind.WIPE:
        width, height = under.size
        edge = int(width * progress)
        # A hard edge on a 1080p frame crawls; a soft one reads as an edge.
        feather = max(2, width // 96)
        mask = Image.new("L", (width, height), 0)
        if edge > 0:
            mask.paste(255, (0, 0, min(edge, width), height))
        if 0 < edge < width:
            ImageDraw.Draw(mask).rectangle(
                [max(0, edge - feather), 0, min(width, edge + feather), height],
                fill=128,
            )
            mask = mask.filter(ImageFilter.GaussianBlur(feather / 2))
        return Image.composite(over, under, mask)

    if kind is TransitionKind.PUSH:
        width, height = under.size
        offset = int(width * progress)
        frame = Image.new(under.mode, (width, height))
        frame.paste(under, (-offset, 0))
        frame.paste(over, (width - offset, 0))
        return frame

    return Image.blend(under, over, progress)


@dataclass(eq=False)
class _ResolvedClip:
    """A clip with its pixels *addressable*, not necessarily loaded.

    ## Why the still is a path and not an image

    Every clip's still used to be decoded into memory before the first frame was
    drawn, and held until the render finished. At 1536×1024 that is 4.7MB each;
    a forty-minute video has around seven hundred visual units, so the renderer
    asked for three gigabytes before it drew anything — on a machine that also
    had to run an encoder. It survived because much of that video was drawn
    typography, which is generated rather than loaded, and it would not have
    survived a video of photographs.

    Loading on demand and releasing between segments bounds the working set to
    whatever one segment touches — a handful of shots — regardless of how long
    the video is. The cost is re-decoding a clip that straddles two segments,
    which is one JPEG decode against three hundred and sixty composited frames.

    `eq=False` matters: the default dataclass equality would compare PIL images
    field by field, and `_previous` locates a clip by identity in a list. An
    accidental value comparison there would find the wrong neighbour and blend
    the wrong shot into a transition.
    """

    clip: VisualClip
    #: Where the still lives on disk, for image sources.
    still_path: Path | None = None
    #: Directory of extracted frames, for video sources.
    frames: list[Path] | None = None
    frame_rate: float = 30.0
    _still: Image.Image | None = field(default=None, repr=False)

    @property
    def has_still(self) -> bool:
        return self.still_path is not None

    @property
    def still(self) -> Image.Image | None:
        if self.still_path is None:
            return None
        if self._still is None:
            with Image.open(self.still_path) as opened:
                self._still = opened.convert("RGB").copy()
        return self._still

    def release(self) -> None:
        self._still = None


class RenderContext:
    """Draws any frame of one video, from a directory and nothing else.

    Constructed in the parent process, saved to `plan.json`, and reconstructed
    inside each pool worker. It holds no storage handle, opens no sockets and
    emits no events — everything it needs was written to the scratch directory
    before the first segment was dispatched.

    That is a deliberate boundary and not merely a convenience. A composer that
    could reach storage would be a composer that can fail differently in a
    worker than it does in the parent, and the failure would appear as a
    corrupt segment in the middle of a two-hundred-segment video.
    """

    def __init__(
        self,
        *,
        timeline: Timeline,
        settings: RenderSettings,
        scratch: Path,
        assets: dict[str, dict[str, object]],
    ) -> None:
        self.timeline = timeline
        self.settings = settings
        self.scratch = scratch
        self.assets = assets
        self.fps = settings.frame_rate

        width, height = settings.dimensions
        self.size = RenderSize(width, height)
        self.theme = Theme.from_style(timeline.style, width=width, height=height)
        self.engine = AnimationEngine(
            timeline.style, entity_colours=timeline.entity_colours
        )

        self.resolved = [self._rebuild(clip) for clip in timeline.clips]
        # Clip starts, for locating the active clip by bisection rather than by
        # scanning. A four-hour video has ~2 900 clips and ~430 000 frames; the
        # linear scan this replaces did up to 1.2 billion comparisons per
        # render, which does not show up in a ten-second test and dominates a
        # long one.
        self._starts = [item.clip.span.start for item in self.resolved]
        self._transition_frames: dict[str, Image.Image] = {}

    # -- persistence ------------------------------------------------------

    def save(self) -> None:
        (self.scratch / "plan.json").write_text(
            json.dumps(
                {
                    "timeline": self.timeline.model_dump(mode="json"),
                    "settings": self.settings.model_dump(mode="json"),
                    "assets": self.assets,
                },
                separators=(",", ":"),
            ),
            encoding="utf-8",
        )

    @classmethod
    def load(cls, scratch: Path) -> RenderContext:
        payload = json.loads((scratch / "plan.json").read_text(encoding="utf-8"))
        return cls(
            timeline=Timeline.model_validate(payload["timeline"]),
            settings=RenderSettings.model_validate(payload["settings"]),
            scratch=scratch,
            assets=payload["assets"],
        )

    def _rebuild(self, clip: VisualClip) -> _ResolvedClip:
        entry = self.assets.get(clip.clip_id)
        if not entry:
            return _ResolvedClip(clip=clip)
        still = entry.get("still")
        if isinstance(still, str):
            return _ResolvedClip(clip=clip, still_path=self.scratch / still)
        folder = entry.get("frames")
        if isinstance(folder, str):
            directory = self.scratch / folder
            return _ResolvedClip(
                clip=clip,
                frames=sorted(directory.glob("frame-*.png")),
                frame_rate=float(entry.get("frame_rate", self.fps) or self.fps),
            )
        return _ResolvedClip(clip=clip)

    def release(self) -> None:
        """Drop decoded pixels. Called between segments to bound memory."""
        for item in self.resolved:
            item.release()
        self._transition_frames.clear()

    # -- frame composition ------------------------------------------------

    def compose(self, t: float) -> Image.Image:
        timeline, settings = self.timeline, self.settings
        active = self._active(t)
        if active is None:
            base = Image.new(
                "RGB", (self.size.width, self.size.height), self.theme.background[:3]
            )
        else:
            base = self._draw_clip(active, t)

            # Every transition is the outgoing clip's final frame combined with
            # the incoming one. What differs is *how* they are combined, and
            # until recently they did not differ at all: `TransitionKind`
            # offered cut, fade, dissolve, wipe and push, and the renderer
            # blended for all four of the non-cut ones. A timeline could ask for
            # a wipe, the API would accept it, the editor would show it, and the
            # video would dissolve — a feature that exists everywhere except on
            # screen.
            transition = active.clip.transition_in
            if transition.kind is not TransitionKind.CUT and transition.duration_seconds > 0:
                since = t - active.clip.span.start
                if 0 <= since < transition.duration_seconds:
                    previous = self._previous(active)
                    if previous is not None:
                        base = _combine(
                            self._outgoing_frame(previous),
                            base,
                            transition.kind,
                            ease_in_out(since / transition.duration_seconds),
                        )

        canvas = Canvas(self.theme)
        canvas.image = base.convert("RGBA")
        canvas.draw = canvas.draw.__class__(canvas.image, "RGBA")

        if active is not None:
            source = active.clip.source
            if isinstance(source, AssetClipSource):
                if source.attribution and settings.include_attributions:
                    self._draw_attribution(canvas, source.attribution)
                if source.illustrative_label:
                    # Generated imagery of real subjects is labelled on screen.
                    self._draw_badge(canvas, "Illustrative")

        if settings.burn_in_captions and timeline.style.captions_enabled:
            cue = self._caption_at(timeline.captions, t)
            if cue is not None:
                self._draw_caption(canvas, cue, t)

        return canvas.to_rgb()

    def _outgoing_frame(self, previous: _ResolvedClip) -> Image.Image:
        """The outgoing clip's last frame, drawn once rather than per frame.

        It is the same picture for the whole transition — always the frame a
        millisecond before the outgoing clip ends — and it was being redrawn
        from scratch for every frame of every transition. A 0.4-second dissolve
        at 30fps drew it twelve times; a video with thirty transitions drew
        three hundred and sixty full frames nobody needed.

        Keyed by clip id and cleared with the rest of the working set between
        segments, so a long video does not accumulate one full-size frame per
        clip for the whole encode.
        """
        cached = self._transition_frames.get(previous.clip.clip_id)
        if cached is None:
            cached = self._draw_clip(previous, previous.clip.span.end - 0.001)
            self._transition_frames[previous.clip.clip_id] = cached
        return cached

    def _draw_clip(self, resolved: _ResolvedClip, t: float) -> Image.Image:
        clip = resolved.clip
        local = max(0.0, min(clip.span.duration, t - clip.span.start))
        source = clip.source

        if isinstance(source, ProgrammaticClipSource):
            return self.engine.frame_at(
                source.spec, size=self.size, t=local, duration=clip.span.duration
            )

        if isinstance(source, PlaceholderClipSource):
            return self._draw_placeholder(self.theme, source.message)

        if resolved.has_still:
            still = resolved.still
            if still is not None:
                return self._draw_still(still, self.theme, clip, local)

        if resolved.frames:
            index = self._frame_index(resolved, local)
            with Image.open(resolved.frames[index]) as frame:
                canvas = Canvas(self.theme)
                canvas.paste_fitted(
                    frame, (0, 0, self.theme.width, self.theme.height), cover=True
                )
                return canvas.to_rgb()

        return self._draw_placeholder(self.theme, "Visual unavailable")

    @staticmethod
    def _frame_index(resolved: _ResolvedClip, local: float) -> int:
        """Which extracted frame to show, honouring the clip's fit policy."""
        count = len(resolved.frames or [])
        if count == 0:
            return 0
        raw = int(local * resolved.frame_rate)
        fit = resolved.clip.fit
        if fit is FitPolicy.LOOP:
            return raw % count
        if fit is FitPolicy.SPEED_RAMP:
            fraction = local / max(0.001, resolved.clip.span.duration)
            return min(count - 1, int(fraction * count))
        # TRIM and HOLD_LAST both stop at the final frame; TRIM simply never
        # reaches it because the media is longer than the slot.
        return min(raw, count - 1)

    def _draw_still(
        self, still: Image.Image, theme: Theme, clip: VisualClip, local: float
    ) -> Image.Image:
        """A photograph with camera motion. A static image held for eight
        seconds reads as a broken video, so every still moves."""
        fraction = local / max(0.001, clip.span.duration)
        eased = ease_out_cubic(fraction) if clip.camera_motion is CameraMotion.KEN_BURNS else fraction
        travel = CAMERA_TRAVEL

        zoom = 1.0 + travel
        offset_x = offset_y = 0.0
        motion = clip.camera_motion
        if motion in {CameraMotion.ZOOM_IN, CameraMotion.KEN_BURNS}:
            zoom = 1.0 + travel * eased
        elif motion is CameraMotion.ZOOM_OUT:
            zoom = 1.0 + travel * (1 - eased)
        elif motion in {CameraMotion.PAN_LEFT, CameraMotion.PAN_RIGHT}:
            offset_x = travel * (eased if motion is CameraMotion.PAN_RIGHT else -eased)
        elif motion in {CameraMotion.PAN_UP, CameraMotion.PAN_DOWN}:
            offset_y = travel * (eased if motion is CameraMotion.PAN_DOWN else -eased)
        elif motion is CameraMotion.NONE:
            zoom = 1.0

        if motion is CameraMotion.KEN_BURNS:
            offset_x = travel * 0.35 * eased

        target_w = int(theme.width * zoom)
        target_h = int(theme.height * zoom)
        canvas = Canvas(theme)
        left = int((theme.width - target_w) / 2 + offset_x * theme.width)
        top = int((theme.height - target_h) / 2 + offset_y * theme.height)
        canvas.paste_fitted(still, (left, top, left + target_w, top + target_h), cover=True)
        return canvas.to_rgb()

    @staticmethod
    def _draw_placeholder(theme: Theme, message: str) -> Image.Image:
        canvas = Canvas(theme)
        font = theme.font("title")
        block = canvas.wrap(message, font, int(theme.safe_width * 0.7))
        canvas.rounded_rect(
            (
                theme.width / 2 - block.width / 2 - theme.scale(0.05),
                theme.height / 2 - block.height / 2 - theme.scale(0.04),
                theme.width / 2 + block.width / 2 + theme.scale(0.05),
                theme.height / 2 + block.height / 2 + theme.scale(0.04),
            ),
            theme.scale(0.02),
            outline=with_alpha(theme.muted, 0.6),
            width=2,
        )
        canvas.text_block(
            block,
            font,
            (int(theme.width / 2 - block.width / 2), int(theme.height / 2 - block.height / 2)),
            theme.muted,
            align="center",
        )
        return canvas.to_rgb()

    # -- overlays ---------------------------------------------------------

    @staticmethod
    def _caption_at(cues: list[CaptionCue], t: float) -> CaptionCue | None:
        for cue in cues:
            if cue.span.start <= t < cue.span.end:
                return cue
        return None

    def _draw_caption(self, canvas: Canvas, cue: CaptionCue, t: float) -> None:
        """Draw the part of this cue that belongs on screen at `t`.

        A cue that does not fit the box is paged rather than cut. `wrap_caption`
        used to return only its first two lines and the remainder was never
        drawn — the sentence stopped mid-clause and the viewer had no way to
        know anything was missing. Now the lines are grouped into screenfuls and
        the elapsed fraction of the cue's own span picks which one is showing,
        so a long line reads as two pages and the whole sentence arrives.

        The pages divide the span evenly. That is deliberately simple: dividing
        by character count would make a short second page flash past, and the
        cue boundaries themselves already came from real word timings upstream.
        """
        theme = canvas.theme
        font = theme.font("body")
        pages = caption_pages(cue.text)
        if len(pages) == 1:
            lines = pages[0]
        else:
            elapsed = t - cue.span.start
            share = cue.span.duration / len(pages) if cue.span.duration > 0 else 0.0
            index = int(elapsed / share) if share > 0 else 0
            lines = pages[min(max(index, 0), len(pages) - 1)]
        widths = [canvas.measure(line, font)[0] for line in lines]
        ascent, descent = font.getmetrics()
        line_height = int((ascent + descent) * 1.16)
        pad_x, pad_y = theme.scale(0.022), theme.scale(0.014)
        box_w = max(widths) + pad_x * 2
        box_h = line_height * len(lines) + pad_y * 2
        x0 = (theme.width - box_w) / 2
        y0 = theme.height - theme.margin * 0.55 - box_h

        canvas.rounded_rect(
            (x0, y0, x0 + box_w, y0 + box_h),
            theme.scale(0.012),
            fill=with_alpha((0, 0, 0, 255), 0.55),
        )
        y = y0 + pad_y
        for line, width in zip(lines, widths, strict=True):
            canvas.text(
                ((theme.width - width) / 2, y), line, font, theme.foreground
            )
            y += line_height

    def _draw_attribution(self, canvas: Canvas, attribution: str) -> None:
        theme = canvas.theme
        font = theme.font("micro")
        text = attribution[:110]
        width = canvas.measure(text, font)[0]
        pad = theme.scale(0.01)
        x0 = theme.margin * 0.45
        y0 = theme.margin * 0.45
        canvas.rounded_rect(
            (x0, y0, x0 + width + pad * 2, y0 + theme.scale(0.032)),
            theme.scale(0.006),
            fill=with_alpha((0, 0, 0, 255), 0.45),
        )
        canvas.text(
            (x0 + pad, y0 + theme.scale(0.016)),
            text,
            font,
            with_alpha(theme.foreground, 0.85),
            anchor="lm",
        )

    def _draw_badge(self, canvas: Canvas, label: str) -> None:
        theme = canvas.theme
        font = theme.font("micro")
        width = canvas.measure(label, font)[0]
        pad = theme.scale(0.012)
        x1 = theme.width - theme.margin * 0.45
        y0 = theme.margin * 0.45
        canvas.rounded_rect(
            (x1 - width - pad * 2, y0, x1, y0 + theme.scale(0.032)),
            theme.scale(0.016),
            fill=with_alpha(theme.secondary, 0.9),
        )
        canvas.text(
            (x1 - width - pad, y0 + theme.scale(0.016)),
            label,
            font,
            (10, 10, 12, 255),
            anchor="lm",
        )

    # -- lookup -----------------------------------------------------------

    def _active(self, t: float) -> _ResolvedClip | None:
        if not self.resolved:
            return None
        index = bisect.bisect_right(self._starts, t) - 1
        if index < 0:
            return None
        candidate = self.resolved[index]
        if t < candidate.clip.span.end:
            return candidate
        # Past the end of the last clip the final picture holds, which is what
        # fills the deliberate visual time the pacing planner allocates after
        # the narration stops. Inside a gap between clips, nothing is active and
        # the background shows.
        return self.resolved[-1] if index == len(self.resolved) - 1 else None

    def _previous(self, current: _ResolvedClip) -> _ResolvedClip | None:
        for index, item in enumerate(self.resolved):
            if item is current:
                return self.resolved[index - 1] if index > 0 else None
        return None


class FfmpegRenderer:
    """Composes and encodes a timeline. Implements the `Renderer` port."""

    def __init__(
        self,
        *,
        storage: object,
        events: EventSink,
        workdir: Path | None = None,
        workers: int | None = None,
        segment_seconds: float = seg.TARGET_SECONDS,
    ) -> None:
        self.storage = storage
        self.events = events
        self.workdir = workdir
        #: How much video one checkpoint covers. See `segments.TARGET_SECONDS`
        #: for the trade; smaller means less lost to a crash and more ffmpeg
        #: invocations.
        self.segment_seconds = segment_seconds
        #: How many segments to draw at once. `None` means "as many as this
        #: machine has cores, up to `MAX_WORKERS`"; `1` means draw inline with
        #: no pool at all, which is what tests and tiny previews want because
        #: starting a worker costs more than the video does.
        self.workers = workers
        self._progress: dict[str, RenderJob] = {}

    # -- Renderer port ----------------------------------------------------

    async def render(
        self, *, timeline: Timeline, settings: RenderSettings
    ) -> RenderJob:
        job = RenderJob(
            organisation_id=timeline.organisation_id,
            project_id=timeline.project_id,
            timeline_id=timeline.timeline_id,
            settings=settings,
            status=Status.PROCESSING,
        )
        self._progress[job.render_job_id] = job

        renderable, problems = timeline.is_renderable()
        if not renderable:
            # Coverage gaps and missing captions are caught here rather than
            # discovered in the finished file.
            raise RenderFailed("timeline is not renderable: " + "; ".join(problems))

        timer = Timer()
        root = self._root()
        seg.sweep(root)
        # Named by *what is being rendered*, never by this attempt's id — that
        # is the whole of how a restarted render finds the segments the dead one
        # left behind. See `segments.fingerprint`.
        scratch = root / f"{timeline.timeline_id}-{seg.fingerprint(timeline, settings)}"
        scratch.mkdir(parents=True, exist_ok=True)

        try:
            output = await self._encode(timeline, settings, scratch, job)
            captions_ref = await self._write_captions(timeline, scratch)
        except VTVError as exc:
            # The error is recorded *before* the status, because `RenderJob`
            # refuses to be FAILED without one — and until now this line set the
            # status alone. Every real render failure therefore died inside
            # pydantic with "a FAILED render job must carry an ErrorInfo",
            # replacing the actual cause ("encode failed (1): …") with a
            # validation error about our own model. The failure path was the one
            # path no test ran.
            job.error = exc.info
            job.status = Status.FAILED
            self.events.emit(
                EventName.RENDER_FAILED,
                project_id=timeline.project_id,
                data={"render_job_id": job.render_job_id},
            )
            # Deliberately *not* cleaned up. The segments already encoded are
            # the reason a retry is cheap, and deleting them here would make
            # every failure cost a full re-render — which is precisely the
            # behaviour this design replaced.
            raise

        shutil.rmtree(scratch, ignore_errors=True)

        job.output = output
        job.captions_output = captions_ref
        job.duration_seconds = timeline.duration_seconds
        job.render_seconds = timer.elapsed_ms / 1000.0
        job.progress = 1.0
        job.status = Status.READY

        self.events.emit(
            EventName.RENDER_COMPLETED,
            project_id=timeline.project_id,
            duration_ms=timer.elapsed_ms,
            data={
                "render_job_id": job.render_job_id,
                "bytes": output.size_bytes,
                "realtime_ratio": round(
                    (timer.elapsed_ms / 1000.0) / max(0.001, timeline.duration_seconds), 2
                ),
            },
        )
        return job

    def _root(self) -> Path:
        """Where segment directories live between attempts.

        A configured `workdir` is used as given. Without one the renderer used
        to call `mkdtemp` and delete the result in a `finally`, which meant a
        crashed render's segments were either already gone or in a directory
        the next attempt could not name. A stable path under the system temp
        directory is what makes resumption possible at all; `sweep` stops it
        growing without bound.
        """
        root = Path(self.workdir) if self.workdir else Path(tempfile.gettempdir()) / "vtv-renders"
        root.mkdir(parents=True, exist_ok=True)
        return root

    async def render_progress(self, render_job_id: str) -> AsyncIterator[RenderJob]:
        async def iterator() -> AsyncIterator[RenderJob]:
            job = self._progress.get(render_job_id)
            if job is not None:
                yield job

        return iterator()

    async def cancel(self, render_job_id: str) -> None:
        job = self._progress.get(render_job_id)
        if job is not None and not job.status.is_terminal:
            job.error = ErrorInfo.of(
                ErrorCode.RENDER_FAILED,
                ErrorCategory.USER,
                "render cancelled by request",
                user_message="You cancelled this render.",
            )
            job.status = Status.FAILED

    # -- encoding ---------------------------------------------------------

    async def _encode(
        self,
        timeline: Timeline,
        settings: RenderSettings,
        scratch: Path,
        job: RenderJob,
    ) -> ObjectRef:
        fps = settings.frame_rate
        total_frames = max(1, round(timeline.duration_seconds * fps))

        assets = await self._materialise(timeline, scratch, fps)
        context = RenderContext(
            timeline=timeline, settings=settings, scratch=scratch, assets=assets
        )
        context.save()

        plan = seg.plan(
            [clip.span.start for clip in timeline.clips],
            fps=fps,
            total_frames=total_frames,
            target_seconds=self.segment_seconds,
        )
        outstanding = [item for item in plan if not item.done(scratch)]
        resumed = len(plan) - len(outstanding)

        self.events.emit(
            EventName.RENDER_STARTED,
            project_id=timeline.project_id,
            data={
                "render_job_id": job.render_job_id,
                "quality": settings.quality.value,
                "clips": len(timeline.clips),
                "duration_seconds": round(timeline.duration_seconds, 3),
                "segments": len(plan),
                # Reported, not inferred. A user whose render died overnight can
                # see from the event stream that it picked up where it stopped,
                # and a user whose first attempt this is sees zero.
                "resumed_segments": resumed,
                "workers": self._worker_count(len(outstanding)),
            },
        )

        job.progress = round(resumed / len(plan), 3) if plan else 0.0
        await self._encode_segments(timeline, context, scratch, outstanding, plan, job)

        output_path = await asyncio.to_thread(
            self._assemble, timeline, settings, scratch, plan
        )

        stored: ObjectRef = await self.storage.put_file(  # type: ignore[attr-defined]
            key=tenant_key(
                timeline.organisation_id,
                "projects",
                timeline.project_id,
                "renders",
                f"{job.render_job_id}.mp4",
            ),
            source=output_path,
            content_type="video/mp4",
            retention=RetentionClass.EPHEMERAL,
        )
        return stored

    def _worker_count(self, outstanding: int) -> int:
        if self.workers is not None:
            return max(1, self.workers)
        if outstanding <= 1:
            # One segment cannot be parallelised, and a pool would cost more to
            # start than the segment costs to draw.
            return 1
        return max(1, min(MAX_WORKERS, os.cpu_count() or 1, outstanding))

    async def _encode_segments(
        self,
        timeline: Timeline,
        context: RenderContext,
        scratch: Path,
        outstanding: list[seg.Segment],
        plan: list[seg.Segment],
        job: RenderJob,
    ) -> None:
        """Draw and encode every segment that is not already on disk.

        Inline and pooled are the same call in two arrangements, never two
        implementations. A separate sequential path would be the one the tests
        exercise and the pooled one the one users get, which is exactly the
        shape of failure — a test double more permissive than the real thing —
        that this project has paid for before.
        """
        if not outstanding:
            return

        done = len(plan) - len(outstanding)

        def advance(failure: str) -> None:
            nonlocal done
            if failure:
                raise RenderFailed(failure)
            done += 1
            job.progress = round(done / len(plan), 3)
            self.events.emit(
                EventName.RENDER_PROGRESS,
                project_id=timeline.project_id,
                data={
                    "render_job_id": job.render_job_id,
                    "progress": job.progress,
                    "segments_done": done,
                    "segments_total": len(plan),
                },
            )

        workers = self._worker_count(len(outstanding))
        if workers == 1:
            for item in outstanding:
                advance(
                    await asyncio.to_thread(
                        seg.encode_segment,
                        str(scratch),
                        item.index,
                        item.start_frame,
                        item.end_frame,
                    )
                )
            return

        # The parent's own context is not shared with the workers — each loads
        # its own from `plan.json` — so release its pixels before forking rather
        # than copying them into every child.
        context.release()
        loop = asyncio.get_running_loop()
        with ProcessPoolExecutor(max_workers=workers) as pool:
            futures = [
                loop.run_in_executor(
                    pool,
                    seg.encode_segment,
                    str(scratch),
                    item.index,
                    item.start_frame,
                    item.end_frame,
                )
                for item in outstanding
            ]
            failures: list[str] = []
            for future in asyncio.as_completed(futures):
                try:
                    failure = await future
                except Exception as exc:  # pragma: no cover - pool death
                    failures.append(f"render worker died: {type(exc).__name__}: {exc}")
                    continue
                if failure:
                    failures.append(failure)
                else:
                    advance("")
            if failures:
                # Every segment that *did* finish is on disk and will be skipped
                # by the retry, so reporting the first failure loses nothing.
                raise RenderFailed(failures[0])

    def _assemble(
        self,
        timeline: Timeline,
        settings: RenderSettings,
        scratch: Path,
        plan: list[seg.Segment],
    ) -> Path:
        """Join the segments and mux the narration. One stream copy, no re-encode.

        Concat's demuxer requires every input to share codec parameters, which
        they do by construction: one encoder, one set of flags, one frame size,
        applied by `segments.encode_segment` and nowhere else.
        """
        missing = [item.name for item in plan if not item.done(scratch)]
        if missing:
            # Reached only if a segment vanished between encoding and assembly.
            # Better a named error than a video that is silently short.
            raise RenderFailed(f"segments missing at assembly: {', '.join(missing[:5])}")

        listing = scratch / "segments.txt"
        listing.write_text(
            "".join(f"file '{item.path(scratch).as_posix()}'\n" for item in plan),
            encoding="utf-8",
        )

        audio_path = scratch / "narration.bin"
        output_path = scratch / "render.mp4"
        args = [
            ffmpeg.FFMPEG, "-y", "-hide_banner", "-loglevel", "error",
            "-f", "concat", "-safe", "0", "-i", str(listing),
        ]
        if audio_path.exists():
            args += ["-i", str(audio_path)]
        args += ["-c:v", "copy", "-movflags", "+faststart"]
        if audio_path.exists():
            # `apad` makes the audio stream effectively infinite and `-shortest`
            # then cuts the output at the end of the *video*. Without the pad,
            # `-shortest` cuts at the end of the audio — which silently threw
            # away every second of deliberate visual time the pacing planner
            # allocated past the end of the voice, so a video the user asked to
            # be five minutes long came back at the length of their script.
            # `adelay` puts the voice where the timeline says it starts.
            delay_ms = round(timeline.narration_start_seconds * 1000)
            chain = "apad" if delay_ms <= 0 else f"adelay={delay_ms}:all=1,apad"
            args += [
                "-af", chain,
                "-c:a", "aac",
                "-b:a", f"{settings.audio_bitrate_kbps}k",
                "-shortest",
            ]
        args.append(str(output_path))

        result = subprocess.run(args, capture_output=True)
        if result.returncode != 0 or not output_path.exists():
            detail = result.stderr.decode("utf-8", "replace").strip()[-400:]
            raise RenderFailed(f"assembly failed ({result.returncode}): {detail}")
        return output_path

    # -- resolution -------------------------------------------------------

    async def _materialise(
        self, timeline: Timeline, scratch: Path, fps: int
    ) -> dict[str, dict[str, object]]:
        """Put every clip's pixels on disk, and return where they went.

        This is the only part of rendering that touches storage, and it is done
        once in the parent — pool workers have no credentials, no network and no
        business fetching a customer's assets. Everything downstream of here
        reads files.

        Already-materialised assets are left alone, so a resumed render does not
        re-download what the dead attempt already fetched.
        """
        manifest: dict[str, dict[str, object]] = {}
        for clip in timeline.clips:
            source = clip.source
            if not isinstance(source, AssetClipSource):
                continue
            content_type = source.object.content_type

            if content_type.startswith("image/"):
                name = f"asset-{clip.clip_id}.bin"
                target = scratch / name
                if not target.exists():
                    # Written as fetched. Re-encoding to PNG here would cost a
                    # decode and an encode per asset to produce a larger file
                    # that PIL opens no faster.
                    target.write_bytes(
                        await self.storage.get(source.object)  # type: ignore[attr-defined]
                    )
                manifest[clip.clip_id] = {"still": name}
                continue

            if content_type.startswith("video/"):
                folder = f"frames-{clip.clip_id}"
                directory = scratch / folder
                if not any(directory.glob("frame-*.png")):
                    directory.mkdir(parents=True, exist_ok=True)
                    source_file = directory / "source.mp4"
                    source_file.write_bytes(
                        await self.storage.get(source.object)  # type: ignore[attr-defined]
                    )
                    ffmpeg.run(
                        [
                            ffmpeg.FFMPEG, "-y", "-hide_banner", "-loglevel", "error",
                            "-i", str(source_file),
                            "-vf", f"fps={fps}",
                            str(directory / "frame-%05d.png"),
                        ]
                    )
                    if not any(directory.glob("frame-*.png")):
                        raise RenderFailed(
                            f"no frames extracted from clip {clip.clip_id}"
                        )
                manifest[clip.clip_id] = {"frames": folder, "frame_rate": float(fps)}
                continue

            raise RenderFailed(f"unsupported asset content type {content_type}")

        await self._narration_file(timeline, scratch)
        return manifest

    async def _narration_file(self, timeline: Timeline, scratch: Path) -> Path | None:
        path = scratch / "narration.bin"
        if path.exists():
            return path
        try:
            data = await self.storage.get(timeline.narration.audio)  # type: ignore[attr-defined]
        except VTVError:
            # A render with no audio is still a render. The user gets silent
            # visuals and a clear event rather than nothing at all.
            self.events.emit(
                EventName.RENDER_PROGRESS,
                project_id=timeline.project_id,
                data={"warning": "narration audio unavailable; rendering silent"},
            )
            return None
        path.write_bytes(data)
        return path

    async def _write_captions(self, timeline: Timeline, scratch: Path) -> ObjectRef | None:
        """Always write a sidecar, whatever the burn-in setting.

        Accessibility must not depend on a render flag.
        """
        if not timeline.captions:
            return None
        srt = scratch / "captions.srt"
        srt.write_text(to_srt(timeline.captions), encoding="utf-8")
        vtt = scratch / "captions.vtt"
        vtt.write_text(to_vtt(timeline.captions), encoding="utf-8")
        captions: ObjectRef = await self.storage.put_file(  # type: ignore[attr-defined]
            key=tenant_key(
                timeline.organisation_id,
                "projects",
                timeline.project_id,
                "renders",
                f"{timeline.timeline_id}.vtt",
            ),
            source=vtt,
            content_type="text/vtt",
            retention=RetentionClass.PROJECT,
        )
        return captions


def clip_span_seconds(clip: VisualClip) -> TimeSpan:
    return clip.span


def ensure_ffmpeg() -> None:
    if not ffmpeg.is_available():
        raise VTVError(
            "ffmpeg and ffprobe are required for rendering",
            code=ErrorCode.RENDER_FAILED,
        )


__all__ = [
    "CAMERA_TRAVEL",
    "MAX_WORKERS",
    "FfmpegRenderer",
    "RenderContext",
    "ensure_ffmpeg",
]
