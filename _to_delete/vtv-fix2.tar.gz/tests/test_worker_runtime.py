"""Stages 27–28 at runtime — the API/worker split, proven end to end.

The audit's finding was not that the durable queue was wrong. It was that
nothing used it: the API held jobs as asyncio tasks and rendered inside its own
event loop, so every durability guarantee in `adapters/queue/durable.py`
described code no request ever reached.

These tests drive the real HTTP application and the real worker against shared
files, and assert the properties that only hold when the split is genuine:

* the API cannot run a job even if asked
* the artifact survives the API process that accepted it
* a replica that never saw the upload can still serve the video
* a crashed worker's job is reclaimed rather than lost
* redelivery does not bill twice
"""

from __future__ import annotations

import asyncio
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory

from starlette.testclient import TestClient

from vtv.adapters.media import ffmpeg
from vtv.api.app import create_app
from vtv.billing.plans import QuotaKind
from vtv.config import Settings
from vtv.contracts.tenancy import (
    Membership,
    Organisation,
    PlanTier,
    Role,
    User,
)
from vtv.jobs import JobKind
from vtv.security.keys import mint_api_key
from vtv.wiring import build, queue_path
from vtv.worker import Worker

SCRIPT = (
    "The transistor was invented in 1947 at Bell Labs. "
    "It replaced the vacuum tube almost everywhere within twenty years."
)


def run(coro):  # type: ignore[no-untyped-def]
    return asyncio.run(coro)


class RuntimeTestCase(unittest.TestCase):
    """One temporary directory holding the storage, database and queue.

    Everything below builds *separate* API and worker objects over these shared
    files, which is the closest a single process can come to the real topology.
    """

    def setUp(self) -> None:
        if not ffmpeg.is_available():
            self.skipTest("ffmpeg is required for a real render")
        self._dir = TemporaryDirectory(prefix="vtv-runtime-")
        root = Path(self._dir.name)
        self.settings = Settings(
            storage_root=root / "storage",
            database_url=f"sqlite:///{root / 'vtv.db'}",
            env="development",
        )
        self.assembly = build(self.settings)
        self.app = create_app(self.settings, assembly=self.assembly)
        self.client = TestClient(self.app)
        self.org, self.key = self.tenant("acme")

    def tearDown(self) -> None:
        self.client.close()
        self._dir.cleanup()

    def tenant(self, slug: str) -> tuple[str, str]:
        organisation = self.assembly.directory.create_organisation(
            Organisation(name=slug.title(), slug=slug, plan=PlanTier.BUSINESS)
        )
        user = self.assembly.directory.create_user(
            User(email=f"o@{slug}.example", sso_subject=f"sso|{slug}")
        )
        self.assembly.directory.add_member(
            Membership(
                user_id=user.user_id,
                organisation_id=organisation.organisation_id,
                role=Role.OWNER,
            )
        )
        minted = mint_api_key(
            organisation_id=organisation.organisation_id,
            name="key",
            role=Role.ADMIN,
            scopes=list(__import__(
                "vtv.contracts.tenancy", fromlist=["Capability"]
            ).Capability),
        )
        self.assembly.directory.store_key(minted.record)
        return organisation.organisation_id, minted.secret

    def auth(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self.key}"}

    def submit_document(self) -> tuple[str, str]:
        """Create a project and enqueue a document render. Returns (project, job)."""
        project_id = self.client.post(
            "/v1/projects", json={"title": "runtime"}, headers=self.auth()
        ).json()["project_id"]

        body = (
            b"# The Transistor\n\n"
            b"The transistor was invented in 1947 at Bell Labs.\n\n"
            b"It replaced the vacuum tube almost everywhere within twenty years.\n"
        )
        response = self.client.post(
            f"/v1/projects/{project_id}/documents",
            files={"document": ("note.md", body, "text/markdown")},
            headers=self.auth(),
        )
        self.assertEqual(response.status_code, 202, response.text)
        return project_id, response.json()["job_id"]

    def worker(self) -> Worker:
        """A worker over the same files, as a separate object with its own queue."""
        return Worker.create(self.settings, assembly=self.assembly, concurrency=1)


class TheApiDoesNotRunWork(RuntimeTestCase):
    def test_the_api_registers_no_handlers(self) -> None:
        """The structural half of the split.

        The API physically does not know how to execute a job, so it cannot do
        so by accident — which is stronger than a convention that rendering
        belongs elsewhere.
        """
        self.assertEqual(self.app.state.vtv.queue.handlers, {})

    def test_uploading_returns_immediately_without_rendering(self) -> None:
        project_id, job_id = self.submit_document()
        self.assertTrue(job_id)

        # Nothing has rendered, because nothing has consumed the queue.
        body = self.client.get(
            f"/v1/projects/{project_id}", headers=self.auth()
        ).json()
        self.assertNotIn("video_url", body)

    def test_the_job_is_durably_queued(self) -> None:
        _project_id, job_id = self.submit_document()
        queue = self.app.state.vtv.queue
        handle = run(queue.status(job_id))
        self.assertEqual(handle.kind, JobKind.RENDER_DOCUMENT.value)

    def test_the_queue_file_is_shared_not_in_memory(self) -> None:
        self.submit_document()
        self.assertTrue(queue_path(self.settings).exists())


class TheWorkerRendersAndTheArtifactSurvives(RuntimeTestCase):
    def test_a_document_becomes_a_video_through_the_queue(self) -> None:
        project_id, _job_id = self.submit_document()

        worker = self.worker()
        run(worker.queue.drain(timeout=180.0))

        body = self.client.get(
            f"/v1/projects/{project_id}", headers=self.auth()
        ).json()
        self.assertIn("video_url", body, body)
        video = self.client.get(body["video_url"], headers=self.auth())
        self.assertEqual(video.status_code, 200)
        self.assertGreater(len(video.content), 10_000)

    def test_a_replica_that_never_saw_the_upload_serves_the_video(self) -> None:
        """The in-memory result store made this impossible.

        A second application object over the same files stands in for a second
        pod. It never handled the upload and never ran the job.
        """
        project_id, _job_id = self.submit_document()
        run(self.worker().queue.drain(timeout=180.0))

        replica_assembly = build(self.settings)
        replica = create_app(self.settings, assembly=replica_assembly)
        with TestClient(replica) as other:
            response = other.get(
                f"/v1/projects/{project_id}/video", headers=self.auth()
            )
            self.assertEqual(response.status_code, 200)
            self.assertGreater(len(response.content), 10_000)

    def test_captions_and_storyboard_also_survive(self) -> None:
        project_id, _job_id = self.submit_document()
        run(self.worker().queue.drain(timeout=180.0))

        replica = create_app(self.settings, assembly=build(self.settings))
        with TestClient(replica) as other:
            captions = other.get(
                f"/v1/projects/{project_id}/captions.vtt", headers=self.auth()
            )
            self.assertEqual(captions.status_code, 200)
            self.assertIn("WEBVTT", captions.text)

            storyboard = other.get(
                f"/v1/projects/{project_id}/storyboard", headers=self.auth()
            )
            self.assertEqual(storyboard.status_code, 200)
            self.assertTrue(storyboard.json()["scenes"])

    def test_the_input_is_stored_under_the_tenants_prefix(self) -> None:
        """P1-2. A raw key would have put one tenant's upload beside another's."""
        project_id, job_id = self.submit_document()
        handle = run(self.app.state.vtv.queue.status(job_id))
        del handle
        bucket = self.settings.storage_root / self.settings.storage_bucket
        uploads = list((bucket / "orgs" / self.org).rglob("*"))
        self.assertTrue(
            any(path.is_file() for path in uploads),
            "the upload is not inside the tenant's namespace",
        )
        del project_id


class FailureAndRecovery(RuntimeTestCase):
    def test_a_reclaimed_job_completes_after_a_worker_dies(self) -> None:
        """Simulates the crash by writing the state a dead worker leaves."""
        import sqlite3

        project_id, job_id = self.submit_document()
        with sqlite3.connect(queue_path(self.settings), isolation_level=None) as db:
            db.execute(
                "UPDATE jobs SET state = 'running', claimed_by = 'dead-worker', "
                "heartbeat_at = 0 WHERE job_id = ?",
                (job_id,),
            )

        worker = Worker.create(
            self.settings, assembly=self.assembly, concurrency=1
        )
        # A fresh worker recovers on construction and again here, exactly as the
        # real one does before it starts consuming.
        recovered, dead = run(worker.queue.recover())
        self.assertEqual(dead, 0)
        run(worker.queue.drain(timeout=180.0))

        body = self.client.get(
            f"/v1/projects/{project_id}", headers=self.auth()
        ).json()
        self.assertIn("video_url", body, f"recovered={recovered} body={body}")

    def test_redelivery_does_not_bill_twice(self) -> None:
        """At-least-once delivery is only safe because the effects converge."""
        project_id, _job_id = self.submit_document()
        run(self.worker().queue.drain(timeout=180.0))

        first = self.assembly.usage.total(
            organisation_id=self.org, kind=QuotaKind.RENDERED_MINUTES
        )
        self.assertGreater(first, 0.0)

        # Re-run the identical work, as a redelivered message would.
        from vtv.jobs import RenderPayload, run_render_document

        payload = RenderPayload(
            project_id=project_id,
            organisation_id=self.org,
            input_key=f"orgs/{self.org}/projects/{project_id}/input/document",
            filename="note.md",
        )
        from vtv.contracts.errors import VTVError

        worker = self.worker()
        with self.assertRaises(VTVError):
            # The input was deleted on success, so a redelivery fails cleanly
            # rather than rendering a second time and charging again. It fails
            # as a domain error, not as an unhandled crash.
            run(run_render_document(worker.context(), payload.model_dump(mode="json")))

        second = self.assembly.usage.total(
            organisation_id=self.org, kind=QuotaKind.RENDERED_MINUTES
        )
        self.assertEqual(first, second, "a redelivered job billed twice")


class DegradationIsVisible(RuntimeTestCase):
    def test_a_mute_render_is_reported_degraded_not_ready(self) -> None:
        """P1-4. The audit's product-truth finding.

        No speech synthesiser is configured here, so the document path produces
        a silent video. It must not claim plain success.
        """
        project_id, _job_id = self.submit_document()
        run(self.worker().queue.drain(timeout=180.0))

        body = self.client.get(
            f"/v1/projects/{project_id}", headers=self.auth()
        ).json()
        self.assertEqual(body["outcome"], "degraded")
        self.assertTrue(body["deliverable"])
        self.assertFalse(body["narration"]["has_speech"])
        self.assertTrue(
            any("voice" in note.lower() for note in body["degradations"]),
            body.get("degradations"),
        )


if __name__ == "__main__":  # pragma: no cover
    unittest.main()
