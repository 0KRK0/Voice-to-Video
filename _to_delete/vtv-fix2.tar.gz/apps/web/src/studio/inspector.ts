/**
 * The inspector — one visual, and everything true about it.
 *
 * Fixed rather than a drawer, and the reason is `rationale`. "Why did it choose
 * this?" is the question users ask most of an AI director, the backend answers
 * it in the director's own words, and an answer behind a disclosure triangle is
 * an answer nobody reads.
 *
 * ## What must never be shown here
 *
 * Internal cost or margin. `cost_usd` on a version is customer-facing and
 * appears; nothing else about the economics does, and the provider that
 * produced a visual is deliberately absent from the payload so this panel
 * cannot leak it by accident.
 *
 * ## The regenerate control
 *
 * A split button whose menu is the ten intents, closed. There is no free-text
 * field, and adding one later would open a prompt-injection surface into a
 * model that decides what appears in someone's video.
 */

import { el, on } from "../core/dom.js";
import { attempt } from "../core/errors.js";
import { clock, humanise, money } from "../core/format.js";
import { Disposer } from "../core/store.js";
import { emptyState, originBadge, unitBadge } from "../widgets/states.js";
import { toast } from "../widgets/dialog.js";
import type {
  MediaAsset,
  RegenerationIntent,
  VisualUnit,
  VisualVersion,
} from "../api/types.js";
import type { StudioState } from "./state.js";
import type { VtvClient } from "../api/client.js";

/** The ten intents, in the order the design lays them out. */
export const INTENTS: { value: RegenerationIntent; needsProvider?: boolean }[] = [
  { value: "same_idea" },
  { value: "more_cinematic" },
  { value: "more_realistic" },
  { value: "more_educational" },
  { value: "simpler" },
  { value: "use_real_source" },
  { value: "use_animation" },
  { value: "use_typography" },
  { value: "use_generated_image", needsProvider: true },
  { value: "use_generated_video", needsProvider: true },
];

export interface InspectorDeps {
  state: StudioState;
  client: VtvClient;
  /** True when an image/video generator is configured on this install. */
  canGenerate: boolean;
  regenerate(unitId: string, intent: RegenerationIntent): Promise<void>;
  /** Open the media library scoped to replacing this visual. */
  replaceFromMedia(unitId: string): void;
  reloadUnits(): Promise<void>;
}

export interface InspectorView {
  node: HTMLElement;
  /**
   * Open the regeneration intents for whatever is selected.
   *
   * Exposed so the script panel's "Choose another approach" on a failed visual
   * opens *this* menu rather than building a second one — a second list would
   * be a second place to remember that two of the intents are unavailable when
   * no generator is configured.
   */
  openIntents(): void;
  dispose(): void;
}

export function createInspector(deps: InspectorDeps): InspectorView {
  const { state, client } = deps;
  const disposer = new Disposer();

  const body = el("div", { class: "inspector__body panel__body scroll" });
  /** The currently-drawn intent menu, so `openIntents` can reach it. */
  let intentMenu: { menu: HTMLElement; button: HTMLElement } | null = null;
  /** Whether the version comparison is open, and against which version. */
  let comparing = false;
  let compareWith: string | null = null;
  const node = el(
    "section",
    { class: "panel inspector", "aria-label": "Visual inspector" },
    body,
  );

  function paint(): void {
    const unit = state.selectedUnit.get();
    if (!unit) {
      body.replaceChildren(
        emptyState({
          title: "Nothing selected",
          body:
            "Click a line, a visual or a clip. What you choose is shown here, " +
            "with why it was chosen.",
        }),
      );
      return;
    }
    body.replaceChildren(detail(unit));
  }

  function detail(unit: VisualUnit): HTMLElement {
    const selected = unit.versions.find(
      (version) => version.version_id === unit.selected_version_id,
    );
    const asset = assetFor(unit, state.media.get());

    return el(
      "div",
      { class: "inspector__inner" },
      el(
        "header",
        { class: "inspector__head" },
        el("span", { class: "label" }, "Inspector"),
        el(
          "span",
          { class: "inspector__name" },
          `Visual ${String(unit.index + 1).padStart(2, "0")}`,
        ),
        el("div", { class: "spacer" }),
        unitBadge(unit.status),
      ),

      unit.detail
        ? el("p", { class: "inspector__detail" }, unit.detail)
        : null,

      el(
        "dl",
        { class: "facts" },
        fact("Kind", [
          el("span", null, selected ? humanise(selected.strategy) : "Not made yet"),
          // The version's own origin, sent by the server. It used to be looked
          // up in the media library, which meant a programmatic or generated
          // visual — anything with no library row — carried no badge at all,
          // and a unit that had been given a file at some point carried that
          // file's badge whichever version was selected.
          selected ? originBadge(selected.origin) : null,
        ]),

        // The rationale. Prose, at rest, in the director's own words.
        selected?.rationale
          ? fact("Why", [
              el("q", { class: "facts__why" }, selected.rationale),
            ])
          : null,

        selected ? fact("Grounded", [groundingLine(selected)]) : null,
        selected ? fact("Consistency", [consistencyLine(selected)]) : null,

        fact("Cost", [
          el(
            "span",
            { class: "tabular" },
            selected ? money(selected.cost_usd) : "—",
            unit.versions.length > 1
              ? el(
                  "span",
                  { class: "muted" },
                  ` · ${money(
                    unit.versions.reduce((sum, item) => sum + item.cost_usd, 0),
                  )} all versions`,
                )
              : null,
          ),
        ]),

        fact("Covers", [
          el(
            "span",
            { class: "tabular" },
            unit.script_block_ids.length === 1
              ? `Line ${lineNumber(unit.script_block_ids[0])}`
              : `Lines ${lineNumber(unit.script_block_ids[0])}–${lineNumber(
                  unit.script_block_ids[unit.script_block_ids.length - 1],
                )}`,
            unit.start !== null && unit.end !== null
              ? ` · ${clock(unit.start)} → ${clock(unit.end)}`
              : null,
          ),
        ]),
      ),

      actions(unit),
      versions(unit),
      asset ? provenance(asset) : null,
    );
  }

  function lineNumber(blockId: string | undefined): string {
    if (!blockId) return "—";
    const block = state.blockById.get().get(blockId);
    return block ? String(block.order + 1).padStart(2, "0") : "—";
  }

  // -- actions ------------------------------------------------------------

  function actions(unit: VisualUnit): HTMLElement {
    const regenerate = el(
      "button",
      {
        class: "btn",
        type: "button",
        disabled: unit.locked,
        title: unit.locked
          ? "This visual is locked. Unlock it first."
          : "Make another version of this visual",
        onclick: () => void deps.regenerate(unit.visual_unit_id, "same_idea"),
      },
      "Regenerate",
    );

    const menuButton = el(
      "button",
      {
        class: "btn",
        type: "button",
        disabled: unit.locked,
        "aria-haspopup": "true",
        "aria-expanded": "false",
        "aria-label": "Choose how to regenerate",
      },
      "▾",
    );

    const menu = el("div", { class: "menu", hidden: true, role: "menu" });
    intentMenu = { menu, button: menuButton };
    for (const intent of INTENTS) {
      const unavailable = Boolean(intent.needsProvider) && !deps.canGenerate;
      menu.appendChild(
        el(
          "button",
          {
            class: ["menu__item", unavailable && "is-unavailable"],
            type: "button",
            role: "menuitem",
            disabled: unavailable,
            title: unavailable
              ? "No image or video generator is configured on this install."
              : "",
            onclick: () => {
              menu.hidden = true;
              menuButton.setAttribute("aria-expanded", "false");
              void deps.regenerate(unit.visual_unit_id, intent.value);
            },
          },
          humanise(intent.value),
          unavailable
            ? el("span", { class: "menu__note muted" }, "unavailable")
            : null,
        ),
      );
    }

    disposer.add(
      on(menuButton, "click", () => {
        const open = menu.hidden;
        menu.hidden = !open;
        menuButton.setAttribute("aria-expanded", String(open));
      }),
      on(document, "click", (event) => {
        if (menu.hidden) return;
        const target = event.target as Node;
        if (!menu.contains(target) && target !== menuButton) {
          menu.hidden = true;
          menuButton.setAttribute("aria-expanded", "false");
        }
      }),
    );

    return el(
      "div",
      { class: "inspector__actions" },
      el("div", { class: "split" }, regenerate, menuButton),
      menu,
      el(
        "button",
        {
          class: "btn",
          type: "button",
          onclick: () => deps.replaceFromMedia(unit.visual_unit_id),
        },
        "Replace from Media",
      ),
      el(
        "button",
        {
          class: ["btn", unit.locked && "is-on"],
          type: "button",
          "aria-pressed": String(unit.locked),
          onclick: () => void setLocked(unit, !unit.locked),
        },
        unit.locked ? "⌂ Unlock" : "⌂ Lock",
      ),
      el(
        "button",
        {
          class: "btn",
          type: "button",
          disabled: unit.locked || unit.status === "approved",
          title: unit.locked
            ? "A lock is the stronger statement — there is nothing to add."
            : "Record that you looked at this and said yes",
          onclick: () => void approve(unit),
        },
        "Approve",
      ),
    );
  }

  async function setLocked(unit: VisualUnit, locked: boolean): Promise<void> {
    const updated = await attempt(() =>
      client.setUnitState(state.projectId, unit.visual_unit_id, { locked }),
    );
    if (!updated) return;
    replaceUnit(updated);
    toast(
      locked
        ? `Visual ${unit.index + 1} is locked. Nothing automatic will replace it.`
        : `Visual ${unit.index + 1} is unlocked.`,
      { tone: "info" },
    );
  }

  async function approve(unit: VisualUnit): Promise<void> {
    const updated = await attempt(() =>
      client.setUnitState(state.projectId, unit.visual_unit_id, {
        approved: true,
      }),
    );
    if (updated) replaceUnit(updated);
  }

  function replaceUnit(updated: VisualUnit): void {
    state.units.set(
      state.units
        .get()
        .map((unit) =>
          unit.visual_unit_id === updated.visual_unit_id ? updated : unit,
        ),
    );
  }

  // -- versions -----------------------------------------------------------

  function versions(unit: VisualUnit): HTMLElement | null {
    if (unit.versions.length === 0) return null;

    return el(
      "section",
      { class: "versions" },
      el(
        "header",
        { class: "versions__head" },
        el("span", { class: "label" }, "Versions"),
        el("div", { class: "spacer" }),
        unit.versions.length > 1
          ? el(
              "button",
              {
                class: ["btn btn--ghost btn--sm", comparing && "is-on"],
                type: "button",
                "aria-pressed": String(comparing),
                title:
                  "Put two versions beside each other before choosing between them",
                onclick: () => {
                  comparing = !comparing;
                  if (!comparing) compareWith = null;
                  paint();
                },
              },
              "Compare ⇄",
            )
          : null,
        el("div", { class: "spacer" }),
        el(
          "span",
          { class: "muted" },
          "Switching is free and instant",
        ),
      ),
      el(
        "div",
        { class: "versions__strip" },
        ...[...unit.versions]
          .reverse()
          .map((version) => versionCard(unit, version)),
      ),
      comparing ? comparison(unit) : null,
    );
  }

  /**
   * Two versions, beside each other.
   *
   * The reason refused and superseded versions are kept at all. Keeping them
   * and offering no way to look at two of them together is keeping receipts:
   * technically complete, no use to anybody deciding.
   *
   * Deliberately not a slider or a wipe. The question is "which of these is
   * better", and two pictures at the same size answers it; a wipe answers
   * "where do they differ", which nobody asked.
   */
  function comparison(unit: VisualUnit): HTMLElement {
    const selected =
      unit.versions.find((item) => item.version_id === unit.selected_version_id) ??
      unit.versions[unit.versions.length - 1];
    const other =
      unit.versions.find((item) => item.version_id === compareWith) ??
      [...unit.versions].reverse().find((item) => item.version_id !== selected?.version_id);

    if (!selected || !other) {
      return el(
        "p",
        { class: "muted" },
        "There is only one version to look at.",
      );
    }

    const picker = el("select", { class: "input" }) as HTMLSelectElement;
    for (const version of unit.versions) {
      if (version.version_id === selected.version_id) continue;
      picker.append(
        el(
          "option",
          {
            value: version.version_id,
            selected: version.version_id === other.version_id,
          },
          `v${version.version} · ${humanise(version.strategy)}`,
        ),
      );
    }
    disposer.add(
      on(picker, "change", () => {
        compareWith = picker.value;
        paint();
      }),
    );

    return el(
      "div",
      { class: "compare" },
      el(
        "div",
        { class: "compare__pair" },
        comparePane(selected, "In use"),
        comparePane(other, "Compared with"),
      ),
      el(
        "label",
        { class: "field" },
        el("span", { class: "label" }, "Compare with"),
        picker,
      ),
      other.usable && other.version_id !== unit.selected_version_id
        ? el(
            "button",
            {
              class: "btn btn--primary btn--sm",
              type: "button",
              disabled: unit.locked,
              onclick: () => void chooseVersion(unit, other),
            },
            `Use v${other.version} instead`,
          )
        : null,
    );
  }

  function comparePane(version: VisualVersion, caption: string): HTMLElement {
    return el(
      "figure",
      { class: "compare__pane" },
      el("span", { class: "label muted" }, caption),
      el(
        "span",
        {
          class: [
            "compare__thumb",
            !version.usable && "is-refused",
            `origin-${version.origin}`,
          ],
        },
        el("span", { class: "label" }, humanise(version.strategy)),
      ),
      el(
        "figcaption",
        { class: "compare__meta" },
        el("span", null, `v${version.version}`),
        originBadge(version.origin),
        el("span", { class: "tabular muted" }, money(version.cost_usd)),
      ),
      version.rationale
        ? el("q", { class: "compare__why" }, version.rationale)
        : null,
      !version.usable
        ? el(
            "p",
            { class: "compare__refused" },
            "Refused — this version cannot be used.",
          )
        : null,
    );
  }

  function versionCard(
    unit: VisualUnit,
    version: VisualVersion,
  ): HTMLElement {
    const current = version.version_id === unit.selected_version_id;
    const refused = version.grounding === "refused" || !version.usable;

    return el(
      "button",
      {
        class: [
          "version",
          current && "is-current",
          refused && "is-refused",
        ],
        type: "button",
        disabled: refused || unit.locked,
        "aria-pressed": String(current),
        title: refused
          ? version.rationale || "This version was refused and cannot be used."
          : `Use version ${version.version}`,
        onclick: () => void chooseVersion(unit, version),
      },
      el("span", { class: ["version__thumb", refused && "is-refused"] }),
      el(
        "span",
        { class: "version__meta" },
        el("span", { class: "version__name" }, `v${version.version}`),
        el(
          "span",
          { class: "muted" },
          refused ? " refused" : current ? " in use" : ` ${humanise(version.strategy)}`,
        ),
      ),
      el("span", { class: "version__cost tabular muted" }, money(version.cost_usd)),
    );
  }

  async function chooseVersion(
    unit: VisualUnit,
    version: VisualVersion,
  ): Promise<void> {
    const updated = await attempt(() =>
      client.setUnitState(state.projectId, unit.visual_unit_id, {
        version_id: version.version_id,
      }),
    );
    if (!updated) return;
    replaceUnit(updated);
    await deps.reloadUnits();
  }

  // -- provenance ---------------------------------------------------------

  /**
   * Where a picture came from, never hidden.
   *
   * For a licensed source this is a legal obligation and a customer question
   * they will one day ask. For a user's own file it is the *absence* of a
   * licence question, which is worth saying out loud.
   */
  function provenance(asset: MediaAsset): HTMLElement {
    if (asset.origin === "user_upload") {
      return el(
        "section",
        { class: "provenance" },
        el("span", { class: "label" }, "Provenance"),
        el(
          "p",
          { class: "provenance__own" },
          "Yours — ",
          el("span", { class: "provenance__file" }, asset.filename),
          ". No third-party licence needed, and no attribution.",
        ),
      );
    }

    const rows: [string, string][] = [
      ["Source", asset.provenance.source_name],
      ["Creator", asset.provenance.creator],
      ["Licence", asset.provenance.licence],
      ["Attribution", asset.provenance.attribution],
    ];

    return el(
      "section",
      { class: "provenance" },
      el("span", { class: "label" }, "Provenance"),
      el(
        "dl",
        { class: "facts facts--tight" },
        ...rows
          .filter(([, value]) => Boolean(value))
          .map(([name, value]) => fact(name, [el("span", null, value)])),
      ),
      asset.provenance.source_url
        ? el(
            "a",
            {
              class: "provenance__link",
              href: asset.provenance.source_url,
              target: "_blank",
              rel: "noreferrer noopener",
            },
            "View the source record",
          )
        : null,
    );
  }

  disposer.add(
    state.selection.subscribe(() => paint()),
    state.units.subscribe(() => paint()),
    state.media.subscribe(() => paint()),
  );

  return {
    node,
    openIntents(): void {
      // Deferred a frame: the caller has just changed the selection, and the
      // menu it wants belongs to the panel that selection is about to draw.
      window.requestAnimationFrame(() => {
        if (!intentMenu) return;
        intentMenu.menu.hidden = false;
        intentMenu.button.setAttribute("aria-expanded", "true");
        intentMenu.menu.querySelector<HTMLElement>(".menu__item:not([disabled])")?.focus();
        node.scrollIntoView({ block: "nearest" });
      });
    },
    dispose: () => disposer.dispose(),
  };
}

// -- helpers ---------------------------------------------------------------

function fact(name: string, value: (Node | null)[]): HTMLElement {
  return el(
    "div",
    { class: "facts__row" },
    el("dt", { class: "facts__name label" }, name),
    el("dd", { class: "facts__value" }, ...value.filter(Boolean)),
  );
}

/**
 * The grounding verdict, in the backend's own vocabulary.
 *
 * This used to branch on `supported` and `unsupported` — two words the API has
 * never sent. The real values are `grounded`, `refused`, `pending` and
 * `not_applicable`, so every visual the gate had positively cleared fell
 * through to the default and was reported as making no factual claim. The
 * product's flagship safety check, computed correctly and then displayed
 * inverted, on the one screen where anybody would look for it.
 *
 * A `switch` rather than a chain of `if`s: `noFallthroughCasesInSwitch` and an
 * exhaustive union mean adding a fifth verdict to the type is a compile error
 * here rather than a silent fifth trip through the default branch.
 */
function groundingLine(version: VisualVersion): HTMLElement {
  switch (version.grounding) {
    case "grounded":
      return el(
        "span",
        { class: "verdict is-good" },
        el("span", { "aria-hidden": "true" }, "✓ "),
        "Every value stated comes from the narration",
      );
    case "refused":
      return el(
        "span",
        { class: "verdict is-bad" },
        el("span", { "aria-hidden": "true" }, "▲ "),
        "Refused — it would have stated something your script does not",
      );
    case "pending":
      return el(
        "span",
        { class: "verdict is-warn" },
        el("span", { "aria-hidden": "true" }, "◷ "),
        "Not checked yet",
      );
    case "not_applicable":
      return el(
        "span",
        { class: "verdict muted" },
        "Not applicable — this makes no factual claim",
      );
  }
}

function consistencyLine(version: VisualVersion): HTMLElement {
  if (version.consistency === "consistent") {
    return el(
      "span",
      { class: "verdict is-good" },
      el("span", { "aria-hidden": "true" }, "✓ "),
      "Matches the Visual Bible",
    );
  }
  if (version.consistency === "conflicting") {
    return el(
      "span",
      { class: "verdict is-warn" },
      el("span", { "aria-hidden": "true" }, "↓ "),
      "Differs from the project's established look",
    );
  }
  return el("span", { class: "verdict muted" }, "Not applicable");
}

/** The library asset behind a unit's selected version, when there is one. */
function assetFor(unit: VisualUnit, media: MediaAsset[]): MediaAsset | null {
  const selected = unit.versions.find(
    (version) => version.version_id === unit.selected_version_id,
  );
  if (!selected) return null;
  return (
    media.find((asset) => asset.used_by_unit_ids.includes(unit.visual_unit_id)) ??
    null
  );
}
