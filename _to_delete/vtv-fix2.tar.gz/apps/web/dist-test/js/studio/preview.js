/**
 * The preview.
 *
 * The honest name for this panel is "the last render, plus what the timeline
 * says is here". There is no live preview of unrendered edits — the backend has
 * no such endpoint and building a client-side compositor would be a second
 * renderer that disagrees with the real one.
 *
 * So this panel does two things and says so:
 *
 * **It plays the last rendered video**, when one exists.
 *
 * **It reports what the timeline holds at the playhead**, from the preview
 * metadata endpoint, which is a database read rather than a frame. That is what
 * keeps the script, the inspector and the timeline in step while scrubbing.
 *
 * When the timeline has moved since the last render, a marker says so. An
 * editor that shows stale frames as though they were current is lying at
 * exactly the moment the user is deciding whether to publish.
 */
import { el, on } from "../core/dom.js";
import { clamp, timecode } from "../core/format.js";
import { Disposer, debounce } from "../core/store.js";
export function createPreview(deps) {
    const { state, client } = deps;
    const disposer = new Disposer();
    const video = el("video", {
        class: "preview__video",
        playsinline: true,
        preload: "metadata",
    });
    const stage = el("div", { class: "preview__stage" }, video);
    const placeholder = el("div", { class: "preview__placeholder" });
    const staleMark = el("div", { class: "preview__stale", hidden: true });
    const clockNow = el("span", { class: "preview__time tabular" }, "0:00.000");
    const clockTotal = el("span", { class: "preview__total tabular muted" }, "0:00");
    const playButton = el("button", { class: "preview__play", type: "button", "aria-label": "Play" }, "▶");
    const context = el("div", { class: "preview__context muted" });
    const node = el("section", { class: "panel preview", "aria-label": "Preview" }, el("div", { class: "preview__frame" }, stage, placeholder, staleMark), el("div", { class: "preview__controls" }, el("button", {
        class: "preview__step",
        type: "button",
        "aria-label": "Go to the start",
        onclick: () => deps.seek(0),
    }, "⏮"), playButton, el("button", {
        class: "preview__step",
        type: "button",
        "aria-label": "Go to the end",
        onclick: () => deps.seek(state.timeline.get()?.duration ?? 0),
    }, "⏭"), clockNow, el("span", { class: "muted" }, "/"), clockTotal, el("div", { class: "spacer" }), el("button", {
        class: "preview__icon",
        type: "button",
        "aria-label": "Fullscreen",
        onclick: () => void stage.requestFullscreen?.().catch(() => undefined),
    }, "⤢")), context);
    // -- source -------------------------------------------------------------
    function reload() {
        const project = state.project.get();
        if (project?.video_url) {
            const url = `${client.videoUrl(state.projectId)}?v=${Date.now()}`;
            if (video.src !== url)
                video.src = url;
            video.hidden = false;
            placeholder.replaceChildren();
            placeholder.hidden = true;
        }
        else {
            video.hidden = true;
            placeholder.hidden = false;
            placeholder.replaceChildren(el("p", { class: "preview__nothing label" }, "Nothing rendered yet"), el("button", { class: "btn", type: "button", onclick: () => deps.render() }, "Render preview"));
        }
        paintStale();
    }
    /**
     * The stale marker.
     *
     * Compares the timeline on screen against the one the render encoded. The
     * server sends the second number; before it did, this used
     * `timeline.version > 1` as a stand-in, which turns on the first time anybody
     * edits anything and never turns off again — including in the second after a
     * fresh render, when it is flatly false.
     *
     * Three states, and the third is the point: **newer**, **current**, and
     * **cannot tell**. A render made before the server recorded which timeline it
     * used gets no marker, because a warning that might be wrong is worse than no
     * warning — it teaches people to ignore the ones that are right.
     */
    function paintStale() {
        const project = state.project.get();
        const timeline = state.timeline.get();
        if (!project?.video_url || !timeline) {
            staleMark.hidden = true;
            return;
        }
        const encoded = project.rendered_timeline_version;
        if (encoded === null || encoded === undefined) {
            staleMark.hidden = true;
            return;
        }
        const moved = timeline.version > encoded;
        staleMark.hidden = !moved;
        if (moved) {
            staleMark.replaceChildren(el("span", { "aria-hidden": "true" }, "◷ "), "Timeline changed since this render");
            staleMark.title =
                `This render encoded version ${encoded}; the timeline is at ` +
                    `version ${timeline.version}.`;
        }
    }
    // -- playback -----------------------------------------------------------
    function play() {
        if (video.hidden)
            return;
        void video.play().catch(() => undefined);
    }
    function pause() {
        video.pause();
    }
    function toggleplay() {
        if (video.hidden) {
            deps.render();
            return;
        }
        if (video.paused)
            play();
        else
            pause();
    }
    disposer.add(on(playButton, "click", () => toggleplay()), on(video, "play", () => {
        state.playing.set(true);
        playButton.textContent = "❚❚";
        playButton.setAttribute("aria-label", "Pause");
    }), on(video, "pause", () => {
        state.playing.set(false);
        playButton.textContent = "▶";
        playButton.setAttribute("aria-label", "Play");
    }), on(video, "timeupdate", () => {
        // The video is the clock while it is playing; the timeline follows it.
        if (!video.paused)
            state.playhead.set(video.currentTime);
    }), on(video, "loadedmetadata", () => {
        clockTotal.textContent = timecode(video.duration || 0, false);
    }));
    // -- metadata -----------------------------------------------------------
    /**
     * What is on screen at the playhead.
     *
     * Debounced on a trailing 150ms, per `TIMELINE_UI_SPEC.md` §9. A scrub across
     * a three-minute project must not produce three hundred requests.
     */
    const loadContext = debounce(150, (at) => {
        // Nothing to ask about until a timeline exists. A project that has only a
        // script is a normal early state, and probing it produces a 404 per scrub
        // that means nothing and clutters the network log.
        if (!state.timeline.get()) {
            context.replaceChildren();
            return;
        }
        void client
            .preview(state.projectId, at)
            .then((preview) => {
            const lines = preview.script_lines.map((line) => line.text).join(" ");
            const parts = [
                preview.clip
                    ? el("span", { class: "tabular" }, `${preview.clip.label || "Clip"} · ${timecode(preview.clip.start, false)}–${timecode(preview.clip.end, false)}`)
                    : el("span", null, "Nothing at this moment"),
            ];
            if (preview.visual_unit) {
                parts.push(el("span", { class: "preview__unit" }, ` · Visual ${String(preview.visual_unit.index + 1).padStart(2, "0")}`));
            }
            if (lines) {
                parts.push(el("span", { class: "preview__line" }, ` · \u201C${lines}\u201D`));
            }
            context.replaceChildren(...parts);
        })
            .catch(() => {
            // A missing preview is a project without a timeline, which is a normal
            // early state rather than a failure worth interrupting for.
            context.replaceChildren();
        });
    });
    disposer.add(state.playhead.subscribe((at) => {
        clockNow.textContent = timecode(at);
        // Only push the video when the user moved the playhead, not when the
        // video moved it — otherwise every frame seeks itself.
        if (video.paused && !video.hidden && Math.abs(video.currentTime - at) > 0.05) {
            video.currentTime = clamp(at, 0, video.duration || at);
        }
        loadContext(at);
    }), state.project.subscribe(() => reload()), state.timeline.subscribe(() => {
        clockTotal.textContent = timecode(state.timeline.get()?.duration ?? 0, false);
        paintStale();
    }), () => loadContext.cancel());
    return {
        node,
        reload,
        play,
        pause,
        toggle: toggleplay,
        dispose: () => disposer.dispose(),
    };
}
