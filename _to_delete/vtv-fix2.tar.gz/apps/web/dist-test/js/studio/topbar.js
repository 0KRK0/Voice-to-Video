/**
 * The Studio toolbar.
 *
 * One primary action — Render — and everything else quieter than it. That is
 * the whole layout rule: a toolbar with four equally loud buttons has no
 * primary action, and this screen's primary action is unambiguous.
 *
 * The save indicator is the other thing worth attention. It reports what
 * actually happened: `saved`, `saving`, `unsaved` when a write was refused, and
 * `offline` when the event stream dropped. It never claims saved on hope.
 */
import { el, fill, on } from "../core/dom.js";
import { clock, humanise } from "../core/format.js";
import { Disposer } from "../core/store.js";
const PACING_MODES = [
    "natural",
    "tight",
    "cinematic",
    "educational",
    "fast",
];
export function createTopbar(deps) {
    const { state } = deps;
    const disposer = new Disposer();
    const title = el("span", { class: "topbar__title" }, "Project");
    const saved = el("span", { class: "topbar__saved" });
    const mode = fact("Mode", "—");
    const style = fact("Style", "—");
    const language = fact("Language", "—");
    const aspect = fact("Aspect", "—");
    const pacing = fact("Pacing", "—");
    const target = fact("Target / actual", "—");
    const busy = el("div", { class: "topbar__busy", hidden: true });
    const pacingSelect = el("select", {
        class: "topbar__select",
        "aria-label": "Pacing",
    });
    for (const value of PACING_MODES) {
        pacingSelect.appendChild(el("option", { value }, humanise(value)));
    }
    pacing.value.replaceChildren(pacingSelect);
    const targetInput = el("input", {
        class: "topbar__target input",
        type: "text",
        placeholder: "—",
        "aria-label": "Target duration, as m:ss",
        size: "5",
    });
    const actual = el("span", { class: "tabular muted" }, "· —");
    target.value.replaceChildren(targetInput, actual);
    const node = el("header", { class: "topbar" }, el("button", {
        class: "topbar__back",
        type: "button",
        "aria-label": "Back to projects",
        onclick: () => deps.onBack(),
    }, "‹"), title, saved, el("div", { class: "spacer" }), el("div", { class: "topbar__facts" }, mode.node, style.node, aspect.node, language.node, pacing.node, target.node), busy, el("div", { class: "topbar__actions" }, el("button", {
        class: "topbar__icon",
        type: "button",
        title: "Undo",
        "aria-label": "Undo",
        onclick: () => deps.onUndo(),
    }, "↶"), el("button", {
        class: "topbar__icon",
        type: "button",
        title: "Redo",
        "aria-label": "Redo",
        onclick: () => deps.onRedo(),
    }, "↷"), el("button", { class: "btn", type: "button", onclick: () => deps.onExport() }, "Export"), el("button", {
        class: "btn btn--primary",
        type: "button",
        onclick: () => deps.onRender(),
    }, "Render")));
    disposer.add(on(pacingSelect, "change", () => {
        deps.onPacing(pacingSelect.value, parseTarget(targetInput.value));
    }), on(targetInput, "change", () => {
        deps.onPacing(pacingSelect.value, parseTarget(targetInput.value));
    }), on(style.value, "click", () => deps.onStyle()));
    disposer.add(state.project.subscribe((project) => {
        title.textContent = project?.title || "Untitled project";
        // The project's own style, not a word that happened to be true for the
        // first project anybody made.
        style.value.textContent = project ? humanise(project.style) : "—";
        aspect.value.textContent = project ? project.aspect_ratio : "—";
    }), state.script.subscribe((script) => {
        if (!script)
            return;
        mode.value.textContent =
            script.origin === "spoken" ? "Spoken" : "Director";
        language.value.textContent = script.language.toUpperCase();
    }), state.pacing.subscribe((plan) => {
        if (!plan)
            return;
        pacingSelect.value = plan.mode;
        if (plan.target_seconds)
            targetInput.value = clock(plan.target_seconds);
        actual.textContent = `· ${clock(plan.planned_seconds)}`;
        actual.classList.toggle("is-over", plan.verdict === "overrun");
        actual.classList.toggle("is-short", plan.verdict === "underfilled");
        actual.title =
            plan.verdict === "on_target"
                ? "Within two seconds of your target."
                : plan.message;
    }), state.timeline.subscribe((timeline) => {
        if (!timeline || state.pacing.get())
            return;
        actual.textContent = `· ${clock(timeline.duration)}`;
    }), state.saving.subscribe((status) => {
        const words = {
            saved: "Saved",
            saving: "Saving…",
            unsaved: "Not saved",
            offline: "Offline",
        };
        saved.textContent = words[status] ?? "";
        saved.className = `topbar__saved is-${status}`;
        saved.title =
            status === "unsaved"
                ? "The last change was refused. Nothing was lost — try again."
                : status === "offline"
                    ? "We cannot reach the server. Changes are not being saved."
                    : "";
    }), state.busy.subscribe((jobs) => {
        const labels = Object.values(jobs);
        busy.hidden = labels.length === 0;
        fill(busy, el("span", { class: "topbar__spinner", "aria-hidden": "true" }), el("span", null, labels[0] ?? ""), labels.length > 1
            ? el("span", { class: "muted" }, ` +${labels.length - 1}`)
            : null);
    }), state.live.subscribe((live) => {
        node.classList.toggle("is-offline", !live);
    }));
    return { node, dispose: () => disposer.dispose() };
}
function fact(label, initial) {
    const value = el("span", { class: "topbar__value" }, initial);
    return {
        value,
        node: el("div", { class: "topbar__fact" }, el("span", { class: "label" }, label), value),
    };
}
/** `7:00` or `420` → seconds. Anything else is "no target". */
function parseTarget(raw) {
    const text = raw.trim();
    if (!text)
        return null;
    if (text.includes(":")) {
        const [minutes, seconds] = text.split(":");
        const total = Number(minutes) * 60 + Number(seconds ?? 0);
        return Number.isFinite(total) && total > 0 ? total : null;
    }
    const value = Number(text);
    return Number.isFinite(value) && value > 0 ? value : null;
}
