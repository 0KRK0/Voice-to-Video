/**
 * The project list.
 *
 * Deliberately plain. The Studio is the product; this is how you get back to
 * one, and any effort spent making it interesting is effort taken from the
 * screen people actually work in.
 *
 * The one column that carries weight is **state**, and it is served rather than
 * derived. "Ready with warnings" and "Ready" are different facts, and only the
 * server knows which applies — a client that inferred it from `status` alone
 * would tell a user their video was finished when three of its visuals failed.
 */
import { el, on } from "../core/dom.js";
import { attempt } from "../core/errors.js";
import { Disposer } from "../core/store.js";
import { clock, since } from "../core/format.js";
import { confirm } from "../widgets/dialog.js";
import { emptyState, skeleton } from "../widgets/states.js";
/** States that mean the project is still moving, and the list should follow. */
const LIVE = /^(queued|working|rendering|generating|planning|processing|transcri)/i;
export function projectsScreen(root, deps) {
    const disposer = new Disposer();
    const body = el("div", { class: "panel__body" }, skeleton("line", 5));
    let poll;
    /** The last list the server gave us, so search does not refetch. */
    let loaded = [];
    let query = "";
    /**
     * Search.
     *
     * Client-side, over the list already loaded, and that is the honest limit:
     * `/v1/projects` takes a `limit` and no query, so a server-side search would
     * be a box that silently only searched the first fifty. Filtering what is on
     * screen is smaller and never lies about its scope — the footer says how many
     * were searched.
     */
    const search = el("input", {
        class: "input projects__search",
        type: "search",
        placeholder: "Search projects",
        "aria-label": "Search projects by title",
    });
    disposer.add(on(search, "input", () => {
        query = search.value.trim().toLowerCase();
        paint();
    }));
    function matching() {
        if (!query)
            return loaded;
        return loaded.filter((item) => (item.title ?? "Untitled").toLowerCase().includes(query));
    }
    function paint() {
        if (loaded.length === 0) {
            body.replaceChildren(emptyState({
                title: "Nothing here yet",
                body: "Speak an idea, paste a script, or start from a document.",
                action: {
                    label: "New project",
                    onClick: () => deps.router.navigate("/"),
                },
            }));
            return;
        }
        const shown = matching();
        if (shown.length === 0) {
            body.replaceChildren(emptyState({
                title: "No project matches that",
                body: `Searched the ${loaded.length} projects on this page.`,
                action: {
                    label: "Clear the search",
                    onClick: () => {
                        search.value = "";
                        query = "";
                        paint();
                    },
                },
            }));
            return;
        }
        body.replaceChildren(table(shown, deps, load));
    }
    const load = async () => {
        const result = await attempt(() => deps.client.listProjects(), {
            retry: () => void load(),
        });
        if (!result) {
            body.replaceChildren(emptyState({
                title: "We could not load your projects",
                body: "The server did not answer. Nothing has been lost.",
                action: { label: "Try again", onClick: () => void load() },
            }));
            return;
        }
        loaded = result.projects;
        paint();
        // Follow anything still in flight, and stop as soon as everything settles.
        // A list that polls forever is a list that keeps a laptop awake.
        window.clearTimeout(poll);
        if (result.projects.some((item) => LIVE.test(item.state))) {
            poll = window.setTimeout(() => void load(), 4000);
        }
    };
    disposer.add(() => window.clearTimeout(poll));
    root.append(el("main", { class: "page" }, el("section", { class: "panel page__panel" }, el("header", { class: "panel__header" }, el("h2", null, "Projects"), el("div", { class: "spacer" }), search, el("a", { class: "btn btn--primary", href: "/" }, "New project")), body, el("footer", { class: "panel__footer muted" }, "Deleting a project deletes its recordings, uploads and renders. It ", "cannot be undone."))));
    void load();
    return disposer;
}
function table(projects, deps, reload) {
    return el("table", { class: "table projects" }, el("thead", null, el("tr", null, el("th", null, "Project"), el("th", null, "State"), el("th", null, "Length"), el("th", null, "Touched"), el("th", { class: "projects__actions-head" }, el("span", { class: "sr-only" }, "Actions")))), el("tbody", null, ...projects.map((project) => row(project, deps, reload))));
}
function row(project, deps, reload) {
    const href = `/studio/${project.project_id}`;
    const live = LIVE.test(project.state);
    const failed = /fail/i.test(project.state);
    const warned = /warning/i.test(project.state);
    return el("tr", null, el("td", null, el("a", { class: "projects__title", href }, project.title || "Untitled project")), el("td", {
        class: [
            "projects__state",
            live && "is-live",
            failed && "is-failed",
            warned && "is-warned",
        ],
    }, live
        ? el("span", { class: "projects__pulse", "aria-hidden": "true" })
        : null, project.state, live && project.progress > 0
        ? el("span", { class: "muted tabular" }, ` · ${Math.round(project.progress * 100)}%`)
        : null), el("td", { class: "tabular" }, clock(project.duration_seconds)), el("td", { class: "muted" }, since(project.updated_at)), el("td", { class: "projects__actions" }, el("button", {
        class: "btn btn--ghost btn--sm",
        type: "button",
        onclick: () => {
            void (async () => {
                const yes = await confirm({
                    title: "Delete this project?",
                    body: `“${project.title || "Untitled project"}” and everything in it ` +
                        "— recordings, uploads and renders — will be removed. This " +
                        "cannot be undone.",
                    affirm: "Delete",
                    danger: true,
                });
                if (!yes)
                    return;
                await attempt(() => deps.client.deleteProject(project.project_id));
                await reload();
            })();
        },
    }, "Delete")));
}
