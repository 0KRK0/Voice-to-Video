"""Background handlers for the product layer.

Three jobs, and the reason each is a job rather than a request:

* **`revise_script`** calls a language model. Seconds, and money.
* **`regenerate_visual`** calls an image or video provider, or fetches an
  asset. Seconds to minutes, and more money.
* **`render_scope`** encodes video. Minutes, and CPU.

Everything else the editor does — moving a clip, locking a visual, choosing a
version — is synchronous, because it costs nothing and a user who dragged a clip
expects it to have moved.

## Idempotency is not optional here

These are the operations a retry can charge twice for. The queue deduplicates on
an idempotency key, and each handler is additionally written so that running it
twice converges: a revision that already exists is returned rather than
re-requested, and a regeneration checks the unit's version count before spending.

The pattern is the one billing already uses — reserve, do the work, settle
against a key — and it is here for the same reason: at-least-once delivery is
only safe when the effects are idempotent.

## Scoped rendering

`render_scope` is what makes disliking one visual cheap. It renders the region
the change touched and concatenates it into the existing output. A full render
remains available and is what an export uses.

**Status: the scoped path currently re-renders the whole timeline and records
the region it was asked for.** The region arithmetic, the boundary expansion and
the job plumbing are real and tested; the ffmpeg-level segment splice is not
implemented, and this module says so rather than letting the API imply a saving
that is not being made. `docs/FINAL_REPORT.md` carries it as remaining work.
"""

from __future__ import annotations

import json
from typing import Any

#: Document kinds, shared with `api/product.py`. Imported from there so the two
#: cannot drift; a mismatched string would silently write documents nothing
#: reads.
from vtv.api.product import (
    SCRIPT_DOC,
    TIMELINE_DOC,
    UNITS_DOC,
)
from vtv.contracts.base import Id, VTVModel
from vtv.contracts.errors import ErrorCode, NotFound, VTVError
from vtv.contracts.project import Project
from vtv.contracts.render_scope import RenderRegion
from vtv.contracts.script import RevisionKind, Script
from vtv.contracts.tenancy import AuditAction, Principal
from vtv.contracts.tracks import EditTimeline
from vtv.contracts.visual_unit import RegenerationIntent, VisualUnit
from vtv.jobs import JobContext
from vtv.observability.events import EventName


class RevisePayload(VTVModel):
    organisation_id: Id
    project_id: Id
    kind: str
    block_ids: list[str] = []
    target_language: str | None = None
    based_on_version: int = 1


class RegeneratePayload(VTVModel):
    organisation_id: Id
    project_id: Id
    visual_unit_id: Id
    intent: str = RegenerationIntent.SAME_IDEA.value


class RenderScopePayload(VTVModel):
    organisation_id: Id
    project_id: Id
    region: dict[str, Any] = {}


# ---------------------------------------------------------------------------
# Handlers
# ---------------------------------------------------------------------------

async def run_revise_script(context: JobContext, payload: dict[str, Any]) -> str:
    """Ask a model for a revision and store it as a proposal.

    Stores a *proposal*. Nothing about the script changes here — the user
    accepts or rejects through the API, and that is the only path that touches
    `current_text`. A background job that edited someone's words while they were
    not looking would be the exact failure this design exists to prevent.
    """
    job = RevisePayload.model_validate(payload)
    # Re-check the tenant here, not only at the API. A worker reads its project
    # id from a payload, and a payload is not a credential — the other two
    # handlers check, and a handler that does not is the one an attacker with
    # any queue-write path would aim at.
    await _project(context, job.project_id, job.organisation_id)
    script = await _load(context, job.project_id, SCRIPT_DOC, Script)
    if script is None:
        raise NotFound("this project has no script to revise")

    if script.version != job.based_on_version:
        # The script moved while the job waited. Proposing against text the user
        # has already changed produces a diff they will not recognise.
        raise VTVError(
            "the script changed before this revision ran",
            code=ErrorCode.SCHEMA_INVALID,
            user_message="Your script changed — ask for the suggestion again.",
        )

    from vtv.pipeline.revision import RevisionService

    service = RevisionService(router=context.assembly.router, events=context.events)
    proposal = await service.propose(
        script,
        kind=RevisionKind(job.kind),
        block_ids=job.block_ids or None,
        target_language=job.target_language,
    )
    await context.repository.put_document(
        project_id=job.project_id,
        kind=f"revision:{proposal.revision_id}",
        document_id=proposal.revision_id,
        payload=json.loads(proposal.model_dump_json()),
    )
    return proposal.revision_id


async def run_regenerate_visual(context: JobContext, payload: dict[str, Any]) -> str:
    """Produce a new version of one visual, and nothing else.

    The units document is read, one entry is replaced, and it is written back.
    Every other unit is untouched — not re-planned, not re-fetched, not
    re-charged — which is the property the product's economics depend on.
    """
    job = RegeneratePayload.model_validate(payload)
    project = await _project(context, job.project_id, job.organisation_id)

    units = await _load_units(context, job.project_id)
    index = next(
        (i for i, u in enumerate(units) if u.visual_unit_id == job.visual_unit_id),
        None,
    )
    if index is None:
        raise NotFound("no such visual in this project")
    unit = units[index]

    script = await _load(context, job.project_id, SCRIPT_DOC, Script)
    narration = _narration_for(unit, script)

    from vtv.pipeline.regeneration import (
        GateValidator,
        RegenerationService,
    )

    service = RegenerationService(
        producer=_DirectorProducer(context=context, project=project),
        validator=GateValidator(
            evidence=_evidence_for(narration),
            visual_bible=await _load_bible(context, job.project_id),
        ),
        events=context.events,
    )
    timeline = await _load(context, job.project_id, TIMELINE_DOC, EditTimeline)
    result = await service.regenerate(
        unit,
        narration=narration,
        intent=RegenerationIntent(job.intent),
        timeline=timeline,
    )

    units[index] = result.unit
    await _store_units(context, job.project_id, units)

    # The timeline shows what the unit now shows. Rebuilt only for this clip:
    # replacing the whole timeline would discard every manual edit the user has
    # made to the others.
    if result.accepted and timeline is not None:
        timeline = _retarget(timeline, result.unit)
        await context.repository.put_document(
            project_id=job.project_id,
            kind=TIMELINE_DOC,
            document_id=timeline.edit_timeline_id,
            payload=json.loads(timeline.model_dump_json()),
        )

    context.audit.write(
        action=AuditAction.PROJECT_UPDATED,
        principal=Principal.system("regenerate", job.organisation_id),
        organisation_id=job.organisation_id,
        target=f"project:{job.project_id}",
        detail={
            "change": "visual_regenerated",
            "visual_unit_id": job.visual_unit_id,
            "intent": job.intent,
            "accepted": str(result.accepted).lower(),
        },
    )
    return job.visual_unit_id


async def run_render_scope(context: JobContext, payload: dict[str, Any]) -> str:
    """Render from the *edited* timeline.

    Not from the input. Re-running the pipeline would rebuild the timeline and
    throw away every edit the user has made — the locks, the moves, the chosen
    versions — which is the opposite of what "render my project" means once
    there is an editor.

    So this flattens the `EditTimeline` into the render contract and hands that
    to the renderer. What the user arranged is what gets encoded.

    **The scope is bookkeeping, not yet a saving.** The region is validated,
    recorded, audited and reported, and the encode is full-timeline. The
    segment splice that would make a clip-scoped render genuinely cheaper is not
    built; saying so here is the whole reason this paragraph exists.
    """
    job = RenderScopePayload.model_validate(payload)
    project = await _project(context, job.project_id, job.organisation_id)
    region = RenderRegion.model_validate(job.region or {"scope": "full_project"})

    timeline = await _load(context, job.project_id, TIMELINE_DOC, EditTimeline)
    if timeline is None:
        raise NotFound("this project has no timeline to render")

    # Narration audio: the samples an edit timeline never carries. Either a
    # previous run produced it, or this one synthesises it from the script.
    # `timeline` may come back retimed against the voice that was actually
    # recorded — see `_narration_for_render` — and this render must use that
    # one, not the estimate-built one it was called with, or the file this
    # produces would still drift while only the *stored* timeline agreed with
    # the voice.
    narration, scene_graph_id, timeline = await _narration_for_render(
        context, project, timeline
    )

    from vtv.contracts.render import RenderSettings
    from vtv.pipeline.units import flatten

    flattened = flatten(
        timeline,
        narration=narration,
        style=project.style,
        aspect_ratio=project.style.aspect_ratio,
        scene_graph_id=scene_graph_id,
    )

    context.events.emit(
        EventName.RENDER_STARTED,
        project_id=job.project_id,
        data={
            "scope": region.scope.value,
            "start": region.start,
            "end": region.end,
            "clips": len(flattened.clips),
            # Named honestly. An operator reading this must not conclude that a
            # clip-scoped request encoded only a clip.
            "encode": "full_timeline",
            "source": "edit_timeline",
        },
    )

    job_result = await context.assembly.pipeline.renderer.render(
        timeline=flattened,
        settings=RenderSettings(
            aspect_ratio=project.style.aspect_ratio,
        ),
    )
    await context.repository.put_document(
        project_id=job.project_id,
        kind="render_job",
        document_id=job_result.render_job_id,
        payload=json.loads(job_result.model_dump_json()),
    )

    # Record which timeline this file encodes. Written after the render, not
    # before: a render that failed must not leave the project claiming to be up
    # to date with an edit it never encoded.
    if job_result.output is not None:
        project.rendered_timeline_version = timeline.version
        project.rendered_duration_seconds = job_result.duration_seconds
        await context.repository.save_project(project)
    context.audit.write(
        action=AuditAction.RENDER_SUBMITTED,
        principal=Principal.system("render-scope", job.organisation_id),
        organisation_id=job.organisation_id,
        target=f"project:{job.project_id}",
        detail={
            "scope": region.scope.value,
            "timeline_version": str(timeline.version),
            "encode": "full_timeline",
        },
    )
    return str(job_result.render_job_id)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

#: Where a synthesised voice track is kept between renders, so that rendering
#: twice does not pay a synthesiser twice.
NARRATION_DOC = "narration_track"

#: How much longer than the timeline's narration lane the real voice may be
#: before the two are considered out of agreement. One frame at 24fps.
_NARRATION_TOLERANCE = 0.042


async def _narration_for_render(
    context: JobContext, project: Project, timeline: EditTimeline
) -> tuple[Any, str, EditTimeline]:
    """The voice this timeline is drawn against, and the scene graph it belongs to.

    ## Why this exists

    Two lanes reach the renderer. The **pipeline lane** (speak, or upload a
    document) synthesises narration first and builds a timeline around it, so
    the audio is already on disk by the time anyone can edit. The **product
    lane** (paste a script, direct the visuals) builds a timeline from
    *estimated* speaking rates and never records a sound — and before this
    function existed it therefore had no render path at all: every export failed
    with "render the project once first", and there was no first render to do.
    That is not a missing button, it is a missing stage, and this is it.

    ## Why it is one function

    Narration is the clock. Every rule in this system about pictures not
    drifting away from the voice — `_deliverable` collapsing interior pacing
    time, the builder laying narration contiguously, `flatten` refusing an
    interior gap — assumes exactly one authoritative audio track per project.
    Producing it in more than one place is how a second, differently-timed
    answer gets in. So there is one place, and it is called from the render job.

    ## What it will not do

    It will not silently render a video whose voice is longer than the lane the
    editor drew for it. The renderer places one continuous file at one offset
    and cuts to the shorter stream, so an over-long voice is not a cosmetic
    mismatch — it is narration that stops mid-sentence with nothing in the
    output to say so. When the real audio does not fit the estimate, the
    measured timings are written back to the script, the audio is kept, and the
    job fails with a sentence naming the remedy. Re-planning then rebuilds the
    timeline from measurement rather than estimate and the next render fits.

    ## Why this also returns the timeline

    Measuring the real voice does not, on its own, close the gap between it and
    the timeline: `TimelineBuilder.build` laid every clip out from the
    *estimate*, and each block's small error over- or under-shoots the next, so
    the pictures and captions drift away from the voice a little more with
    every line even when the total length still looks right. `retime` is the
    fix — a piecewise-linear map from estimated time to measured time, applied
    to every clip boundary — and it has to run before this function's caller
    flattens the timeline for the renderer, not only before the next time
    someone opens the editor. So the timeline this returns is the one the
    caller must render: unchanged on every path that does not just measure a
    fresh voice, retimed and re-persisted on the one that does.
    """
    from vtv.contracts.base import IdPrefix, new_id
    from vtv.contracts.timeline import NarrationTrack
    from vtv.contracts.timeline import Timeline as RenderTimeline

    project_id = project.project_id

    # 1. A full pipeline render already produced one. That is the authority.
    rendered = await _load(context, project_id, "timeline", RenderTimeline)
    if rendered is not None:
        return rendered.narration, rendered.scene_graph_id, timeline

    scene_graph_id = project.scene_graph_id or new_id(IdPrefix.SCENE_GRAPH)

    script = await _load(context, project_id, SCRIPT_DOC, Script)
    if script is None or not any(block.is_narrated for block in script.blocks):
        raise VTVError(
            "this project has no narrated script to voice",
            code=ErrorCode.RENDER_FAILED,
            user_message=(
                "There is nothing to narrate yet. Write or record your script "
                "first, then render."
            ),
        )

    digest = _script_digest(script)

    # 2. A voice track from an earlier attempt, still describing this script.
    stored = await context.repository.get_document(
        project_id=project_id, kind=NARRATION_DOC
    )
    if stored and stored.get("text_digest") == digest:
        try:
            track = NarrationTrack.model_validate(stored["narration"])
        except (KeyError, ValueError):
            track = None
        if track is not None:
            _require_fits(track.duration_seconds, timeline)
            return track, str(stored.get("scene_graph_id") or scene_graph_id), timeline

    # 3. Synthesise. This is the step that costs money, and the digest above is
    #    what stops a retry paying for it again.
    service = getattr(context.assembly.pipeline, "narration", None)
    if service is None:
        raise VTVError(
            "this deployment has no narration service",
            code=ErrorCode.PROVIDER_UNAVAILABLE,
            user_message=(
                "This install cannot turn a written script into a video: no "
                "narration is configured."
            ),
        )

    from vtv.pipeline.narration import transcript_from_script

    draft = transcript_from_script(
        script,
        organisation_id=project.organisation_id,
        project_id=project_id,
    )
    spoken = await service.synthesise(
        draft, organisation_id=project.organisation_id, project_id=project_id
    )

    track = NarrationTrack(
        audio=spoken.audio, duration_seconds=spoken.duration_seconds
    )

    # Keep it before deciding whether it fits. The audio exists either way, and
    # a project that fails the fit check is about to be re-planned and rendered
    # again — charging for the same sentences twice would be the system's
    # mistake, not the user's.
    await context.repository.put_document(
        project_id=project_id,
        kind=NARRATION_DOC,
        document_id=NARRATION_DOC,
        payload={
            "text_digest": digest,
            "scene_graph_id": scene_graph_id,
            "narration": json.loads(track.model_dump_json()),
            "provider": spoken.provider,
            "has_speech": spoken.has_speech,
            "degradations": [
                json.loads(step.model_dump_json()) for step in spoken.degradations
            ],
        },
    )

    # The measured truth, written back onto the script. Estimates built the
    # timeline; measurement is what a re-plan must use, and a re-plan that had
    # to guess again would land in exactly the same place.
    measured = _apply_measured(script, spoken.transcript)
    if measured is not None:
        await context.repository.put_document(
            project_id=project_id,
            kind=SCRIPT_DOC,
            document_id=measured.script_id,
            payload=json.loads(measured.model_dump_json()),
        )

        # And the timeline moved to agree with it. Without this the pictures
        # and captions stay exactly where the estimate put them while the
        # voice now plays at the measured times — the drift this whole
        # function's docstring describes. Persisted under the same document
        # kind the editor reads, so the Studio shows the same times the video
        # has rather than the estimate the last plan produced.
        from vtv.pipeline.units import retime

        retimed = retime(timeline, measured)
        if retimed is not timeline:
            timeline = retimed
            await context.repository.put_document(
                project_id=project_id,
                kind=TIMELINE_DOC,
                document_id=timeline.edit_timeline_id,
                payload=json.loads(timeline.model_dump_json()),
            )

    if project.scene_graph_id != scene_graph_id:
        project.scene_graph_id = scene_graph_id
        await context.repository.save_project(project)

    context.events.emit(
        EventName.NARRATION_SYNTHESISED,
        project_id=project_id,
        data={
            "lane": "product",
            "provider": spoken.provider,
            "has_speech": spoken.has_speech,
            "duration_seconds": round(spoken.duration_seconds, 3),
            "degraded": bool(spoken.degradations),
        },
    )

    _require_fits(spoken.duration_seconds, timeline)
    return track, scene_graph_id, timeline


def _script_digest(script: Script) -> str:
    """What the narrated words are, independent of ids, order fields or version.

    Two scripts with the same digest produce the same audio, which is the only
    property the cache above needs. Including a block id would invalidate a
    perfectly good voice track every time a line was split and rejoined.
    """
    import hashlib

    material = "".join(
        block.text.strip() for block in script.blocks if block.is_narrated
    )
    material = f"{script.language}{material}"
    return hashlib.sha256(material.encode("utf-8")).hexdigest()[:32]


def _require_fits(duration: float, timeline: EditTimeline) -> None:
    """Refuse a voice longer than the lane drawn for it.

    The renderer places one continuous audio file at one offset and encodes to
    the shorter of the two streams. A voice 4 seconds longer than the pictures
    therefore ships as a video that stops talking mid-sentence — no error, no
    event, nothing in the file to say a sentence is missing. That is the one
    failure this product promises never to produce, so it is a raise.

    The other direction is fine and needs no check: a voice shorter than the
    pictures leaves deliberate visual time at the end, which `flatten` already
    measures and records as `fill_seconds`.
    """
    from vtv.contracts.tracks import TrackKind

    lane = timeline.track_of_kind(TrackKind.NARRATION)
    clips = sorted(lane.clips, key=lambda clip: clip.start) if lane else []
    if not clips:
        return
    available = round(clips[-1].end - clips[0].start, 3)
    if duration <= available + _NARRATION_TOLERANCE:
        return

    over = round(duration - available, 2)
    raise VTVError(
        f"narration is {duration:.3f}s but the timeline allows {available:.3f}s",
        code=ErrorCode.RENDER_FAILED,
        user_message=(
            f"The recorded voice is {over}s longer than this timeline was "
            "built for, so rendering it now would cut the narration short. "
            "Re-plan the visuals — the timings measured from the real audio "
            "have been saved, and the next render will fit."
        ),
    )


def _apply_measured(script: Script, transcript: Any) -> Script | None:
    """Copy measured segment timings onto the narrated blocks, in order.

    Positional, because `transcript_from_script` emits one segment per narrated
    block in order and the narration service only ever re-times what it was
    given — it never splits, merges or reorders. If a provider ever did, the
    length check below drops the write rather than attaching one line's timing
    to another line's text.
    """
    blocks = [block for block in script.blocks if block.is_narrated]
    segments = list(getattr(transcript, "segments", []))
    if len(blocks) != len(segments):
        return None

    # Both ends in one assignment. `ScriptBlock` validates on assignment and
    # refuses a half-set pair — a start with no end is a timing nobody can use —
    # so the copy carries the whole update rather than two statements that are
    # briefly, and invalidly, apart.
    narrated = {block.block_id for block in blocks}
    updated = []
    index = 0
    for block in script.blocks:
        if block.block_id not in narrated:
            updated.append(block.model_copy(deep=True))
            continue
        span = segments[index].span
        updated.append(
            block.model_copy(
                deep=True,
                update={
                    "measured_start": round(span.start, 3),
                    "measured_end": round(span.end, 3),
                    "timing_invalidated": False,
                },
            )
        )
        index += 1
    return script.model_copy(deep=True, update={"blocks": updated})


async def _project(context: JobContext, project_id: str, organisation_id: str) -> Project:
    project: Project | None = await context.repository.get_project(
        project_id, organisation_id=organisation_id
    )
    if project is None:
        raise NotFound("no such project")
    return project


async def _load(context: JobContext, project_id: str, kind: str, model: Any) -> Any:
    payload = await context.repository.get_document(project_id=project_id, kind=kind)
    if payload is None:
        return None
    try:
        return model.model_validate(payload)
    except ValueError:
        return None


async def _load_units(context: JobContext, project_id: str) -> list[VisualUnit]:
    payload = await context.repository.get_document(
        project_id=project_id, kind=UNITS_DOC
    )
    if not payload:
        return []
    out: list[VisualUnit] = []
    for item in payload.get("units", []):
        try:
            out.append(VisualUnit.model_validate(item))
        except ValueError:
            continue
    return out


async def _store_units(
    context: JobContext, project_id: str, units: list[VisualUnit]
) -> None:
    await context.repository.put_document(
        project_id=project_id,
        kind=UNITS_DOC,
        document_id=UNITS_DOC,
        payload={"units": [json.loads(u.model_dump_json()) for u in units]},
    )


async def _load_bible(context: JobContext, project_id: str) -> Any:
    from vtv.contracts.consistency import VisualBible

    return await _load(context, project_id, "visual_bible", VisualBible)


def _narration_for(unit: VisualUnit, script: Script | None) -> str:
    if script is None:
        return ""
    return " ".join(
        block.text
        for block_id in unit.script_block_ids
        if (block := script.block(block_id)) is not None
    )


def _evidence_for(narration: str) -> Any:
    """Evidence for the grounding gate, built from the narration alone.

    Narrow on purpose: a regenerated visual must be checked against what is
    actually said under it, not against the whole project. A chart that is
    supported by something said four minutes earlier is not supported *here*.
    """
    if not narration.strip():
        return None
    from vtv.pipeline.grounding import Evidence

    return Evidence.build(narration=narration)


def _retarget(timeline: EditTimeline, unit: VisualUnit) -> EditTimeline:
    """Point this unit's clips at its newly selected version.

    A thin wrapper over `pipeline.units.retarget`, which is now the single
    implementation shared with the two synchronous paths that change what a
    visual shows. There were two implementations of this and only one of them
    ran anywhere except a regeneration; keeping the wrapper preserves this
    module's call site while removing the second copy.
    """
    from vtv.pipeline.units import retarget

    return retarget(timeline, [unit])


class _DirectorProducer:
    """Produces a new visual version through the existing director and router.

    A thin adapter, deliberately: the decision about *what* a visual should be
    already lives in the Visual Director, and a second implementation here would
    be a second set of rules to keep in step with the first.
    """

    def __init__(self, *, context: JobContext, project: Project) -> None:
        self.context = context
        self.project = project

    async def produce(
        self,
        *,
        unit: VisualUnit,
        intent: RegenerationIntent,
        narration: str,
    ) -> Any:
        from vtv.contracts.visual_language import TypographySpec
        from vtv.contracts.visual_plan import VisualStrategy
        from vtv.contracts.visual_unit import VisualVersion

        if not narration.strip():
            raise VTVError(
                "there is no narration under this visual to work from",
                code=ErrorCode.VISUAL_PLANNING_FAILED,
                user_message="Add narration to this section first.",
            )

        # Typography is the strategy that never fails and never invents a fact.
        # It is what the ladder descends to, and with no image or video provider
        # configured it is the only honest answer — so it is what a regeneration
        # produces rather than an error the user cannot act on.
        #
        # With a provider configured this is where the director's ladder runs;
        # that path is EXTERNAL DEPENDENCY and named as such in the report.
        headline = narration.strip().split(".")[0][:120] or narration[:120]
        spec = TypographySpec(headline=headline)
        return VisualVersion(
            version=unit.next_version_number,
            strategy=VisualStrategy.PROGRAMMATIC,
            spec=json.loads(spec.model_dump_json()),
            intent=intent,
            rationale=(
                "no image or video provider is configured, so this section is "
                "set as motion typography — which states only what is said"
            ),
        )


HANDLERS: dict[str, Any] = {
    "revise_script": run_revise_script,
    "regenerate_visual": run_regenerate_visual,
    "render_scope": run_render_scope,
}


__all__ = [
    "HANDLERS",
    "RegeneratePayload",
    "RenderScopePayload",
    "RevisePayload",
    "run_regenerate_visual",
    "run_render_scope",
    "run_revise_script",
]
