"""Runtime configuration.

Read from the environment once, at process start, and passed down explicitly.
Nothing deeper in the system reads ``os.environ`` — a module that reaches for a
global at import time cannot be tested twice with different settings.
"""

from __future__ import annotations

import os
from pathlib import Path

from pydantic import Field

from vtv.contracts.base import VTVModel

#: Any field whose name ends in one of these is a credential and is replaced in
#: `Settings.redacted`. A suffix rule rather than a list of field names, because
#: the list version only redacts the secrets somebody remembered to add to it —
#: `storage_secret_key` was added long after `redacted` was written and would
#: have been logged in the clear on every boot.
_SECRET_SUFFIXES = ("_api_key", "_key", "_secret", "_token", "_password")


class Settings(VTVModel):
    """Everything the process needs to know about where it is running."""

    env: str = "development"
    log_level: str = "info"

    # Storage -------------------------------------------------------------
    #: Which backend runs is decided by whether credentials are present, not by
    #: a `STORAGE_BACKEND` string. A name and a credential can disagree —
    #: `STORAGE_BACKEND=s3` with no secret key is a deployment that believes it
    #: is on S3 and is writing to a container filesystem that disappears on the
    #: next deploy. Credentials cannot disagree with themselves. See
    #: `wiring.storage_provider`.
    storage_root: Path = Path("./var/storage")
    storage_bucket: str = "vtv-media-dev"
    storage_endpoint: str | None = None
    storage_region: str = "us-east-1"
    storage_access_key: str | None = None
    storage_secret_key: str | None = None
    #: Path-style (`host/bucket/key`). MinIO and Ceph need it; AWS and R2 accept
    #: it. Set false only for a bucket whose name is a valid DNS label and whose
    #: endpoint expects virtual-hosted style.
    storage_path_style: bool = True

    # Datastores ----------------------------------------------------------
    #: Only ``sqlite:///`` is implemented. `wiring.repository_path` raises on
    #: anything else rather than silently substituting a local file — see the
    #: comment there, and P1-5 in docs/REMEDIATION.md for PostgreSQL.
    database_url: str = "sqlite:///./var/vtv.db"

    # Providers -----------------------------------------------------------
    # Credentials only. *Which* provider handles a request is a routing
    # decision made from declared capabilities, never a hard-coded choice.
    speech_to_text_api_key: str | None = None
    speech_to_text_endpoint: str | None = None
    speech_synthesis_api_key: str | None = None
    speech_synthesis_endpoint: str | None = None
    speech_synthesis_model: str = "unset"
    speech_synthesis_voice: str = "alloy"
    text_generation_api_key: str | None = None
    text_generation_endpoint: str | None = None
    text_generation_model: str = "unset"
    image_generation_api_key: str | None = None
    image_generation_endpoint: str | None = None
    video_generation_api_key: str | None = None
    video_generation_endpoint: str | None = None
    asset_search_endpoint: str = "https://api.openverse.org/v1"

    # Budgets and limits --------------------------------------------------
    max_project_cost_usd: float = 1.00
    max_recording_seconds: float = 1800.0
    temporary_retention_hours: int = 24
    max_upload_bytes: int = 200 * 1024 * 1024

    # Rendering -----------------------------------------------------------
    renderer: str = "ffmpeg"  # ffmpeg | remotion
    remotion_project_dir: Path = Path("./apps/remotion")

    # Security ------------------------------------------------------------
    allowed_origins: list[str] = Field(default_factory=lambda: ["http://localhost:8000"])
    signed_url_seconds: int = 900

    #: HMAC key for signed media URLs. Must be identical across every replica:
    #: with a per-process key, a URL signed by one pod is rejected by the next,
    #: so a customer's video download fails roughly half the time behind a load
    #: balancer. `wiring.build` generates one in development and refuses to
    #: start without it in production — an ephemeral key is a correctness bug,
    #: not a convenience.
    signing_key: str | None = None

    @property
    def is_production(self) -> bool:
        return self.env == "production"

    @classmethod
    def from_env(cls, environ: dict[str, str] | None = None) -> Settings:
        source = environ if environ is not None else dict(os.environ)

        def get(key: str) -> str | None:
            value = source.get(f"VTV_{key}")
            return value if value else None

        def path(key: str, default: Path) -> Path:
            raw = get(key)
            return Path(raw) if raw else default

        def number(key: str, default: float) -> float:
            raw = get(key)
            return float(raw) if raw else default

        origins = get("ALLOWED_ORIGINS")
        return cls(
            env=get("ENV") or "development",
            log_level=get("LOG_LEVEL") or "info",
            storage_root=path("STORAGE_ROOT", Path("./var/storage")),
            storage_bucket=get("STORAGE_BUCKET") or "vtv-media-dev",
            storage_endpoint=get("STORAGE_ENDPOINT"),
            storage_region=get("STORAGE_REGION") or "us-east-1",
            storage_access_key=get("STORAGE_ACCESS_KEY"),
            storage_secret_key=get("STORAGE_SECRET_KEY"),
            storage_path_style=(get("STORAGE_PATH_STYLE") or "true").lower()
            not in {"false", "0", "no"},
            database_url=get("DATABASE_URL") or "sqlite:///./var/vtv.db",
            signing_key=get("SIGNING_KEY"),
            signed_url_seconds=int(number("SIGNED_URL_SECONDS", 900)),
            max_upload_bytes=int(number("MAX_UPLOAD_BYTES", 200 * 1024 * 1024)),
            speech_to_text_api_key=get("SPEECH_TO_TEXT_API_KEY"),
            speech_to_text_endpoint=get("SPEECH_TO_TEXT_ENDPOINT"),
            speech_synthesis_api_key=get("SPEECH_SYNTHESIS_API_KEY"),
            speech_synthesis_endpoint=get("SPEECH_SYNTHESIS_ENDPOINT"),
            speech_synthesis_model=get("SPEECH_SYNTHESIS_MODEL") or "unset",
            speech_synthesis_voice=get("SPEECH_SYNTHESIS_VOICE") or "alloy",
            text_generation_api_key=get("TEXT_GENERATION_API_KEY"),
            text_generation_endpoint=get("TEXT_GENERATION_ENDPOINT"),
            text_generation_model=get("TEXT_GENERATION_MODEL") or "unset",
            image_generation_api_key=get("IMAGE_GENERATION_API_KEY"),
            image_generation_endpoint=get("IMAGE_GENERATION_ENDPOINT"),
            video_generation_api_key=get("VIDEO_GENERATION_API_KEY"),
            video_generation_endpoint=get("VIDEO_GENERATION_ENDPOINT"),
            asset_search_endpoint=get("ASSET_SEARCH_ENDPOINT")
            or "https://api.openverse.org/v1",
            max_project_cost_usd=number("MAX_PROJECT_COST_USD", 1.00),
            max_recording_seconds=number("MAX_RECORDING_SECONDS", 1800.0),
            temporary_retention_hours=int(number("TEMPORARY_RETENTION_HOURS", 24)),
            renderer=get("RENDERER") or "ffmpeg",
            remotion_project_dir=path("REMOTION_PROJECT_DIR", Path("./apps/remotion")),
            allowed_origins=(
                [o.strip() for o in origins.split(",")]
                if origins
                else ["http://localhost:8000"]
            ),
        )

    def redacted(self) -> dict[str, object]:
        """Loggable view. Every credential is replaced, never truncated —
        a truncated secret is still a leaked secret."""
        payload = self.model_dump(mode="json")
        for key in list(payload):
            if key.endswith(_SECRET_SUFFIXES):
                payload[key] = "***set***" if payload[key] else None
        return payload


__all__ = ["Settings"]
