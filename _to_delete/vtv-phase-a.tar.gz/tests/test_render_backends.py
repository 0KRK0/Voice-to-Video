"""Phase A: more than one place to render, and nothing else changed.

Two claims, and the second is the one that matters.

**The abstraction works.** Segments are drawn through a `RenderBackend`, the
chain is descended per segment, and a backend that cannot do something is
followed by one that can.

**The output is identical.** Phase A's entire job is to change where a frame can
be composed without changing the frame. That is checked by the frame-for-frame
comparisons already in `test_render_segments` — pooled against inline, resumed
against whole — which now run through this code, plus the direct comparison
below of a rendered frame against the composer's own output.

The fake backends here fail in specific, named ways, because the interesting
behaviour is not "does a backend run" but "what happens when one of them will
not". A backend that only ever succeeds tells you nothing about a graphics card
running out of memory in the fortieth minute.
"""

from __future__ import annotations

import pickle
import unittest
from dataclasses import dataclass, field
from pathlib import Path
from tempfile import TemporaryDirectory

from vtv.adapters.render.cpu_backend import CpuRenderBackend, workers_for
from vtv.adapters.render.ffmpeg_renderer import run_segment
from vtv.contracts.execution import ExecutionPolicy, ExecutionTarget, Registry
from vtv.ports.rendering import RenderBackend, RenderCapabilities, SegmentOutcome


@dataclass
class Fake:
    """A backend that does exactly what it is told, and remembers being asked."""

    where: ExecutionTarget
    outcome: SegmentOutcome = field(default_factory=SegmentOutcome.done)
    asked: list[int] = field(default_factory=list)

    @property
    def target(self) -> ExecutionTarget:
        return self.where

    def capabilities(self) -> RenderCapabilities:
        return RenderCapabilities(target=self.where)

    def render_segment(
        self, scratch: str, index: int, start_frame: int, end_frame: int
    ) -> SegmentOutcome:
        del scratch, start_frame, end_frame
        self.asked.append(index)
        return self.outcome


def chain(*backends: Fake) -> list[tuple[ExecutionTarget, object]]:
    return [(backend.where, backend) for backend in backends]


class TheCpuBackendIsAValidBackend(unittest.TestCase):
    """The floor of every chain. If this is not a real implementation of the
    port, nothing below it is worth testing."""

    def test_it_satisfies_the_protocol(self) -> None:
        self.assertIsInstance(CpuRenderBackend(), RenderBackend)

    def test_it_refuses_nothing(self) -> None:
        """It is the end of the fallback chain, so it must never be the reason
        a chain runs out. A backend that cannot draw something falls back to
        one that can, and the chain has to terminate somewhere unconditional."""
        capabilities = CpuRenderBackend().capabilities()
        self.assertEqual(capabilities.unsupported, frozenset())
        self.assertIsNone(capabilities.max_pixels)
        self.assertTrue(capabilities.can_draw(["text", "image", "chart", "anything"]))

    def test_an_unmeasured_backend_reports_none_not_zero(self) -> None:
        """"Nobody has timed this" and "this is useless" are different facts,
        and a selector reading the first as the second would refuse hardware it
        has never tried."""
        self.assertIsNone(CpuRenderBackend().capabilities().frames_per_second)

    def test_it_survives_being_sent_to_a_pool_worker(self) -> None:
        """On Windows a pool spawns rather than forks, so the backend is
        pickled to the child. A backend holding a storage handle or an open
        file would fail here — or, worse, pickle a copy and behave differently
        in the worker than in the parent."""
        backend = CpuRenderBackend(
            where=ExecutionTarget.LOCAL_CPU, hardware_encoder="h264_nvenc"
        )
        self.assertEqual(pickle.loads(pickle.dumps(backend)), backend)

    def test_workers_are_capped_in_one_place(self) -> None:
        self.assertEqual(workers_for(1), 1)
        self.assertEqual(workers_for(4), 4)
        self.assertEqual(workers_for(64), 8)


class TheChainIsDescendedPerSegment(unittest.TestCase):
    """The granularity at which hardware actually fails.

    A graphics card that runs out of memory on one dense shot has not made the
    video impossible. With segments already checkpointed, a failed attempt
    costs one segment rather than the render — which is what makes shipping a
    GPU backend a reasonable risk rather than a bet on somebody's driver.
    """

    def test_the_first_backend_that_works_is_used(self) -> None:
        first = Fake(ExecutionTarget.LOCAL_GPU)
        second = Fake(ExecutionTarget.LOCAL_CPU)
        failure, target, after = run_segment(chain(first, second), "s", 0, 0, 10)
        self.assertEqual(failure, "")
        self.assertEqual(target, "local_gpu")
        self.assertEqual(after, "")
        self.assertEqual(second.asked, [], "the second backend was asked anyway")

    def test_a_backend_that_says_elsewhere_is_followed_by_another(self) -> None:
        gpu = Fake(
            ExecutionTarget.LOCAL_GPU,
            SegmentOutcome.failed("out of video memory", elsewhere=True),
        )
        cpu = Fake(ExecutionTarget.LOCAL_CPU)
        failure, target, after = run_segment(chain(gpu, cpu), "s", 7, 0, 10)
        self.assertEqual(failure, "")
        self.assertEqual(target, "local_cpu")
        # The fallback is reported, never silent: a render that quietly moved
        # to different hardware is one whose timing nobody can explain.
        self.assertEqual(after, "out of video memory")
        self.assertEqual(cpu.asked, [7])

    def test_a_backend_that_does_not_is_the_end_of_it(self) -> None:
        """A timeline referencing a missing asset fails identically everywhere.
        Retrying each backend turns one clear error into several slow ones."""
        gpu = Fake(
            ExecutionTarget.LOCAL_GPU, SegmentOutcome.failed("that clip has no asset")
        )
        cpu = Fake(ExecutionTarget.LOCAL_CPU)
        failure, target, _ = run_segment(chain(gpu, cpu), "s", 0, 0, 10)
        self.assertEqual(failure, "that clip has no asset")
        self.assertEqual(target, "")
        self.assertEqual(cpu.asked, [], "a hopeless failure was retried elsewhere")

    def test_running_out_of_backends_says_so(self) -> None:
        gpu = Fake(
            ExecutionTarget.LOCAL_GPU, SegmentOutcome.failed("no memory", elsewhere=True)
        )
        failure, target, _ = run_segment(chain(gpu), "s", 3, 0, 10)
        self.assertEqual(failure, "no memory")
        self.assertEqual(target, "")

    def test_an_empty_chain_fails_with_a_sentence(self) -> None:
        failure, _, _ = run_segment([], "s", 12, 0, 10)
        self.assertIn("12", failure)
        self.assertIn("backend", failure)


class TheChainComesFromThePolicy(unittest.TestCase):
    def registry(self, *targets: ExecutionTarget) -> Registry:
        found = Registry()
        for target in targets:
            found.register(target, Fake(target))
        return found

    def test_auto_prefers_the_customers_own_machine(self) -> None:
        found = self.registry(ExecutionTarget.CLOUD_CPU, ExecutionTarget.LOCAL_CPU)
        order = [t for t, _ in found.chain(ExecutionPolicy.auto())]
        self.assertEqual(order[0], ExecutionTarget.LOCAL_CPU)

    def test_everything_available_is_in_the_chain(self) -> None:
        """A fallback list that omits a working backend is a render that fails
        while something that could have finished it sat idle."""
        found = self.registry(ExecutionTarget.CLOUD_CPU, ExecutionTarget.LOCAL_GPU)
        order = [t for t, _ in found.chain(ExecutionPolicy.auto())]
        self.assertEqual(len(order), 2)

    def test_strict_means_no_chain_at_all(self) -> None:
        """"Never run this in the cloud" is a real requirement, and a chain
        that quietly appends the cloud to it is a policy that does nothing."""
        found = self.registry(ExecutionTarget.CLOUD_CPU, ExecutionTarget.LOCAL_CPU)
        order = [
            t
            for t, _ in found.chain(
                ExecutionPolicy.exactly(ExecutionTarget.LOCAL_CPU, strict=True)
            )
        ]
        self.assertEqual(order, [ExecutionTarget.LOCAL_CPU])

    def test_a_chain_survives_pickling(self) -> None:
        """It is handed to a pool worker whole."""
        found = Registry()
        found.register(ExecutionTarget.CLOUD_CPU, CpuRenderBackend())
        restored = pickle.loads(pickle.dumps(found.chain(ExecutionPolicy.auto())))
        self.assertEqual(restored[0][0], ExecutionTarget.CLOUD_CPU)


class SpeedIsMeasuredNotLookedUp(unittest.TestCase):
    """Choosing hardware by name is wrong often enough to matter: a card can be
    present and driverless, present and saturated, or present and slower than
    eight cores on a typography-heavy video."""

    def setUp(self) -> None:
        from vtv.pipeline import calibration

        calibration.forget()

    def measurement(self, target: str, fps: float):  # type: ignore[no-untyped-def]
        from vtv.pipeline.calibration import Measurement

        return Measurement(target=target, frames_per_second=fps, frames=24)

    def test_a_materially_faster_backend_wins(self) -> None:
        from vtv.pipeline.calibration import better

        self.assertEqual(
            better(
                [self.measurement("cloud_cpu", 20.0), self.measurement("local_gpu", 90.0)],
                "cloud_cpu",
            ),
            "local_gpu",
        )

    def test_a_tie_goes_to_the_incumbent(self) -> None:
        """Below the threshold the difference is inside the noise of a
        quarter-second sample, and switching adds a class of failure — a
        driver, a memory ceiling, a fallback — that the slower path lacks."""
        from vtv.pipeline.calibration import better

        self.assertEqual(
            better(
                [self.measurement("cloud_cpu", 20.0), self.measurement("local_gpu", 21.0)],
                "cloud_cpu",
            ),
            "cloud_cpu",
        )

    def test_nothing_measured_changes_nothing(self) -> None:
        from vtv.pipeline.calibration import better

        self.assertEqual(better([], "cloud_cpu"), "cloud_cpu")

    def test_the_report_is_empty_rather_than_invented(self) -> None:
        from vtv.pipeline.calibration import report

        self.assertEqual(report()["measured"], [])

    def test_a_real_context_can_be_timed(self) -> None:
        """The measurement is of composition, not of a whole segment: encoding
        is the part that does not differ between a processor and a card."""
        from vtv.adapters.render.ffmpeg_renderer import RenderContext
        from vtv.contracts.render import RenderQuality, RenderSettings
        from vtv.pipeline.calibration import compose_rate

        from tests.test_render_segments import plain_timeline
        from vtv.contracts.base import ObjectRef

        timeline = plain_timeline(
            ObjectRef(bucket="b", key="n.wav", content_type="audio/wav")
        )
        with TemporaryDirectory() as tmp:
            context = RenderContext(
                timeline=timeline,
                settings=RenderSettings(quality=RenderQuality.PREVIEW, frame_rate=24),
                scratch=Path(tmp),
                assets={},
            )
            rate = compose_rate(context, frames=6)
        self.assertGreater(rate, 0.0)
        self.assertLess(rate, 100_000.0)


if __name__ == "__main__":  # pragma: no cover
    unittest.main()


@dataclass(frozen=True)
class FlakyGpu:
    """Stands in for a graphics card that fails on one segment.

    Frozen and module-level so it pickles into a pool worker, like a real
    backend must. It delegates nothing: the segment it refuses is finished by
    whatever comes next in the chain.
    """

    fails_on: int = 1
    where: ExecutionTarget = ExecutionTarget.LOCAL_GPU

    @property
    def target(self) -> ExecutionTarget:
        return self.where

    def capabilities(self) -> RenderCapabilities:
        return RenderCapabilities(target=self.where)

    def render_segment(
        self, scratch: str, index: int, start_frame: int, end_frame: int
    ) -> SegmentOutcome:
        if index == self.fails_on:
            return SegmentOutcome.failed(
                f"segment {index}: out of video memory", elsewhere=True
            )
        # Everything else it "renders" by handing straight to the CPU path, so
        # that this test is about the fallback and not about a second renderer.
        return CpuRenderBackend().render_segment(
            scratch, index, start_frame, end_frame
        )


@unittest.skipUnless(
    __import__("vtv.adapters.media", fromlist=["ffmpeg"]).ffmpeg.is_available(),
    "ffmpeg is required",
)
class FallingBackProducesTheSameVideo(unittest.TestCase):
    """The property that makes per-segment fallback safe rather than merely
    clever.

    If a render that lost its graphics card halfway produced a *slightly*
    different video from one that never had it, the feature would be a source
    of bugs nobody could reproduce — the seam would be in a different place
    every run. Frames composed on different hardware have to be the same
    frames, and until a second compositor exists that is trivially true; this
    test is what will fail on the day it stops being.
    """

    def render(self, root: Path, name: str, chain_backends: list[object]) -> str:
        from vtv.adapters.render.ffmpeg_renderer import FfmpegRenderer
        from vtv.adapters.storage.local import LocalStorageProvider
        from vtv.contracts.render import RenderQuality, RenderSettings
        from vtv.observability.events import EventSink

        from tests.test_render_segments import (
            SEGMENT_SECONDS,
            picture_of,
            run,
            stored_timeline,
        )

        storage = LocalStorageProvider(root / f"storage-{name}")
        timeline = stored_timeline(storage, root)
        registry = Registry()
        for backend in chain_backends:
            registry.register(backend.target, backend)  # type: ignore[attr-defined]
        job = run(
            FfmpegRenderer(
                storage=storage,
                events=EventSink(),
                workdir=root / name,
                workers=1,
                segment_seconds=SEGMENT_SECONDS,
                backends=registry,
            ).render(
                timeline=timeline,
                settings=RenderSettings(
                    quality=RenderQuality.PREVIEW, frame_rate=24
                ),
            )
        )
        self.job = job
        assert job.output is not None
        return picture_of(storage.path_for(job.output))

    def test_a_render_that_fell_back_matches_one_that_did_not(self) -> None:
        with TemporaryDirectory(prefix="vtv-fallback-") as directory:
            root = Path(directory)
            plain = self.render(root, "plain", [CpuRenderBackend()])
            fell_back = self.render(
                root, "fallback", [FlakyGpu(), CpuRenderBackend()]
            )
        self.assertEqual(plain, fell_back)

    def test_the_record_says_which_hardware_drew_what(self) -> None:
        """"Did my graphics card do this?" is a question the product should be
        able to answer about its own output."""
        with TemporaryDirectory(prefix="vtv-fallback-record-") as directory:
            self.render(Path(directory), "record", [FlakyGpu(), CpuRenderBackend()])
        counted = self.job.backends
        self.assertGreater(counted.get("local_gpu", 0), 0, counted)
        # Exactly the one segment the card refused went to the processor.
        self.assertEqual(counted.get("cloud_cpu", 0), 1, counted)
