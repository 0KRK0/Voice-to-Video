"""Where a finished video lives on the computer that drew it.

## Why there is a module for choosing a folder

Because until now there was not one, and the consequence was the largest
architectural hole in the desktop path. `JobExecutor.execute` finished a render,
uploaded it, and then did this:

    shutil.rmtree(job_root, ignore_errors=True)

The finished MP4 was inside `job_root`. So a customer's own computer drew a
four-hour video, sent a copy to the cloud, and deleted the original — leaving
the only durable copy of the file in the one place the storage model says
renders are *not* kept:

    permanent, in the cloud:  project, script, timeline, decisions, devices,
                              billing, usage
    temporary, in the cloud:  segments, working audio, previews, cloud renders
    the customer's own:       the finished video, their source media, the cache

Every part of that was implemented except the last line, and the last line is
the one the product is sold on.

## What "kept" has to mean to be worth anything

**Somewhere a person can find it without being told.** A file under
`%LOCALAPPDATA%\\VoiceToVideo\\work\\ren_01H…\\storage\\org\\prj\\…mp4` is
technically kept and practically lost. The default is the videos folder the
operating system already has, and the name carries the project's title and the
date.

**Not the scratch directory.** Scratch is keyed by render job and deleted when
the job is done, which is correct — segments are checkpoints and checkpoints
are litter once the thing they were checkpoints towards exists. The deliverable
has to leave that tree before the tree is removed.

**Never overwriting.** Two renders of the same project on the same day are two
files. A person who renders, watches, edits and renders again has not asked for
their first version to be destroyed, and silently replacing it is the kind of
data loss nobody reports because they do not notice.

## What this deliberately does not do

It does not sync, index, clean up or enforce a size limit. The customer's disk
is the customer's. A product that started deleting videos out of somebody's
videos folder to save space would be doing the single most alarming thing a
video tool can do.
"""

from __future__ import annotations

import os
import re
import shutil
import sys
from datetime import datetime
from pathlib import Path

#: What the folder is called wherever it ends up. The product's name, because
#: the person looking at it in a file manager needs to know what put it there.
FOLDER_NAME = "Voice to Video"

#: Characters no mainstream filesystem will take in a name, plus the ones
#: Windows reserves. Replaced rather than dropped, so two titles differing only
#: in punctuation do not collide.
_UNSAFE = re.compile(r'[<>:"/\\|?*\x00-\x1f]')

#: Windows will not create a file with these stems, whatever the extension.
_RESERVED = {
    "con", "prn", "aux", "nul",
    *(f"com{n}" for n in range(1, 10)),
    *(f"lpt{n}" for n in range(1, 10)),
}

#: Long enough for a real title, short enough that the whole path stays inside
#: the limit a default Windows install still enforces.
MAX_STEM = 80


def videos_root() -> Path:
    """The folder this operating system keeps videos in.

    `VTV_LIBRARY` wins, for the machine somebody has deliberately pointed at a
    second disk — which is a normal thing to want when the files are gigabytes.

    Falls back to the configuration directory rather than inventing a folder in
    somebody's home. A render node in a container has no videos folder, and
    creating `~/Videos` on a machine that never had one is a program taking a
    liberty with a filesystem that is not its own.
    """
    override = os.environ.get("VTV_LIBRARY")
    if override:
        return Path(override).expanduser()

    home = Path.home()
    candidates: list[Path] = []
    if sys.platform == "win32":
        profile = os.environ.get("USERPROFILE")
        if profile:
            candidates.append(Path(profile) / "Videos")
        candidates.append(home / "Videos")
    elif sys.platform == "darwin":
        candidates.append(home / "Movies")
    else:
        # `xdg-user-dirs` writes this; reading it is how the folder is found on
        # a system where it is called something other than "Videos".
        config = Path(
            os.environ.get("XDG_CONFIG_HOME") or (home / ".config")
        ) / "user-dirs.dirs"
        with _quiet():
            if config.exists():
                for line in config.read_text(encoding="utf-8").splitlines():
                    if line.startswith("XDG_VIDEOS_DIR="):
                        raw = line.split("=", 1)[1].strip().strip('"')
                        candidates.append(
                            Path(raw.replace("$HOME", str(home))).expanduser()
                        )
        candidates.append(home / "Videos")

    for candidate in candidates:
        if candidate.is_dir():
            return candidate / FOLDER_NAME

    from vtv.desktop import state

    return state.config_root() / "library"


class _quiet:
    """Suppress anything a best-effort filesystem read can raise."""

    def __enter__(self) -> None:
        return None

    def __exit__(self, *_: object) -> bool:
        return True


def safe_stem(title: str, fallback: str) -> str:
    """A filename a person recognises, that every filesystem will accept."""
    cleaned = _UNSAFE.sub("-", title or "").strip().strip(". ")
    cleaned = re.sub(r"\s+", " ", cleaned)[:MAX_STEM].strip()
    if not cleaned or cleaned.lower() in _RESERVED:
        return fallback
    return cleaned


def unique(folder: Path, stem: str, suffix: str = ".mp4") -> Path:
    """A path in `folder` that does not exist yet.

    Numbered rather than timestamped-to-the-second, because the collision this
    resolves is a person rendering the same project twice in one day and the
    answer they expect is "(2)", not a different-looking name.
    """
    candidate = folder / f"{stem}{suffix}"
    if not candidate.exists():
        return candidate
    for index in range(2, 1000):
        candidate = folder / f"{stem} ({index}){suffix}"
        if not candidate.exists():
            return candidate
    # A thousand renders of one project on one day. Fall back to something that
    # cannot collide rather than refusing to keep the video.
    return folder / f"{stem} ({datetime.now():%H%M%S%f}){suffix}"


def keep(
    source: Path,
    *,
    title: str,
    project_id: str,
    root: Path | None = None,
    when: datetime | None = None,
) -> Path:
    """Move a finished render out of scratch and into the library. Returns where.

    A move rather than a copy, so a two-gigabyte file is not written twice and
    so the scratch tree that is about to be deleted no longer holds the only
    copy at any point. `shutil.move` falls back to copy-and-delete by itself
    when the library is on another disk, which it often is — that is the whole
    reason somebody sets `VTV_LIBRARY`.
    """
    moment = when or datetime.now()
    folder = Path(root) if root is not None else videos_root()
    folder.mkdir(parents=True, exist_ok=True)

    stem = f"{safe_stem(title, project_id)} {moment:%Y-%m-%d}"
    target = unique(folder, stem, source.suffix or ".mp4")
    shutil.move(str(source), str(target))
    return target


__all__ = ["FOLDER_NAME", "MAX_STEM", "keep", "safe_stem", "unique", "videos_root"]
