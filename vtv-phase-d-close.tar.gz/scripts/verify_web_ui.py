"""The web application, in a real browser, against a real everything.

    python scripts/verify_web_ui.py

## Why this exists

Phase D passed eighteen checks over real HTTP and the browser had never been
opened once. Those are not the same thing and the difference is not cosmetic:
`verify_phase_d.py` asks the server questions and the server answered them all
correctly. A screen that never renders, a button wired to nothing, a link a
browser cannot authenticate — every one of those is invisible to a check that
speaks HTTP, because the HTTP is fine.

So this owns the same three processes `verify_recovery.py` owns — a server, a
seeded project, a desktop — and adds the one thing missing: a real Chromium,
loading the real built bundle, clicking the real controls.

It walks the path a first customer walks, in order:

    sign in → see there are no computers → run the desktop → approve it in the
    browser → see it listed → choose "on my computer" → open the Studio →
    press Render → watch it → play the video that machine drew

## Two decisions worth stating

**The desktop is paired through the browser, not with a code from a script.**
`Scene.pair()` mints a code over HTTP because that is all a Python harness can
do. The browser flow — the one modelled on how a desktop application signs a
person in — has a screen in the middle of it, and that screen is exactly what
has never been exercised.

**Nothing is asserted from a screenshot.** Screenshots are written next to every
check and are evidence, not proof. What is asserted is that the preference
survived a reload, that the render request on the wire asked for the device, and
that the bytes behind the download link decode as a video with a duration.
"""

from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from verify_recovery import ROOT, Scene  # noqa: E402

#: Printed by `vtv-desktop pair` before it starts polling.
APPROVE_LINE = re.compile(r"Approve this computer at:\s+(\S+)")


def _post(url: str, payload: dict) -> tuple[int, str]:
    request = urllib.request.Request(
        url,
        data=json.dumps(payload).encode(),
        headers={"content-type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            return response.status, response.read().decode()
    except urllib.error.HTTPError as error:
        return error.code, error.read().decode()
    except Exception as error:  # noqa: BLE001
        return 0, str(error)


def mint_key(base: str) -> str:
    """An administrator's key, because managing computers is an admin act.

    Deliberately not the default `service` role. A service key cannot list
    devices — `DEVICE_MANAGE` belongs to admins and owners — and signing the
    browser in with one would test the error state rather than the feature.
    That error state is worth having and the Computers screen states it in a
    sentence; it is simply not what this walk is for.
    """
    status, body = _post(f"{base}/v1/api-keys", {"name": "web walk", "role": "admin"})
    if status not in (200, 201):
        raise SystemExit(f"could not mint an API key ({status}): {body[:300]}")
    return json.loads(body)["secret"]


def start_pairing(scene: Scene) -> tuple[subprocess.Popen, str, Path]:
    """Run the desktop's browser pairing and read the URL it prints.

    Returns while the process is still polling for approval — which is the
    state a person is in while they walk to their browser, and the state the
    approval screen has to work in.
    """
    log = scene.root / "pair.log"
    handle = log.open("wb")
    process = subprocess.Popen(
        [
            sys.executable, "-m", "vtv.desktop.cli", "pair",
            "--server", scene.base, "--name", "web walk", "--skip-gpu-check",
        ],
        cwd=ROOT, env={**scene.env, "VTV_NO_BROWSER": "1"},
        stdout=handle, stderr=subprocess.STDOUT,
    )

    deadline = time.monotonic() + 120
    while time.monotonic() < deadline:
        if log.exists():
            found = APPROVE_LINE.search(log.read_text(encoding="utf-8", errors="replace"))
            if found:
                return process, found.group(1), log
        if process.poll() is not None:
            break
        time.sleep(0.5)

    text = log.read_text(encoding="utf-8", errors="replace") if log.exists() else ""
    process.kill()
    raise SystemExit(f"the desktop never printed an approval URL:\n{text[:800]}")


def run_walk(scene: Scene, args: argparse.Namespace, phase: str, **extra: str) -> int:
    command = [
        # Inside `apps/web` rather than beside this file: Node resolves
        # `import "playwright"` from the *script's* directory, not the working
        # directory, so a walker living in `scripts/` cannot see the web
        # application's own dependencies.
        "node", str(ROOT / "apps" / "web" / "scripts" / "web-walk.mjs"),
        "--base", scene.base,
        "--phase", phase,
        "--shots", str(args.shots),
        "--render-timeout", str(args.render_timeout),
    ]
    for name, value in extra.items():
        command += [f"--{name}", value]
    result = subprocess.run(command, cwd=ROOT / "apps" / "web")
    return result.returncode


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8134)
    parser.add_argument("--seconds", type=float, default=20.0,
                        help="length of the seeded narration")
    parser.add_argument("--shots", default=str(ROOT / "var" / "web-walk"),
                        help="where screenshots and results.json go")
    parser.add_argument("--render-timeout", type=int, default=900)
    parser.add_argument("--keep", action="store_true")
    parser.add_argument("--skip-build", action="store_true",
                        help="use apps/web/dist as it stands")
    args = parser.parse_args(argv)

    if not args.skip_build:
        print("building the web application...", flush=True)
        built = subprocess.run(
            ["npm", "run", "build"], cwd=ROOT / "apps" / "web",
            capture_output=True, text=True,
        )
        if built.returncode != 0:
            print(built.stdout[-2000:])
            print(built.stderr[-2000:])
            return 1
        print(built.stdout.strip().splitlines()[-1] if built.stdout.strip() else "built")

    dist = ROOT / "apps" / "web" / "dist" / "index.html"
    if not dist.exists():
        print(f"there is no built web application at {dist}")
        return 1

    scene = Scene(args.port, keep=args.keep)
    failures = 0
    try:
        scene.start_server()
        # The cloud worker, running, because "render on my computer" is not a
        # path that bypasses the server. Pressing Render in the Studio enqueues
        # `render_scope`, and *that* job synthesises narration, sources the
        # unclaimed visuals, flattens the edit timeline into a render contract
        # and only then hands the drawing to a device. Everything needing a
        # credential happens server-side first; the device gets pixels.
        #
        # Without it the queue holds one pending `render_scope` for ever, a
        # device that may only claim `render_timeline` correctly ignores it, and
        # the browser sits on "Rendering" with nothing wrong anywhere. That is
        # what the first two runs of this walk actually showed, and it took
        # reading the queue table to see it — from the outside it looked exactly
        # like a slow machine.
        scene.start_worker()
        print(f"server on {scene.base}, workspace {scene.root}", flush=True)

        key = mint_key(scene.base)
        print("seeding a project...", flush=True)
        project = scene.seed(args.seconds)
        print(f"project {project}", flush=True)

        pairing, approve_url, pair_log = start_pairing(scene)
        print(f"the desktop is waiting for approval at {approve_url}", flush=True)

        failures += bool(
            run_walk(scene, args, "pair", key=key, project=project, approve=approve_url)
        )

        # The desktop collects its credentials within one poll of approval.
        try:
            code = pairing.wait(timeout=90)
        except subprocess.TimeoutExpired:
            pairing.kill()
            code = -1
        if code != 0:
            print("\n  [FAIL] the desktop did not finish pairing after approval")
            print(pair_log.read_text(encoding="utf-8", errors="replace")[-1200:])
            failures += 1
        else:
            print("  the desktop collected its credentials", flush=True)

        scene.start_desktop()
        failures += bool(run_walk(scene, args, "render", key=key, project=project))

        # Said either way. A worker that died on startup and a worker with
        # nothing to do look identical from here, and this project has been
        # caught by exactly that twice.
        print(f"\n  cloud worker: {scene.worker_trouble()}")
    finally:
        scene.close()

    print(f"\nscreenshots and results: {args.shots}")
    if failures:
        print("\nFAIL — the browser found something the HTTP checks could not.")
        return 1
    print("\nPASS — the product works when a person clicks it.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
