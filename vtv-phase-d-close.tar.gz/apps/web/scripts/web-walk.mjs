/**
 * The customer path, clicked, in a real browser.
 *
 * Phase D was verified over real HTTP and never once opened in a browser. That
 * is a real gap and not a formality: `verify_phase_d.py` proves the server
 * answers correctly, and a screen that never renders answers nothing. Every
 * bug this file has found so far was invisible to both the unit tests and the
 * HTTP checks, because both of them talk to the API and the API was fine.
 *
 * Driven by `scripts/verify_web_ui.py`, which owns the server, the seeded
 * project and the desktop process. This half owns only the browser, so it can
 * be pointed at a running install by hand:
 *
 *     node scripts/web_walk.mjs --base http://127.0.0.1:8123 \
 *          --key vtv_… --project prj_… --approve <url> --phase all
 *
 * ## Why the assertions are not screenshots
 *
 * Screenshots prove a page drew. They do not prove the radio that says "on my
 * computer" survived a reload, that the render the button queued actually went
 * to the device, or that the bytes behind "Download video" decode. Each check
 * below asserts something a person would notice a week later, and the
 * screenshots are kept beside them as evidence rather than as the evidence.
 */

import { chromium } from "playwright";
import { writeFileSync, mkdirSync } from "node:fs";
import { join } from "node:path";

const args = new Map();
for (let i = 2; i < process.argv.length; i += 2) {
  args.set(process.argv[i].replace(/^--/, ""), process.argv[i + 1]);
}

const BASE = args.get("base") ?? "http://127.0.0.1:8123";
const KEY = args.get("key") ?? "";
const PROJECT = args.get("project") ?? "";
const APPROVE = args.get("approve") ?? "";
const PHASE = args.get("phase") ?? "all";
const SHOTS = args.get("shots") ?? "/tmp/vtv-web-walk";
const RENDER_TIMEOUT = Number(args.get("render-timeout") ?? 900) * 1000;

mkdirSync(SHOTS, { recursive: true });

/**
 * What the walk writes into the Studio.
 *
 * Five short lines, because the point is a real render finishing in a
 * reasonable time, not a long one. Blank lines separate ideas — that is where
 * the system cuts — so five paragraphs is five visuals.
 */
const SCRIPT = `Before computer science had a name, computation was a mechanical art.

Rooms of brass and glass did the arithmetic that a pocket does now.

Then, in December 1947, three men at Bell Labs pressed two gold contacts onto a sliver of germanium.

The current that came out was larger than the current that went in.

Within a decade the vacuum tube was a museum piece.`;

const results = [];
let shot = 0;

function check(name, passed, evidence = "") {
  results.push({ name, passed: Boolean(passed), evidence });
  const mark = passed ? "PASS" : "FAIL";
  console.log(`  [${mark}] ${name}${evidence ? `\n         ${evidence}` : ""}`);
  return Boolean(passed);
}

/**
 * A check this browser cannot decide, recorded as such.
 *
 * Neither a pass nor a failure, because both would be a lie. Playwright ships
 * the *open-source* Chromium build, which contains no H.264 and no AAC
 * decoder — `canPlayType('video/mp4; codecs="avc1.42E01E"')` returns the empty
 * string. The product encodes H.264/AAC, so this browser cannot play its
 * output at all, while every browser a customer actually uses can.
 *
 * Reporting that as a failure would train whoever runs this to ignore a red
 * line; reporting it as a pass would claim something nothing here checked.
 * What can still be checked in this browser is everything up to the decode —
 * that a link is minted, that the element is pointed at it, that the bytes
 * arrive and are an MP4 — and that is what happens instead.
 */
function skip(name, why) {
  results.push({ name, passed: true, skipped: true, evidence: why });
  console.log(`  [SKIP] ${name}\n         ${why}`);
}

async function capture(page, name) {
  shot += 1;
  const file = join(SHOTS, `${String(shot).padStart(2, "0")}-${name}.png`);
  await page.screenshot({ path: file, fullPage: true });
  return file;
}

/** Everything the page said went wrong, so a silent failure cannot stay silent. */
function watchForTrouble(page) {
  const trouble = [];
  page.on("console", (message) => {
    if (message.type() === "error") trouble.push(`console: ${message.text()}`);
  });
  page.on("pageerror", (error) => trouble.push(`uncaught: ${error.message}`));
  page.on("response", (response) => {
    if (response.status() < 400) return;
    const path = new URL(response.url()).pathname;
    // Asking before knowing. The backend has no aggregate that would answer
    // these without a request, so a 404 is the answer rather than a fault:
    //
    //   /script       a project with no script yet has no script document
    //   /captions.vtt written by the render, so absent until one has run
    //   /preview      preview metadata, same
    //   /timeline     the *spoken* lane's document. A project authored in the
    //                 Studio keeps its own under `edit_timeline` and will
    //                 never have one, so this 404 is permanent for every
    //                 project the Studio creates. Harmless, and one wasted
    //                 request per load — worth tidying, not worth failing.
    if (/\/(script|captions\.vtt|preview|timeline)$/.test(path)) return;
    trouble.push(`${response.status()} ${path}`);
  });
  page.on("requestfailed", (request) => {
    // Aborted media requests are normal when a page is torn down mid-load.
    const why = request.failure()?.errorText ?? "";
    if (why.includes("ERR_ABORTED")) return;
    trouble.push(`request failed: ${request.url()} — ${why}`);
  });
  return trouble;
}

async function textOf(page) {
  return (await page.locator("body").innerText()).replace(/\s+/g, " ");
}

/** Wait until the page's text matches, rather than for a fixed number of ms. */
async function until(page, predicate, timeoutMs, everyMs = 500) {
  const deadline = Date.now() + timeoutMs;
  let last = "";
  while (Date.now() < deadline) {
    last = await textOf(page);
    if (predicate(last)) return { ok: true, text: last };
    await page.waitForTimeout(everyMs);
  }
  return { ok: false, text: last };
}

async function signIn(page, key) {
  await page.goto(`${BASE}/`, { waitUntil: "networkidle" });
  const field = page.locator('input[aria-label="API key"]');
  await field.waitFor({ timeout: 15000 });
  await field.fill(key);
  await page.getByRole("button", { name: "Continue" }).click();
  // Waited for, not assumed. The screen stores the key and reloads the page;
  // navigating away before that reload finishes leaves the browser on the
  // sign-in screen with the key stored, which reads as "the device never
  // appeared" three checks later. That is exactly how this failed once.
  await page.waitForSelector(".shell", { timeout: 30000 });
}

// -- phase one: sign in and pair -------------------------------------------

async function phasePairing(page, trouble) {
  console.log("\n=== 1. Signing in ===\n");

  await page.goto(`${BASE}/`, { waitUntil: "networkidle" });
  check(
    "an unauthenticated browser is asked for a key rather than shown an empty app",
    (await textOf(page)).includes("API key") ||
      (await page.locator('input[aria-label="API key"]').count()) > 0,
    await capture(page, "signin"),
  );

  // A wrong key must fail out loud. A sign-in that silently does nothing is
  // the single most common way a working backend looks broken.
  await page.locator('input[aria-label="API key"]').fill("vtv_test_notarealkey");
  await page.getByRole("button", { name: "Continue" }).click();
  const refused = await until(
    page,
    (text) => text.includes("not accepted"),
    10000,
  );
  check(
    "a key the server rejects produces a visible message, not silence",
    refused.ok,
    refused.ok ? "" : `page said: ${refused.text.slice(0, 200)}`,
  );
  // That check *is* a 401, deliberately. Leaving it in the trouble log would
  // mean the walk's own test of the failure path failed the walk.
  trouble.length = 0;

  await signIn(page, KEY);
  const inside = await until(
    page,
    (text) => text.includes("Projects") && text.includes("Computers"),
    20000,
  );
  check(
    "a valid key lands in the application with its navigation",
    inside.ok,
    await capture(page, "signed-in"),
  );

  console.log("\n=== 2. Before any computer is paired ===\n");

  await page.goto(`${BASE}/devices`, { waitUntil: "networkidle" });
  const empty = await until(
    page,
    (text) => text.includes("No computers yet") || text.includes("cannot be listed"),
    15000,
  );
  check(
    "the Computers page says there are none, and how to add one",
    empty.text.includes("No computers yet") &&
      empty.text.includes("vtv-desktop pair"),
    await capture(page, "devices-empty"),
  );
  check(
    "and offers the three places a render can run before one exists",
    empty.text.includes("Automatically") &&
      empty.text.includes("On my computer") &&
      empty.text.includes("In the cloud"),
    "",
  );
  check(
    "with Automatically saying plainly that it will use the cloud",
    empty.text.includes("No computer is running, so this will use the cloud"),
    "",
  );

  console.log("\n=== 3. Approving a computer the way a person would ===\n");

  await page.goto(APPROVE, { waitUntil: "networkidle" });
  const waiting = await until(
    page,
    (text) => text.includes("Approve this computer") || text.includes("no longer waiting"),
    20000,
  );
  const code = new URL(APPROVE).searchParams.get("code") ?? "";
  check(
    "the approval page shows the same code the computer printed",
    waiting.text.includes(code),
    `code ${code}`,
  );
  check(
    "and names the machine and its hardware before asking",
    waiting.text.includes("web walk"),
    await capture(page, "approve"),
  );
  check(
    "and states what the computer will and will not be given",
    waiting.text.includes("never given your provider keys"),
    "",
  );

  await page.getByRole("button", { name: "Approve this computer" }).click();
  const approved = await until(
    page,
    (text) => text.includes("is connected"),
    30000,
  );
  check(
    "approving says the computer is connected",
    approved.ok,
    await capture(page, "approved"),
  );

  check("the browser reported nothing broken during pairing", trouble.length === 0,
    trouble.slice(0, 3).join(" | "));
  return trouble.length === 0;
}

// -- phase two: choose the device, render on it, watch, play ---------------

async function phaseRender(page, trouble) {
  console.log("\n=== 4. The computer appears, and can be chosen ===\n");

  await signIn(page, KEY);
  await page.goto(`${BASE}/devices`, { waitUntil: "networkidle" });

  const listed = await until(
    page,
    (text) => text.includes("web walk") && (text.includes("Ready") || text.includes("Rendering")),
    90000,
    1000,
  );
  check(
    "the paired computer is listed, with a state a person can read",
    listed.ok,
    await capture(page, "devices-listed"),
  );

  const auto = await textOf(page);
  check(
    "and Automatically now offers to use it rather than the cloud",
    auto.includes("Use one of your computers when it is running"),
    "",
  );

  // The radio, clicked. Not `writeExecution` called from the console: the
  // question is whether the control a person sees is wired to the preference
  // the Studio reads.
  await page.locator('input[name="vtv-execution"][value="device"]').check();
  await page.waitForTimeout(400);

  await page.reload({ waitUntil: "networkidle" });
  await page.waitForTimeout(1200);
  const stillChecked = await page
    .locator('input[name="vtv-execution"][value="device"]')
    .isChecked();
  check(
    "choosing 'on my computer' survives a reload",
    stillChecked,
    await capture(page, "devices-chosen"),
  );

  const stored = await page.evaluate(() => {
    try {
      return window.localStorage.getItem("vtv.execution");
    } catch {
      return null;
    }
  });
  check(
    "and the preference the Studio will read says the same thing",
    stored === "device",
    `stored: ${JSON.stringify(stored)}`,
  );

  console.log("\n=== 5. Writing a project, in the Studio ===\n");

  // Authored here rather than seeded, and the first run of this walk is why.
  //
  // It opened the fixture `seed_device_job.py` creates — a project with a
  // stored `timeline` document — and the Studio drew an empty script, an empty
  // timeline and a Render button that submitted a request the server then
  // refused. The fixture writes the spoken lane; the Studio edits its own
  // (`edit_timeline`). Both are real, and a walk that seeds one and opens the
  // other is testing the seam rather than the product.
  //
  // A customer's project comes from this screen. So does this one.
  await page.goto(`${BASE}/`, { waitUntil: "domcontentloaded" });
  await page.waitForSelector(".start__title", { timeout: 20000 });
  check(
    "the start screen offers a way in that does not need a microphone",
    (await page.locator(".modecard").count()) === 2,
    await capture(page, "start"),
  );

  await page.click(".modecard:nth-child(2) .btn");
  await page.waitForSelector(".studio", { timeout: 30000 });
  const authored = new URL(page.url()).pathname.split("/")[2] ?? "";
  check("choosing 'write it' creates a project and opens the Studio", Boolean(authored), authored);

  await page.waitForSelector(".script__composer", { timeout: 20000 });
  await page.fill(".script__composer", SCRIPT);
  await page.click(".script__empty .btn--primary");

  await page.waitForSelector(".block", { timeout: 60000 });
  const lines = await page.locator(".block").count();
  check("the script became addressable lines", lines >= 3, `${lines} lines`);

  let clips = 0;
  try {
    await page.waitForSelector(".tl__clip", { timeout: 120000 });
    clips = await page.locator(".tl__clip").count();
  } catch {
    /* reported by the check below */
  }
  check(
    "visuals were planned and the timeline drew clips",
    clips >= 1,
    clips ? `${clips} clips — ${await capture(page, "studio")}` : await capture(page, "studio-noclips"),
  );

  console.log("\n=== 6. Rendering it, on that computer ===\n");

  // Watch what the browser actually asks for, so "it rendered on the device"
  // is read off the wire rather than inferred from a label.
  let submitted = null;
  page.on("request", (request) => {
    if (request.method() === "POST" && /\/render$/.test(new URL(request.url()).pathname)) {
      try {
        submitted = JSON.parse(request.postData() ?? "{}");
      } catch {
        submitted = { unparsed: request.postData() };
      }
    }
  });

  await page.getByRole("button", { name: "Render", exact: true }).first().click();
  // Some projects show a confirmation before rendering — take it if it appears.
  const anyway = page.getByRole("button", { name: "Render anyway" });
  if (await anyway.count().then((n) => n > 0).catch(() => false)) {
    await anyway.first().click().catch(() => {});
  }

  const started = await until(
    page,
    (text) => text.includes("Rendering") || text.includes("Render started"),
    30000,
  );
  check(
    "pressing Render says so, rather than appearing to do nothing",
    started.ok,
    await capture(page, "rendering"),
  );
  check(
    "and the request the browser sent asked for the device",
    submitted !== null && submitted.execution === "device",
    `body: ${JSON.stringify(submitted)}`,
  );

  const finished = await until(
    page,
    (text) => text.includes("Rendered") || text.includes("could not") || text.includes("failed"),
    RENDER_TIMEOUT,
    2000,
  );
  check(
    "the Studio reports the render finished",
    finished.ok && finished.text.includes("Rendered"),
    finished.ok ? await capture(page, "rendered") : `last: ${finished.text.slice(0, 300)}`,
  );

  console.log("\n=== 7. The finished video, in the browser ===\n");

  await page.goto(`${BASE}/studio/${authored}/renders`, { waitUntil: "domcontentloaded" });
  await page.waitForTimeout(1500);
  const history = await textOf(page);
  check(
    "the render history lists the render that just happened",
    !history.includes("Render from the Studio to produce a video"),
    await capture(page, "renders"),
  );

  const hasDownload = (await page.getByRole("button", { name: "Download" }).count()) > 0;
  check("the finished render offers a download", hasDownload, "");

  // The endpoint a browser can actually follow. Asked for the way the page
  // asks — with the credential — and then loaded the way a media element
  // would: with none.
  const link = await page.evaluate(async ({ base, project, key }) => {
    const response = await fetch(`${base}/v1/projects/${project}/video/link`, {
      headers: { Authorization: `Bearer ${key}` },
    });
    if (!response.ok) return { status: response.status };
    return await response.json();
  }, { base: BASE, project: authored, key: KEY });
  check(
    "the server mints a signed link for the video",
    Boolean(link && link.url),
    JSON.stringify(link).slice(0, 200),
  );

  // The real question: do those bytes decode in a browser? A 200 with a
  // content-type is not a video, and the Studio has no player of its own —
  // so the check makes one.
  const codecs = await page.evaluate(() => {
    const probe = document.createElement("video");
    return {
      h264: probe.canPlayType('video/mp4; codecs="avc1.42E01E"'),
      aac: probe.canPlayType('audio/mp4; codecs="mp4a.40.2"'),
    };
  });
  const canDecode = Boolean(codecs.h264);

  // What can be checked without a decoder: that the bytes arrive, and that
  // they are an MP4. Every MP4 carries `ftyp` at offset 4.
  const fetched = await page.evaluate(async (url) => {
    try {
      const response = await fetch(url);
      const buffer = new Uint8Array(await response.arrayBuffer());
      const brand = String.fromCharCode(...buffer.slice(4, 8));
      return {
        status: response.status,
        type: response.headers.get("content-type"),
        bytes: buffer.length,
        brand,
      };
    } catch (error) {
      return { error: String(error) };
    }
  }, link?.url ?? "");
  check(
    "the browser can fetch those bytes, and they are an MP4",
    fetched.status === 200 && fetched.brand === "ftyp" && fetched.bytes > 10000,
    JSON.stringify(fetched),
  );

  if (!canDecode) {
    const why =
      "this Chromium has no H.264 decoder " +
      `(canPlayType returned ${JSON.stringify(codecs)}), so nothing here can ` +
      "play the product's output. The bytes were checked above; ffprobe " +
      "checks the encode in verify_phase_d.py.";
    skip("and the bytes behind it decode as a video with a real duration", why);
    skip("the Studio's own preview loads the finished video", why);
    check("the browser reported nothing broken during the render",
      trouble.length === 0, trouble.slice(0, 5).join(" | "));
    return results.every((r) => r.passed);
  }

  const played = await page.evaluate(async (url) => {
    return await new Promise((resolve) => {
      const video = document.createElement("video");
      video.preload = "metadata";
      video.muted = true;
      const done = (value) => resolve(value);
      video.addEventListener("loadedmetadata", () =>
        done({ ok: true, duration: video.duration, width: video.videoWidth, height: video.videoHeight }),
      );
      video.addEventListener("error", () =>
        done({ ok: false, why: video.error ? video.error.message || String(video.error.code) : "unknown" }),
      );
      setTimeout(() => done({ ok: false, why: "timed out loading metadata" }), 60000);
      video.src = url;
    });
  }, link?.url ?? "");

  check(
    "and the bytes behind it decode as a video with a real duration",
    played.ok && played.duration > 0,
    JSON.stringify(played),
  );

  // The Studio's own player, in the Studio. The check above proves the bytes
  // are playable; this one proves the product actually plays them, which is
  // the half that was broken: the preview pointed a `<video>` at an endpoint
  // that authorises with a header no media element sends.
  await page.goto(`${BASE}/studio/${authored}`, { waitUntil: "domcontentloaded" });
  await page.waitForSelector(".studio", { timeout: 30000 });
  const inStudio = await page
    .waitForFunction(
      () => {
        const video = document.querySelector("video");
        if (!video || video.hidden) return false;
        return video.readyState >= 1
          ? { duration: video.duration, src: video.currentSrc.slice(0, 60) }
          : false;
      },
      undefined,
      { timeout: 60000 },
    )
    .then((handle) => handle.jsonValue())
    .catch(() => null);
  check(
    "the Studio's own preview loads the finished video",
    Boolean(inStudio && inStudio.duration > 0),
    inStudio ? JSON.stringify(inStudio) : await capture(page, "preview-empty"),
  );

  check("the browser reported nothing broken during the render", trouble.length === 0,
    trouble.slice(0, 5).join(" | "));

  return results.every((r) => r.passed);
}

// -- main -------------------------------------------------------------------

const browser = await chromium.launch();
const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
const page = await context.newPage();
const trouble = watchForTrouble(page);

try {
  if (PHASE === "pair" || PHASE === "all") await phasePairing(page, trouble);
  if (PHASE === "render" || PHASE === "all") await phaseRender(page, trouble);
} catch (error) {
  check("the walk ran to the end", false, `${error}`);
  await capture(page, "crash").catch(() => {});
} finally {
  writeFileSync(
    join(SHOTS, "results.json"),
    JSON.stringify({ results, trouble }, null, 2),
  );
  await browser.close();
}

const failed = results.filter((r) => !r.passed);
const skipped = results.filter((r) => r.skipped);
console.log(
  `\n  ${results.length - failed.length - skipped.length}/` +
    `${results.length - skipped.length} checks passed` +
    (skipped.length ? `, ${skipped.length} not decidable in this browser` : "") +
    (failed.length ? `\n  failed: ${failed.map((f) => f.name).join("; ")}` : ""),
);
process.exit(failed.length ? 1 : 0);
