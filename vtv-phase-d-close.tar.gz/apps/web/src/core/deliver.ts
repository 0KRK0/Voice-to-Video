/**
 * Getting a finished file out of the product and onto somebody's disk.
 *
 * ## Why this is not a link
 *
 * It was. Both places that offered the video were `<a download href="…/video">`
 * pointing at an endpoint that authorises with a bearer token — and a browser
 * following a link sends no Authorization header. The download therefore
 * arrived unauthenticated and, in any install that actually authenticates,
 * returned 401. It appeared to work throughout development for one reason: an
 * unconfigured install answers unauthenticated requests as a development
 * principal, which is precisely the condition that hides this until it ships.
 *
 * The fix is not a cookie. A cookie would authenticate every request the
 * browser makes to this origin, including ones caused by a page the customer
 * did not write; buying a working download with ambient authority is a bad
 * trade. Instead the *authenticated* request is made with `fetch`, where a
 * header is possible, and what comes back is a short-lived signed URL — the
 * same signature, expiry and single-key scope that every asset handed to a
 * customer's computer already uses.
 *
 * ## Why the video is not fetched as a blob and the captions are
 *
 * A four-hour render is nearly two gigabytes. Reading it into memory to make
 * an object URL would take the tab down, and it would also throw away range
 * requests, which is what lets somebody scrub a video without downloading all
 * of it. Captions are a few kilobytes of text and have neither problem.
 */

import { toast } from "../widgets/dialog.js";
import type { VtvClient } from "../api/client.js";

/** Ask the browser to save `url` as `filename`, without navigating away. */
function save(url: string, filename: string): void {
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  anchor.rel = "noopener";
  // Appended because Firefox ignores a click on a detached anchor.
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
}

/**
 * Download the finished video.
 *
 * Errors are shown rather than swallowed. The three real ones are distinct and
 * a person can act on each: nothing rendered, the render has expired from
 * cloud storage, or this key cannot read the project.
 */
export async function downloadVideo(
  client: VtvClient,
  projectId: string,
): Promise<boolean> {
  try {
    const link = await client.videoLink(projectId);
    save(link.url, "video.mp4");
    return true;
  } catch (error) {
    toast(
      error instanceof Error && /410|expired/i.test(error.message)
        ? "That render is no longer stored here. Renders drawn on your own " +
            "computer are kept on it."
        : "The video could not be fetched. Try rendering again.",
      { tone: "error" },
    );
    return false;
  }
}

/** Download the captions that were written alongside the video. */
export async function downloadCaptions(
  client: VtvClient,
  projectId: string,
): Promise<boolean> {
  let url = "";
  try {
    const text = await client.captionsText(projectId);
    url = URL.createObjectURL(new Blob([text], { type: "text/vtt" }));
    save(url, "captions.vtt");
    return true;
  } catch {
    toast("The captions could not be fetched.", { tone: "error" });
    return false;
  } finally {
    // Revoked on a timer rather than immediately: the click above is
    // asynchronous, and revoking the URL before the browser has read it
    // produces a download of zero bytes.
    if (url) window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
  }
}
