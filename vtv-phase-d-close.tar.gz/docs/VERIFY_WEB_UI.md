# Verifying the web application — in a browser

    cd "D:\Voice to Video"
    .\.venv\Scripts\Activate.ps1
    python scripts\verify_web_ui.py

One command. It builds the web application, starts its own server on port 8134
with a throwaway database, seeds nothing it does not need, runs a real desktop
process, and drives a real Chromium through the path a first customer walks.
About fifteen minutes on your card, most of it the render.

Screenshots and a machine-readable result land in `var\web-walk\`.

---

## Why this exists

Phase D passed eighteen checks over real HTTP and **the browser had never been
opened once**. Those are not the same thing, and the difference is not cosmetic:
`verify_phase_d.py` asks the server questions and the server answered every one
of them correctly. A screen that never renders answers nothing.

The first run of this walk found four faults. Every one of them was invisible to
1,733 unit tests and to eighteen HTTP checks, because the HTTP was fine.

---

## What the first run found

### 1. Nobody could pair a computer

`PAIR_LIMIT` refills at one token every five seconds. The desktop polls
`/v1/devices/pair/collect` every three. The burst of ten therefore drained in
about twenty-five seconds, after which the server answered `429` — and the
desktop treated any non-`202` as terminal and gave up, printing a message
blaming the server.

So **anybody who took longer than half a minute to approve their own computer
could not pair it**. That is everybody who walks to another window.

Neither the unit tests nor `verify_phase_d.py` could see it: both pair with a
code, in a single request. Only a flow with a human-shaped pause in the middle
of it has this shape at all.

The fix has two halves, and both are corrections rather than accommodations:

* The tight budget is for people **guessing** device codes, so it is now charged
  when a code fails to resolve — which is what every guess looks like. Polling
  with a credential you already hold is not an attempt to guess one. This is the
  rule `authenticate` already applies to bearer tokens.
* A `429` means *slow down*, not *stop*. The desktop backs off, honours
  `Retry-After`, and keeps waiting — which is what the device-authorization
  grant this flow is modelled on has always said.

### 2. The download link could not work outside development

Both places the product offered the finished video were
`<a download href=".../video">`, and the preview player set
`video.src = .../video`. That endpoint authorises with a bearer token.

**A browser following a link sends no headers. A media element sends no
headers.** Both arrived unauthenticated: `401` in any install that actually
authenticates.

It worked throughout development for exactly one reason — an unconfigured
install answers unauthenticated requests as a development principal. That is
the condition that hides this entire class of bug until the day somebody
switches authentication on.

The fix is not a cookie; a cookie would authenticate every request the browser
makes to this origin, including ones caused by a page the customer did not
write. Instead `GET /v1/projects/{id}/video/link` is called *with* the
credential, using `fetch`, and returns a short-lived signed URL — the same
signature, expiry and single-key scope already used for every asset handed to a
customer's computer.

### 3. The Studio showed nothing for a seeded project

The walk originally opened the project `seed_device_job.py` creates and found an
empty script, an empty timeline, and a Render button that submitted a request
the server refused. The fixture writes the spoken lane (a `timeline` document);
the Studio edits its own (`edit_timeline`). Both are real. A walk that seeds one
and opens the other is testing the seam rather than the product, so the walk now
**writes its project in the Studio**, the way a customer does.

This is worth knowing as a product fact, not only a test one: a project created
outside the Studio's authoring lane opens blank in the Studio.

### 4. Two faults in the walk itself

`page.goto(..., { waitUntil: "networkidle" })` never resolves on the Studio,
which holds a server-sent events stream open — a page that loaded perfectly
timed out. And the sign-in helper did not wait for the reload the sign-in screen
performs, so the next navigation happened on the sign-in screen and three
unrelated checks failed.

Both are the usual lesson in this project, which is now on its sixth instance:
**a verification tool is as likely to be wrong as the code it verifies.**

---

## What each check proves

**Signing in.** That an unauthenticated browser is asked for a key rather than
shown an empty application, and — the one worth having — that a key the server
*rejects* produces a visible message. A sign-in that silently does nothing is
the single most common way a working backend looks broken.

**Before pairing.** That the Computers page says there are none and how to add
one, offers all three places a render can run *before* one exists, and states
plainly that Automatically will use the cloud. An option that only appears once
you have done the work is one nobody discovers.

**Approving.** That the approval screen shows the same code the computer
printed — the comparison is the entire security value of a short code, and a
screen that just says "Approve?" throws it away — names the machine, states what
it will and will not be given, and that approving actually hands the waiting
computer its credential.

**Choosing.** That the paired computer appears with a state a person can read,
that Automatically changes its sentence, that clicking "on my computer" survives
a reload, and that the value the Studio will read says the same thing. The radio
is clicked; `writeExecution` is not called from the console.

**Authoring.** That the start screen offers a way in that does not need a
microphone, that choosing it creates a project and opens the Studio, that a
pasted script becomes addressable lines, and that visuals are planned and drawn
as clips.

**Rendering.** That pressing Render says so rather than appearing to do nothing,
and — read off the wire, not inferred from a label — that the request the
browser sent asked for `execution: "device"`.

**The result.** That the render history lists it, that a download is offered,
that the server mints a signed link, that the bytes behind that link decode in a
browser as a video with a real duration, and that **the Studio's own preview
loads it**. The last one is the half that was broken.

---

## Running it against an install you already have

The browser half is a separate program and takes an install it did not build:

    node apps/web/scripts/web-walk.mjs \
        --base http://127.0.0.1:8000 \
        --key vtv_… --phase render --shots ./shots

`--phase pair` walks the sign-in and approval; `--phase render` walks the
Studio; the default walks both. `--phase pair` needs `--approve <url>`, which is
the address `vtv-desktop pair` prints.
